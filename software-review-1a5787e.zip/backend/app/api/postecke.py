"""
API-Router für die Postecke (Social-Media-Modul, Etappe 1).

Endpunkte:
  Profile:  GET/POST       /postecke/profile
            PUT/DELETE     /postecke/profile/{id}
  Posts:    GET            /postecke/posts?status=...
            POST           /postecke/posts
            GET/PUT/DELETE /postecke/posts/{id}
            POST           /postecke/posts/{id}/status      (Workflow inkl. Planung)
            POST           /postecke/posts/{id}/generieren  (KI-Vorschlag)
  Fotos:    POST           /postecke/posts/{id}/fotos       (Upload, multipart)
            GET            /postecke/fotos/{id}             (Bild abrufen)
            DELETE         /postecke/fotos/{id}
  Video:    POST           /postecke/posts/{id}/video       (Upload MP4/MOV, ein Video)
            GET            /postecke/videos/{id}            (Video abrufen)
            GET            /postecke/videos/{id}/poster     (Standbild/Vorschau)
            DELETE         /postecke/videos/{id}

Rechte: Profile und Posts sind persönlich — sichtbar/änderbar nur für den
Besitzer (private Social-Media-Konten).
"""

from datetime import datetime, timezone
from typing import List, Optional
from uuid import UUID, uuid4

from fastapi import APIRouter, Depends, HTTPException, Query, UploadFile, File, Response
from sqlalchemy.orm import Session

from app.db.base import get_db
from app.api.deps import get_current_user
from app.models.user import User
from app.models.postecke import (
    SocialProfil, SocialPost, SocialPostFoto, SocialPostVideo, POST_STATUS,
)
from app.schemas.postecke import (
    ProfilCreate, ProfilUpdate, ProfilResponse,
    PostCreate, PostUpdate, PostStatusUpdate, PostResponse,
    GenerierenRequest, GenerierenResponse,
)
import json

from app.services import storage_service
from app.services import postecke as postecke_service
from app.services import social_publish

router = APIRouter(prefix="/postecke", tags=["Postecke"])

ERLAUBTE_FOTO_TYPEN = ("image/jpeg", "image/png", "image/webp", "image/heic", "image/heif")
MAX_FOTO_BYTES = 25 * 1024 * 1024  # 25 MB je Foto (iPhone-Originale)
MAX_FOTOS_JE_POST = 20

# Video: max. eines je Post, kein Misch-Post mit Fotos. MP4/MOV, bis 200 MB
# (nginx client_max_body_size ist entsprechend auf 200M gesetzt).
ERLAUBTE_VIDEO_TYPEN = ("video/mp4", "video/quicktime")
MAX_VIDEO_BYTES = 200 * 1024 * 1024  # 200 MB je Video


def _loesche_video_dateien(db: Session, video: SocialPostVideo) -> None:
    """
    Entfernt Video und Standbild aus dem Speicher, in dem sie tatsächlich
    liegen (``storage_provider``), nicht aus dem gerade aktiven. Ohne diese
    Unterscheidung bleiben nach einem Speicherwechsel Dateileichen zurück —
    ein Löschversuch am falschen Ort meldet je nach Provider nicht einmal
    einen Fehler. NULL bedeutet weiterhin „aktiver Speicher".
    """
    storage_service.delete_file(video.storage_key, db, backend=video.storage_provider)
    if video.poster_key:
        storage_service.delete_file(video.poster_key, db, backend=video.storage_provider)


def _sync_datacenter(db: Session, post: SocialPost, user_id) -> None:
    """
    Spiegelt den Post laufend ins Datacenter (Ordner „Postecke" bzw. beim
    Kontakt). Fehler dürfen die eigentliche Aktion nie scheitern lassen — sie
    werden nur protokolliert. Committet selbst nicht; der Aufrufer committet.
    """
    try:
        postecke_service.synchronisiere_datacenter(db, post, user_id=user_id)
    except Exception as e:
        print(f"[WARN] Datacenter-Ablage (Postecke) fehlgeschlagen für {post.id}: {e}")


# ── Hilfen ────────────────────────────────────────────────────────────────────
def _get_profil(db: Session, profil_id: UUID, user: User) -> SocialProfil:
    p = (db.query(SocialProfil)
         .filter(SocialProfil.id == profil_id,
                 SocialProfil.owner_user_id == user.id).first())
    if not p:
        raise HTTPException(404, "Profil nicht gefunden")
    return p


def _get_post(db: Session, post_id: UUID, user: User) -> SocialPost:
    p = (db.query(SocialPost)
         .filter(SocialPost.id == post_id,
                 SocialPost.owner_user_id == user.id).first())
    if not p:
        raise HTTPException(404, "Post nicht gefunden")
    return p


# ── Profile ───────────────────────────────────────────────────────────────────
def _profil_response(p: SocialProfil) -> ProfilResponse:
    """Response mit Zugangs-Status (die Zugangsdaten selbst bleiben am Server)."""
    resp = ProfilResponse.model_validate(p)
    resp.has_zugang = bool(p.zugang_enc)
    resp.direktanbindung = social_publish.hat_direktanbindung(p)
    return resp


@router.get("/profile", response_model=List[ProfilResponse])
def list_profile(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    rows = (db.query(SocialProfil)
            .filter(SocialProfil.owner_user_id == current_user.id)
            .order_by(SocialProfil.created_at).all())
    return [_profil_response(p) for p in rows]


@router.post("/profile", response_model=ProfilResponse, status_code=201)
def create_profil(
    body: ProfilCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    daten = body.model_dump()
    zugang = daten.pop("zugang", None)
    p = SocialProfil(owner_user_id=current_user.id, **daten)
    zugang = {k: v for k, v in (zugang or {}).items() if v}  # leere Felder weglassen
    if zugang:
        p.zugang_enc = social_publish.encrypt_secret(json.dumps(zugang))
    db.add(p)
    db.commit()
    db.refresh(p)
    return _profil_response(p)


@router.put("/profile/{profil_id}", response_model=ProfilResponse)
def update_profil(
    profil_id: UUID,
    body: ProfilUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    p = _get_profil(db, profil_id, current_user)
    daten = body.model_dump(exclude_unset=True)
    zugang = daten.pop("zugang", None)
    for key, value in daten.items():
        setattr(p, key, value)
    zugang = {k: v for k, v in (zugang or {}).items() if v}  # leere Felder weglassen
    if zugang:  # leer = unverändert lassen
        p.zugang_enc = social_publish.encrypt_secret(json.dumps(zugang))
    db.commit()
    db.refresh(p)
    return _profil_response(p)


@router.post("/profile/{profil_id}/verbindung-testen")
def teste_profil_verbindung(
    profil_id: UUID,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Prüft die hinterlegten Zugangsdaten gegen den Kanal (z.B. Graph API)."""
    p = _get_profil(db, profil_id, current_user)
    tester = social_publish.KANAL_VERBINDUNGSTEST.get(p.kanal)
    if not tester:
        raise HTTPException(400, f"Kanal {p.kanal} hat (noch) keine Direktanbindung")
    zugang = social_publish.lade_zugang(p)
    if not zugang:
        raise HTTPException(400, "Keine Zugangsdaten hinterlegt")
    return tester(zugang)


@router.delete("/profile/{profil_id}", status_code=204)
def delete_profil(
    profil_id: UUID,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    p = _get_profil(db, profil_id, current_user)
    db.delete(p)
    db.commit()


# ── Posts ─────────────────────────────────────────────────────────────────────
@router.get("/posts", response_model=List[PostResponse])
def list_posts(
    status: Optional[str] = Query(None),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    q = db.query(SocialPost).filter(SocialPost.owner_user_id == current_user.id)
    if status:
        if status not in POST_STATUS:
            raise HTTPException(422, "Ungültiger Status")
        q = q.filter(SocialPost.status == status)
    return q.order_by(SocialPost.created_at.desc()).all()


@router.post("/posts", response_model=PostResponse, status_code=201)
def create_post(
    body: PostCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    if body.profil_id:
        _get_profil(db, body.profil_id, current_user)  # Rechteprüfung
    p = SocialPost(owner_user_id=current_user.id, **body.model_dump())
    db.add(p)
    db.commit()
    db.refresh(p)
    _sync_datacenter(db, p, current_user.id)
    db.commit()
    db.refresh(p)
    return p


@router.get("/posts/{post_id}", response_model=PostResponse)
def get_post(
    post_id: UUID,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    return _get_post(db, post_id, current_user)


@router.put("/posts/{post_id}", response_model=PostResponse)
def update_post(
    post_id: UUID,
    body: PostUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    p = _get_post(db, post_id, current_user)
    payload = body.model_dump(exclude_unset=True)
    if payload.get("profil_id"):
        _get_profil(db, payload["profil_id"], current_user)  # Rechteprüfung
    for key, value in payload.items():
        setattr(p, key, value)
    db.commit()
    db.refresh(p)
    _sync_datacenter(db, p, current_user.id)
    db.commit()
    db.refresh(p)
    return p


@router.delete("/posts/{post_id}", status_code=204)
def delete_post(
    post_id: UUID,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    p = _get_post(db, post_id, current_user)
    for foto in list(p.fotos or []):
        storage_service.delete_file(foto.storage_key, db, backend=foto.storage_provider)
    if p.video is not None:
        _loesche_video_dateien(db, p.video)
    db.delete(p)
    db.commit()


@router.post("/posts/{post_id}/status", response_model=PostResponse)
def set_post_status(
    post_id: UUID,
    body: PostStatusUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    p = _get_post(db, post_id, current_user)
    vorher = p.status
    p.status = body.status
    if body.status == "geplant":
        if not body.geplant_am:
            raise HTTPException(422, "Für Status 'geplant' wird geplant_am benötigt")
        p.geplant_am = body.geplant_am
    if body.status == "veroeffentlicht":
        p.veroeffentlicht_am = datetime.now(timezone.utc)

    db.commit()
    db.refresh(p)
    # Datacenter-Ablage aktuell halten (z.B. frisches Veröffentlicht-Datum im
    # Content-Text). Die Kopien bleiben unabhängig vom Status erhalten.
    _sync_datacenter(db, p, current_user.id)
    db.commit()
    db.refresh(p)
    return p


# ── Direkt veröffentlichen (Kanäle mit Anbindung, z.B. Facebook-Seite) ────────
@router.post("/posts/{post_id}/veroeffentlichen", response_model=PostResponse)
def veroeffentliche_post(
    post_id: UUID,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """
    Veröffentlicht den Post sofort über die Direktanbindung seines Profils:
    Foto-Post (Fotos in der Ausspielungs-Variante + Text/Hashtags) ODER
    Video-Post (Video + Text/Hashtags als Beschreibung). Setzt Status auf
    "veröffentlicht" und speichert die Beitrags-URL.
    """
    p = _get_post(db, post_id, current_user)
    if not (p.text or "").strip():
        raise HTTPException(422, "Der Post hat noch keinen Text")
    profil = None
    if p.profil_id:
        profil = db.query(SocialProfil).filter(SocialProfil.id == p.profil_id).first()
    if not social_publish.hat_direktanbindung(profil):
        raise HTTPException(400, "Dieses Profil hat keine Direktanbindung — bitte assistiert posten")
    try:
        social_publish.publiziere(db, p, profil)
    except RuntimeError as e:
        raise HTTPException(502, str(e)) from e
    db.commit()
    db.refresh(p)
    _sync_datacenter(db, p, current_user.id)
    db.commit()
    db.refresh(p)
    return p


# ── KI-Generierung ────────────────────────────────────────────────────────────
@router.post("/posts/{post_id}/generieren", response_model=GenerierenResponse)
def generiere_post(
    post_id: UUID,
    body: GenerierenRequest,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """
    Erzeugt einen KI-Vorschlag aus Fotos + Beschreibung + Profil-Stil und
    speichert ihn direkt am Post (bleibt danach frei editierbar).
    """
    p = _get_post(db, post_id, current_user)
    profil = None
    if p.profil_id:
        profil = db.query(SocialProfil).filter(SocialProfil.id == p.profil_id).first()
    try:
        vorschlag = postecke_service.generiere_vorschlag(
            db, p, profil, beschreibung=body.beschreibung)
    except RuntimeError as e:
        raise HTTPException(400, str(e)) from e
    except Exception as e:
        raise HTTPException(502, f"KI-Aufruf fehlgeschlagen: {e}") from e

    if body.beschreibung:
        p.beschreibung = body.beschreibung
    p.text = vorschlag["text"]
    p.hashtags = vorschlag["hashtags"]
    p.ort = vorschlag["ort"] or p.ort
    p.gefuehl = vorschlag["gefuehl"] or p.gefuehl
    if not p.titel:
        p.titel = vorschlag["titel"]
    p.ki_model = vorschlag["ki_model"]
    if p.status == "entwurf":
        p.status = "kontrolle"
    db.commit()
    return GenerierenResponse(**vorschlag)


# ── Fotos ─────────────────────────────────────────────────────────────────────
@router.post("/posts/{post_id}/fotos", response_model=PostResponse, status_code=201)
def upload_fotos(
    post_id: UUID,
    files: List[UploadFile] = File(...),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    p = _get_post(db, post_id, current_user)
    if p.video is not None:
        raise HTTPException(422, "Dieser Post enthält bereits ein Video — "
                                 "Foto und Video lassen sich nicht mischen.")
    vorhandene = len(p.fotos or [])
    if vorhandene + len(files) > MAX_FOTOS_JE_POST:
        raise HTTPException(422, f"Maximal {MAX_FOTOS_JE_POST} Fotos je Post")

    for i, f in enumerate(files):
        mimetype = (f.content_type or "").lower()
        if mimetype not in ERLAUBTE_FOTO_TYPEN:
            raise HTTPException(422, f"Dateityp nicht erlaubt: {f.filename}")
        data = f.file.read()
        if len(data) > MAX_FOTO_BYTES:
            raise HTTPException(422, f"Foto zu groß (max. 25 MB): {f.filename}")
        # ID selbst vergeben, damit der Storage-Key VOR dem Insert feststeht
        # (storage_key ist NOT NULL — nachträgliches Setzen scheitert am Flush)
        foto_id = uuid4()
        filename = f.filename or "foto.jpg"
        storage_key = storage_service.build_storage_key(
            "postecke", str(p.id), f"{foto_id}_{filename}")
        # Den Speicher festhalten, in den wir schreiben. Ohne diese Angabe wird
        # die Datei nach einem Speicherwechsel am falschen Ort gesucht — dieselbe
        # Lehre wie bei den Anhängen (0039) und Positionsbildern (0051).
        backend = storage_service.current_backend(db)
        storage_service.upload_file(storage_key, data, mimetype, db=db, backend=backend)
        db.add(SocialPostFoto(
            id=foto_id,
            post_id=p.id,
            storage_key=storage_key,
            storage_provider=backend,
            filename=filename,
            mimetype=mimetype,
            size_bytes=len(data),
            sort_order=vorhandene + i,
        ))

    db.commit()
    db.refresh(p)
    _sync_datacenter(db, p, current_user.id)
    db.commit()
    db.refresh(p)
    return p


@router.get("/fotos/{foto_id}/ausspielung")
def get_foto_ausspielung(
    foto_id: UUID,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """
    Foto in der Ausspielungs-Variante des Post-Profils: Zielformat
    (z.B. 1:1, mittiger Zuschnitt) und Filter angewendet, als JPEG.
    Ohne Profil bzw. bei "original"/"kein" nur vereinheitlicht.
    Wird beim Teilen und beim Foto-Download genutzt — das Original
    bleibt unverändert gespeichert.
    """
    zeile = (db.query(SocialPostFoto, SocialPost)
             .join(SocialPost, SocialPost.id == SocialPostFoto.post_id)
             .filter(SocialPostFoto.id == foto_id,
                     SocialPost.owner_user_id == current_user.id).first())
    if not zeile:
        raise HTTPException(404, "Foto nicht gefunden")
    foto, post = zeile

    bild_format, bild_filter = "original", "kein"
    if post.profil_id:
        profil = db.query(SocialProfil).filter(SocialProfil.id == post.profil_id).first()
        if profil:
            bild_format = profil.bild_format or "original"
            bild_filter = profil.bild_filter or "kein"

    data, _ct = storage_service.download_file(
        foto.storage_key, db, backend=foto.storage_provider)
    try:
        daten, mimetype = postecke_service.bearbeite_foto(data, bild_format, bild_filter)
    except Exception:
        # Bearbeitung fehlgeschlagen (z.B. exotisches Format) -> Original liefern
        daten, mimetype = data, foto.mimetype or "image/jpeg"
    return Response(content=daten, media_type=mimetype)


@router.get("/fotos/{foto_id}")
def get_foto(
    foto_id: UUID,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    foto = (db.query(SocialPostFoto)
            .join(SocialPost, SocialPost.id == SocialPostFoto.post_id)
            .filter(SocialPostFoto.id == foto_id,
                    SocialPost.owner_user_id == current_user.id).first())
    if not foto:
        raise HTTPException(404, "Foto nicht gefunden")
    data, content_type = storage_service.download_file(
        foto.storage_key, db, backend=foto.storage_provider)
    return Response(content=data, media_type=content_type or foto.mimetype)


@router.delete("/fotos/{foto_id}", status_code=204)
def delete_foto(
    foto_id: UUID,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    foto = (db.query(SocialPostFoto)
            .join(SocialPost, SocialPost.id == SocialPostFoto.post_id)
            .filter(SocialPostFoto.id == foto_id,
                    SocialPost.owner_user_id == current_user.id).first())
    if not foto:
        raise HTTPException(404, "Foto nicht gefunden")
    post_id = foto.post_id
    storage_service.delete_file(foto.storage_key, db, backend=foto.storage_provider)
    db.delete(foto)
    db.commit()
    # Datacenter-Spiegelung nachziehen (entfernt die Kopie des gelöschten Fotos)
    post = db.query(SocialPost).filter(SocialPost.id == post_id).first()
    if post is not None:
        db.refresh(post)
        _sync_datacenter(db, post, current_user.id)
        db.commit()


# ── Video (max. eines je Post; kein Misch-Post mit Fotos) ─────────────────────
@router.post("/posts/{post_id}/video", response_model=PostResponse, status_code=201)
def upload_video(
    post_id: UUID,
    file: UploadFile = File(...),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """
    Lädt ein einzelnes Video (MP4/MOV, bis 200 MB) zu einem Post hoch. Ein Post
    ist entweder Foto- oder Video-Post — hat er bereits Fotos, wird abgelehnt.
    Ein bereits vorhandenes Video wird ersetzt.
    """
    p = _get_post(db, post_id, current_user)
    if p.fotos:
        raise HTTPException(422, "Dieser Post enthält bereits Fotos — "
                                 "Foto und Video lassen sich nicht mischen.")

    mimetype = (file.content_type or "").lower()
    if mimetype not in ERLAUBTE_VIDEO_TYPEN:
        raise HTTPException(422, "Videotyp nicht erlaubt — bitte MP4 oder MOV.")
    data = file.file.read()
    if len(data) > MAX_VIDEO_BYTES:
        raise HTTPException(422, "Video zu groß (max. 200 MB).")

    # Vorhandenes Video ersetzen (Datei + Poster + Datensatz entfernen)
    if p.video is not None:
        _loesche_video_dateien(db, p.video)
        db.delete(p.video)
        db.flush()

    video_id = uuid4()
    filename = file.filename or "video.mp4"
    storage_key = storage_service.build_storage_key(
        "postecke", str(p.id), f"{video_id}_{filename}")
    # Speicher festhalten — Video und Standbild landen gemeinsam in diesem
    # Speicher und werden später auch dort gesucht (vgl. Migration 0053).
    backend = storage_service.current_backend(db)
    storage_service.upload_file(storage_key, data, mimetype, db=db, backend=backend)

    # Standbild (erstes Frame) per ffmpeg erzeugen und ablegen — schlägt es fehl,
    # bleibt poster_key leer (Vorschau fällt dann auf den Video-Player zurück).
    poster_key = None
    endung = ".mov" if mimetype == "video/quicktime" else ".mp4"
    poster = postecke_service.erzeuge_video_poster(data, endung)
    if poster:
        poster_key = storage_service.build_storage_key(
            "postecke", str(p.id), f"{video_id}_poster.jpg")
        storage_service.upload_file(poster_key, poster, "image/jpeg", db=db, backend=backend)

    db.add(SocialPostVideo(
        id=video_id,
        post_id=p.id,
        storage_key=storage_key,
        storage_provider=backend,
        filename=filename,
        mimetype=mimetype,
        size_bytes=len(data),
        poster_key=poster_key,
    ))
    db.commit()
    db.refresh(p)
    _sync_datacenter(db, p, current_user.id)
    db.commit()
    db.refresh(p)
    return p


@router.get("/videos/{video_id}")
def get_video(
    video_id: UUID,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    video = (db.query(SocialPostVideo)
             .join(SocialPost, SocialPost.id == SocialPostVideo.post_id)
             .filter(SocialPostVideo.id == video_id,
                     SocialPost.owner_user_id == current_user.id).first())
    if not video:
        raise HTTPException(404, "Video nicht gefunden")
    data, content_type = storage_service.download_file(
        video.storage_key, db, backend=video.storage_provider)
    return Response(content=data, media_type=content_type or video.mimetype)


@router.get("/videos/{video_id}/poster")
def get_video_poster(
    video_id: UUID,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Standbild (erstes Frame) des Videos als JPEG — für die Vorschau."""
    video = (db.query(SocialPostVideo)
             .join(SocialPost, SocialPost.id == SocialPostVideo.post_id)
             .filter(SocialPostVideo.id == video_id,
                     SocialPost.owner_user_id == current_user.id).first())
    if not video or not video.poster_key:
        raise HTTPException(404, "Kein Standbild vorhanden")
    data, _ct = storage_service.download_file(
        video.poster_key, db, backend=video.storage_provider)
    return Response(content=data, media_type="image/jpeg")


@router.delete("/videos/{video_id}", status_code=204)
def delete_video(
    video_id: UUID,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    video = (db.query(SocialPostVideo)
             .join(SocialPost, SocialPost.id == SocialPostVideo.post_id)
             .filter(SocialPostVideo.id == video_id,
                     SocialPost.owner_user_id == current_user.id).first())
    if not video:
        raise HTTPException(404, "Video nicht gefunden")
    post_id = video.post_id
    _loesche_video_dateien(db, video)
    db.delete(video)
    db.commit()
    # Datacenter-Spiegelung nachziehen (entfernt die Kopie des gelöschten Videos)
    post = db.query(SocialPost).filter(SocialPost.id == post_id).first()
    if post is not None:
        db.refresh(post)
        _sync_datacenter(db, post, current_user.id)
        db.commit()
