# STATUS – DeineZeit

> Lebendes Status-/Logbuch. **Oben** der aktuelle Stand (Snapshot, wird
> überschrieben), **unten** ein chronologisches Logbuch (neue Einträge oben
> anhängen). Release-Details stehen im [CHANGELOG.md](CHANGELOG.md), das „Wie/
> Warum/Was-als-Nächstes" hier.

---

## Aktueller Stand (Snapshot)

- **Version:** **2.0.0** (Release 04.09.2026, Abschluss des Audits) — Details in `frontend/package.json` / [CHANGELOG.md](CHANGELOG.md); der pre-commit-Hook hebt die Patch-Version je Branch an
- **Branch-Modell:** Feature-Branch → PR → CI (pytest ist Pflicht) → Merge auf `main` → Deploy **nach grüner CI** (`deploy.yml`, `workflow_run`)
- **DB-Migrationsstand:** bis `0062_update_zustand_entfernen`; Modelle und Migrationen sind deckungsgleich (`tests/test_migrationen.py` wacht darüber)
- **Tests:** 961 pytest-Tests + 9 Vitest-Tests, Laufzeit in CI wenige Minuten
- **Lokale Umgebung:** Docker Compose (`docker-compose.local.yml`) → http://localhost; lokale Werte in `.env.local` (nicht im Repo)

### Module / Funktionsumfang

Zeiterfassung (mit Zeitprojekten, Berichten) · Stammdaten (inkl. Artikelstamm, Import) ·
Projektplanung (Kanban/Gantt) · Aufgaben (mit Mail-Import/KI) · Verkauf (Belege, PDF,
E-Rechnung, Zahlungen, Mahnwesen, Monatsabschluss) · Buchhaltung (Eingangsrechnungen,
UVA, BMD-Export) · Datacenter (Dateien via MinIO/WebDAV/OneDrive) · Postecke ·
Benutzerverwaltung mit Rechtegruppen, 2FA/Passkeys · Dashboard.

### Audit September 2026

Vollständiges Software-Audit am 02.09.2026 — Bericht: [docs/AUDIT-2026-09-02.md](docs/AUDIT-2026-09-02.md),
Abschlussprüfung 04.09.2026: [docs/AUDIT-2026-09-02-ABSCHLUSS.md](docs/AUDIT-2026-09-02-ABSCHLUSS.md).
Umgesetzt in Bündeln (K-01 … K-25): Backups bleiben beim Deploy erhalten und enthalten den
Dateispeicher (+ Restore-Anleitung [docs/WIEDERHERSTELLUNG.md](docs/WIEDERHERSTELLUNG.md)),
XSS-Lücke in der Datacenter-Vorschau geschlossen, Konfigurations-Geheimnisse verschlüsselt,
Endpunkte laufen im Threadpool, FastAPI/Starlette/WeasyPrint aktuell, Ortszeit statt UTC,
Setup-Token, CSP scharf, In-App-Update samt Docker-Socket gestrichen (Updates nur noch per
CI-Deploy), Worker-Sperre per Advisory-Lock, Zeit → Aufgabe verdrahtet (Bündel H).
Abschlussprüfung: [docs/AUDIT-2026-09-02-ABSCHLUSS.md](docs/AUDIT-2026-09-02-ABSCHLUSS.md);
Release-Checkliste: [docs/RELEASE-2.0.0.md](docs/RELEASE-2.0.0.md).

### Bekannte Einschränkungen

- **Kein Update-Knopf mehr:** Neue Versionen kommen ausschließlich über den CI-Deploy
  (GitHub Actions nach grüner Prüfung); von Hand am Server `sudo bash scripts/deploy.sh`.
- **Doku ist Windows-zentriert** (`.bat`/`.ps1`); Mac-Workflow steht in [CLAUDE.md](CLAUDE.md).
- **Kein Offline-Modus:** Service Worker bewusst abgeschaltet (alter Code im Cache).
- **Nur Deutsch:** Sprachwahl ausgeblendet, i18n nicht durchgezogen.
- **Excel-Import:** nur `.xlsx` (kein `.xls`).

### Nächste Schritte / To-dos

- Nach 2.0.0 (ohne Release-Druck): ~~npm-Hauptversionen~~ (erledigt 08.09.2026: react-router 7, TipTap 3, vite 8, Node 22, `npm audit` 0), K-26 — Prüfbericht: [docs/PRUEFBERICHT-NPM-2026-09-08.md](docs/PRUEFBERICHT-NPM-2026-09-08.md); K-26a gemergt 09.09.2026 (Verkauf aufgeteilt, v2.0.2), K-26a2 gemergt 09.09. (v2.0.3, Windows-Test offen), K-26b gemergt (PR #94) und am Server abgenommen 10.09. (v2.0.4), K-26c gemergt und am Server abgenommen 11.09. (Request-ID im Log, raise from, SEC-015; v2.0.5; R1-Reload-Schutz live bestätigt) — Prüfbericht: [docs/PRUEFBERICHT-K26C-2026-09-11.md](docs/PRUEFBERICHT-K26C-2026-09-11.md). Audit-Nacharbeiten damit vollständig; nächster Schritt Tiefen-Audit ab ~25.09.2026 — Prüfbericht: [docs/PRUEFBERICHT-K26B-2026-09-09.md](docs/PRUEFBERICHT-K26B-2026-09-09.md) — Prüfbericht: [docs/PRUEFBERICHT-K26A-2026-09-08.md](docs/PRUEFBERICHT-K26A-2026-09-08.md)
- **Zeiterfassung: Import aus Fremdsystemen** (18.09.2026, v2.1.0, PR #96 gemergt, Deploy #230 grün, Server-Abnahme 14.10.2026 ✅): CSV, Excel, JSON, ICS im Browser gelesen, PDF über die KI-Schnittstelle; Spaltenzuordnung → Probelauf → Prüfbericht → Import. Prüfbericht: [docs/PRUEFBERICHT-ZEITEN-IMPORT-2026-09-18.md](docs/PRUEFBERICHT-ZEITEN-IMPORT-2026-09-18.md)
  (invoice.py aufteilen, Skripte ordnen, React.lazy, aria-label/Formularfeld-IDs), OPS-006 Logging
- Branch-Schutz: „Frontend: Tests (Vitest)" als Pflicht-Check aufnehmen

---

## Logbuch

### 2026-09-02 … 09-03 – Software-Audit und Korrekturbündel A–F
- Prüfbericht `docs/AUDIT-2026-09-02.md` (45 Befunde, Korrekturplan K-01…K-26).
- Umgesetzt: K-01, A (K-22a, K-02…K-06, Migration 0060), B (K-07…K-09, Migration 0061),
  C (K-10…K-12), D (K-13, K-15, K-17, K-18), E (K-14, K-16, K-19, K-20), F (K-23, K-24, K-25).
- CI-Laufzeit des pytest-Jobs von 84 Minuten auf wenige Minuten (MinIO-Retry in Tests).

### 2026-06-27 – CI-Gate für Tests (Schritt 2)
- `ci.yml`: neuer Job „Backend: Tests (pytest)" mit Postgres-Service-Container;
  setzt `DATABASE_URL`/`TEST_DATABASE_URL`/`SECRET_KEY` und installiert pango/
  cairo (für WeasyPrint-Import). Läuft bei jedem Push und PR.
- YAML-Syntax geprüft (valide, 4 Jobs in Reihenfolge).
- `BRANCH-SCHUTZ.md` erstellt: Anleitung für Oliver, um in den GitHub-Settings
  direktes Pushen auf `main` zu sperren und grüne Tests als Merge-Pflicht zu
  setzen (Feature-Branch + PR-Workflow).
- Offen festgehalten: `deploy.yml` deployt noch ohne Test-Kopplung (Folgepunkt).
- CLAUDE.md (CI-Abschnitt) aktualisiert.

### 2026-06-27 – Teststrategie + pytest-Fundament (Schritt 1)
- `TESTSTRATEGIE.md` erstellt und mit Oliver abgestimmt; Reihenfolge angenommen
  (Backend zuerst, dann CI-Gate, dann Module, dann Frontend).
- Backend-Testgerüst angelegt: `backend/tests/conftest.py` (PostgreSQL-Test-DB,
  TestClient mit überschriebenem `get_db`, Fixtures `test_user`/`admin_user`/
  `auth_client`), `test_health.py`, `test_auth.py` (Vorlage), `tests/README.md`.
- `backend/requirements-dev.txt`, `backend/pytest.ini`, und `./test.sh`
  (Wegwerf-Test-DB im laufenden Container) hinzugefügt.
- CLAUDE.md um Test-Abschnitt + Regel „neues Modul ⇒ neuer Test" ergänzt.
- Statisch verifiziert: Python-/Bash-Syntax ok, URL-Ableitung der Test-DB ok,
  MinIO-Startup ist in try/except gekapselt (Tests laufen ohne MinIO).
- **Offen / nächster Schritt:** `./test.sh` einmal lokal am Mac ausführen und
  grün bestätigen; danach Schritt 2 (CI-Gate + Branch-Schutz).

### 2026-06-27 – Bestandsaufnahme & Projekt-Doku angelegt
- Bestandsaufnahme des Repos durchgeführt (Stack, Struktur, Workflow, CI/CD,
  Versionierung). Ordner ist die Git-Repo-Wurzel, `main` synchron mit Remote.
- **CLAUDE.md** neu erstellt: Tech-Stack, Ordnerstruktur, lokale Mac-Befehle,
  Git-/Versionierungs-Workflow, CI/CD, Konventionen.
- **STATUS.md** (diese Datei) neu erstellt: Snapshot + Logbuch.
- Festgehalten: Mac als lokale Plattform; Versionierung läuft automatisch über
  `auto-version.yml` → nicht manuell bumpen.
- **Offen / nächster Schritt:** Snapshot-Felder „Laufende Baustellen" und
  „Nächste Schritte" mit Olivers aktuellen Arbeitszielen befüllen.

<!--
Vorlage für neue Einträge (jeweils oben einfügen):

### JJJJ-MM-TT – Kurztitel
- Was wurde gemacht
- Was ist offen / nächster Schritt
-->
