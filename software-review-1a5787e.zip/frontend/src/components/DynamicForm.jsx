import { useState, useEffect, useRef } from 'react'
import { FIELD_TYPES } from './FieldBuilder'
import { masterdataApi, accountingApi, getAccessToken } from '../services/api'
import toast from 'react-hot-toast'
import { Search, X, Plus, Loader2, GitMerge, ExternalLink,
         Upload, Image as ImageIcon, Trash2 } from 'lucide-react'

/**
 * Generiert ein Formular automatisch aus den Felddefinitionen.
 * Wenn der EntityType Tabs definiert hat, werden diese als Reiter angezeigt.
 * Wird sowohl für "Neu anlegen" als auch "Bearbeiten" verwendet.
 */
const COL_CLASSES = {
  3:  'col-span-12 sm:col-span-3',
  4:  'col-span-12 sm:col-span-4',
  6:  'col-span-12 sm:col-span-6',
  9:  'col-span-12 sm:col-span-9',
  12: 'col-span-12',
}

export default function DynamicForm({ fields, tabs = [], values, onChange, disabled = false }) {
  const sorted = [...fields].sort((a, b) => a.sort_order - b.sort_order)
  const [activeTab, setActiveTab] = useState(tabs.length > 0 ? tabs[0] : null)

  // Wenn tabs sich ändern (z.B. nach Reload), aktiven Tab anpassen
  useEffect(() => {
    if (tabs.length > 0 && (!activeTab || !tabs.includes(activeTab))) {
      setActiveTab(tabs[0])
    }
    if (tabs.length === 0) setActiveTab(null)
  }, [tabs])

  const handleChange = (key, value) => {
    onChange({ ...values, [key]: value })
  }

  // Felder für aktuellen Tab filtern (oder alle wenn keine Tabs)
  const visibleFields = tabs.length > 0 && activeTab
    ? sorted.filter(f => (f.tab || tabs[0]) === activeTab)
    : sorted

  return (
    <div>
      {/* Tab-Navigation */}
      {tabs.length > 0 && (
        <div className="flex gap-0 mb-4 border-b border-gray-200">
          {tabs.map(tab => (
            <button
              key={tab}
              type="button"
              onClick={() => setActiveTab(tab)}
              className={`px-4 py-2 text-sm font-medium transition -mb-px border-b-2 ${
                activeTab === tab
                  ? 'border-primary-500 text-primary-700'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              {tab}
            </button>
          ))}
        </div>
      )}

      {/* Felder */}
      <div className="grid grid-cols-12 gap-4">
        {visibleFields.map((field) => {
          const colClass = COL_CLASSES[field.col_span] || 'col-span-12'
          return (
            <div key={field.id} className={colClass}>
              <FieldInput
                field={field}
                value={values[field.key] ?? field.default_value ?? ''}
                onChange={(val) => handleChange(field.key, val)}
                disabled={disabled}
              />
            </div>
          )
        })}
        {visibleFields.length === 0 && (
          <div className="col-span-12 py-6 text-center text-gray-400 text-sm">
            Keine Felder in diesem Register.
          </div>
        )}
      </div>
    </div>
  )
}

// ── Modal zum Anlegen eines verknüpften Datensatzes ───────────────────────────
// WICHTIG: Kein <form> verwenden – dieses Modal wird innerhalb eines äußeren
// <form> gerendert. Verschachtelte Forms sind in HTML ungültig und verursachen
// Probleme beim Speichern. Stattdessen: div + onClick auf dem Button.
function InlineCreateModal({ entityType, onClose, onCreated }) {
  const [values, setValues] = useState({})
  const [loading, setLoading] = useState(false)

  const handleSave = async () => {
    setLoading(true)
    try {
      const res = await masterdataApi.createRecord(entityType.slug, values)
      toast.success(`${res.data.display_name} wurde in „${entityType.name}" angelegt`)
      onCreated(res.data)
    } catch (err) {
      toast.error(err.response?.data?.detail || 'Fehler beim Anlegen')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="fixed inset-0 bg-black/60 z-[60] flex items-start justify-center p-4 overflow-y-auto sheet-safe">
      <div className="max-h-full overflow-y-auto bg-surface rounded-2xl shadow-2xl w-full max-w-xl my-8">
        <div className="flex items-center justify-between px-6 py-4 border-b border-neutral-100">
          <div className="flex items-center gap-2">
            <div className="p-1.5 bg-primary-50 rounded-lg">
              <GitMerge size={16} className="text-primary-600" />
            </div>
            <div>
              <h2 className="text-base font-semibold text-neutral-900">
                Neuen Eintrag in „{entityType.name}" anlegen
              </h2>
              <p className="text-xs text-neutral-400">Wird direkt in {entityType.name} gespeichert und verknüpft</p>
            </div>
          </div>
          <button aria-label="Schließen" type="button" onClick={onClose} className="p-1.5 text-neutral-400 hover:text-neutral-600 hover:bg-neutral-100 rounded-lg transition">
            <X size={18} />
          </button>
        </div>
        <div className="px-6 py-5">
          {entityType.fields.length === 0 ? (
            <p className="text-sm text-neutral-400 text-center py-4">
              Keine Felder für {entityType.name} definiert.
            </p>
          ) : (
            <DynamicForm
              fields={entityType.fields}
              values={values}
              onChange={setValues}
            />
          )}
        </div>
        <div className="flex gap-3 px-6 pb-5 border-t border-neutral-100 pt-4">
          <button type="button" onClick={onClose} className="btn-secondary flex-1 justify-center">
            Abbrechen
          </button>
          <button
            type="button"
            onClick={handleSave}
            disabled={loading || entityType.fields.length === 0}
            className="btn-primary flex-1 justify-center"
          >
            {loading ? <Loader2 size={15} className="animate-spin" /> : <Plus size={15} />}
            Anlegen & verknüpfen
          </button>
        </div>
      </div>
    </div>
  )
}

// ── Verknüpfungs-Feld ─────────────────────────────────────────────────────────
function RelationField({ field, value, onChange, disabled }) {
  const linkedSlug = field.linked_type_slug
  const [linkedEntityType, setLinkedEntityType] = useState(null)
  const [search, setSearch] = useState('')
  const [results, setResults] = useState([])
  const [isOpen, setIsOpen] = useState(false)
  const [loadingResults, setLoadingResults] = useState(false)
  const [showCreateModal, setShowCreateModal] = useState(false)
  const dropdownRef = useRef(null)

  // Gespeicherter Wert: { id, display_name } oder leer
  const selected = value && typeof value === 'object' && value.id ? value : null

  // EntityType für das Anlegen-Modal laden
  useEffect(() => {
    if (!linkedSlug) return
    masterdataApi.getType(linkedSlug)
      .then(res => setLinkedEntityType(res.data))
      .catch(() => {})
  }, [linkedSlug])

  // Datensätze suchen (mit Debounce)
  useEffect(() => {
    if (!linkedSlug || !isOpen) return
    const timer = setTimeout(async () => {
      setLoadingResults(true)
      try {
        const res = await masterdataApi.listRecords(linkedSlug, {
          search: search || undefined,
          page_size: 10,
        })
        setResults(res.data.items)
      } catch {
        setResults([])
      } finally {
        setLoadingResults(false)
      }
    }, 250)
    return () => clearTimeout(timer)
  }, [search, isOpen, linkedSlug])

  // Klick außerhalb schließt Dropdown
  useEffect(() => {
    const handler = (e) => {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target)) {
        setIsOpen(false)
      }
    }
    document.addEventListener('mousedown', handler)
    return () => document.removeEventListener('mousedown', handler)
  }, [])

  const handleSelect = (record) => {
    onChange({ id: record.id, display_name: record.display_name })
    setIsOpen(false)
    setSearch('')
  }

  const handleClear = () => {
    onChange(null)
    setSearch('')
  }

  const handleCreated = (record) => {
    onChange({ id: record.id, display_name: record.display_name })
    setShowCreateModal(false)
  }

  const baseInput = "w-full px-4 py-2.5 border border-gray-300 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-transparent transition disabled:bg-gray-50 disabled:text-gray-500"

  const label = (
    <label className="block text-sm font-medium text-gray-700 mb-1">
      {field.name}
      {field.is_required && <span className="text-red-500 ml-1">*</span>}
      {linkedEntityType && (
        <span className="ml-2 text-xs text-neutral-400 font-normal">→ {linkedEntityType.name}</span>
      )}
    </label>
  )

  if (!linkedSlug) {
    return (
      <div>
        {label}
        <div className="px-4 py-2.5 border border-dashed border-red-200 rounded-xl text-sm text-red-400">
          Kein Ziel-Typ konfiguriert
        </div>
      </div>
    )
  }

  return (
    <div>
      {label}

      {selected ? (
        // Ausgewählter Datensatz
        <div className={`flex items-center gap-2 px-3 py-2.5 border rounded-xl ${disabled ? 'bg-gray-50 border-gray-200' : 'bg-primary-50 border-primary-200'}`}>
          <GitMerge size={14} className="text-primary-500 flex-shrink-0" />
          <span className="text-sm text-primary-800 flex-1 font-medium">{selected.display_name}</span>
          {!disabled && (
            <button aria-label="Verknüpfung aufheben"
              type="button"
              onClick={handleClear}
              className="p-0.5 text-primary-400 hover:text-red-500 transition"
              title="Verknüpfung aufheben"
            >
              <X size={14} />
            </button>
          )}
        </div>
      ) : (
        // Suche + Dropdown
        <div className="space-y-1.5" ref={dropdownRef}>
          <div className="relative">
            <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 pointer-events-none" />
            <input
              type="text"
              value={search}
              onChange={(e) => { setSearch(e.target.value); setIsOpen(true) }}
              onFocus={() => setIsOpen(true)}
              placeholder={`${linkedEntityType?.name || field.name} suchen…`}
              className={`${baseInput} pl-9`}
              disabled={disabled}
            />
            {loadingResults && (
              <Loader2 size={14} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 animate-spin" />
            )}

            {/* Suchergebnis-Dropdown */}
            {isOpen && (
              <div className="absolute top-full left-0 right-0 mt-1 bg-surface border border-gray-200 rounded-xl shadow-lg z-20 overflow-hidden">
                {results.length > 0 ? (
                  <ul className="max-h-48 overflow-y-auto">
                    {results.map(record => (
                      <li key={record.id}>
                        <button
                          type="button"
                          onClick={() => handleSelect(record)}
                          className="w-full text-left px-4 py-2.5 text-sm text-gray-700 hover:bg-primary-50 hover:text-primary-700 transition flex items-center gap-2"
                        >
                          <span className="flex-1">{record.display_name}</span>
                          <ExternalLink size={12} className="text-gray-300" />
                        </button>
                      </li>
                    ))}
                  </ul>
                ) : (
                  <div className="px-4 py-3 text-sm text-gray-400 text-center">
                    {loadingResults ? 'Suche läuft…' : search ? 'Keine Ergebnisse' : 'Suchbegriff eingeben…'}
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Neu anlegen */}
          {!disabled && linkedEntityType && (
            <button
              type="button"
              onClick={() => setShowCreateModal(true)}
              className="flex items-center gap-1.5 text-xs text-primary-600 hover:text-primary-700 transition font-medium"
            >
              <Plus size={13} />
              Neu in „{linkedEntityType.name}" anlegen
            </button>
          )}
        </div>
      )}

      {/* Modal: Verknüpften Datensatz neu anlegen */}
      {showCreateModal && linkedEntityType && (
        <InlineCreateModal
          entityType={linkedEntityType}
          onClose={() => setShowCreateModal(false)}
          onCreated={handleCreated}
        />
      )}
    </div>
  )
}

// ── Auswahl aus einem Verzeichnis (Kontenplan / Artikelgruppen) ───────────────
//
// Unterschied zur Verknüpfung: Gespeichert wird der fachliche Schlüssel selbst
// — die Kontonummer bzw. der Gruppenkurzschlüssel —, nicht {id, display_name}.
// So kann die Belegposition ihn unverändert übernehmen und der BMD-Export ihn
// direkt schreiben, ohne den Stammsatz nachzuschlagen.
//
// Die Verzeichnisse werden je Feld einmal geladen und sind klein (Kontenplan
// ~25 Zeilen, Artikelgruppen eine Handvoll) — deshalb ein einfaches select
// statt einer Suche mit Nachladen.
function LookupField({ field, value, onChange, disabled }) {
  const [eintraege, setEintraege] = useState([])
  const [laedt, setLaedt] = useState(true)

  useEffect(() => {
    let abgebrochen = false
    ;(async () => {
      setLaedt(true)
      try {
        if (field.lookup_source === 'konten') {
          const res = await accountingApi.listAccounts({ active_only: true })
          if (!abgebrochen) setEintraege(res.data.map(k => ({
            key: k.nr, label: `${k.nr} — ${k.name}`, typ: k.typ,
          })))
        } else if (field.lookup_source === 'artikelgruppen') {
          const res = await masterdataApi.listArticleGroups({ active_only: true })
          if (!abgebrochen) setEintraege(res.data.map(g => ({
            key: g.nr, label: `${g.nr} — ${g.name}`,
          })))
        } else {
          if (!abgebrochen) setEintraege([])
        }
      } catch {
        if (!abgebrochen) setEintraege([])
      } finally {
        if (!abgebrochen) setLaedt(false)
      }
    })()
    return () => { abgebrochen = true }
  }, [field.lookup_source])

  const baseInput = "w-full px-4 py-2.5 border border-gray-300 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-transparent transition disabled:bg-gray-50 disabled:text-gray-500"

  // Ein gespeicherter Wert, den es im Verzeichnis nicht (mehr) gibt, darf nicht
  // stillschweigend verschwinden: Sonst würde das Feld beim nächsten Speichern
  // geleert, ohne dass jemand es angefasst hat.
  const unbekannt = value && !laedt && !eintraege.some(e => e.key === value)

  return (
    <div>
      <label className="block text-sm font-medium text-gray-700 mb-1">
        {field.name}
        {field.is_required && <span className="text-red-500 ml-1">*</span>}
      </label>
      <select
        value={value || ''}
        onChange={(e) => onChange(e.target.value)}
        disabled={disabled || laedt}
        required={field.is_required}
        className={`${baseInput} appearance-none bg-surface`}
      >
        <option value="">{laedt ? 'lädt…' : '— keine Vorgabe —'}</option>
        {unbekannt && <option value={value}>{value} (nicht im Verzeichnis)</option>}
        {eintraege.map(e => <option key={e.key} value={e.key}>{e.label}</option>)}
      </select>
      {unbekannt && (
        <p className="text-xs text-amber-600 mt-1">
          „{value}“ steht nicht (mehr) im Verzeichnis — bitte prüfen.
        </p>
      )}
    </div>
  )
}

// ── Bild am Datensatz ─────────────────────────────────────────────────────────
//
// Gespeichert wird { key, provider, name }. Der Provider muss mit: Nach einem
// Wechsel des Speicherziels liegen ältere Bilder weiter im alten Speicher —
// ohne die Angabe würde am falschen Ort gesucht (Lehre aus Migration 0039).
function ImageField({ field, value, onChange, disabled }) {
  const [vorschau, setVorschau] = useState(null)
  const [laeuft, setLaeuft] = useState(false)
  const dateiRef = useRef(null)
  const bild = value && typeof value === 'object' && value.key ? value : null

  // Ein <img src="/api/…"> schickt keinen Anmelde-Token mit und bekäme 401.
  // Deshalb per fetch holen und als Objekt-URL einhängen — dasselbe Muster wie
  // beim Positionsbild im Beleg.
  useEffect(() => {
    if (!bild) { setVorschau(null); return }
    let url = null
    let abgebrochen = false
    ;(async () => {
      try {
        const res = await fetch(masterdataApi.bildUrl(bild.key, bild.provider),
                                { headers: { Authorization: 'Bearer ' + getAccessToken() } })
        if (!res.ok) throw new Error(res.status)
        const blob = await res.blob()
        if (abgebrochen) return
        url = URL.createObjectURL(blob)
        setVorschau(url)
      } catch { setVorschau(null) }
    })()
    return () => { abgebrochen = true; if (url) URL.revokeObjectURL(url) }
  }, [bild?.key, bild?.provider])

  async function hochladen(datei) {
    if (!datei) return
    setLaeuft(true)
    try {
      const res = await masterdataApi.uploadBild(datei, 'gross')
      onChange({ key: res.data.key, provider: res.data.provider, name: res.data.name })
      toast.success('Bild hinterlegt')
    } catch (e) {
      toast.error(e.response?.data?.detail || 'Upload fehlgeschlagen')
    } finally {
      setLaeuft(false)
      if (dateiRef.current) dateiRef.current.value = ''
    }
  }

  return (
    <div>
      <label className="block text-sm font-medium text-gray-700 mb-1">
        {field.name}
        {field.is_required && <span className="text-red-500 ml-1">*</span>}
      </label>
      <div className="flex items-start gap-3">
        <div className="w-28 h-28 rounded-xl border border-dashed border-gray-300 bg-gray-50 flex items-center justify-center overflow-hidden flex-shrink-0">
          {vorschau
            ? <img src={vorschau} alt={bild?.name || field.name} className="max-w-full max-h-full object-contain" />
            : <ImageIcon size={22} className="text-gray-300" />}
        </div>
        <div className="flex-1 space-y-2">
          <input ref={dateiRef} type="file" accept="image/*" disabled={disabled || laeuft}
                 onChange={(e) => hochladen(e.target.files?.[0])}
                 className="hidden" id={`bild-${field.id}`} />
          <label htmlFor={`bild-${field.id}`}
                 className={`inline-flex items-center gap-1.5 px-3 py-1.5 text-xs rounded-lg border transition ${
                   disabled || laeuft
                     ? 'border-gray-200 text-gray-300 cursor-not-allowed'
                     : 'border-gray-300 text-gray-600 hover:bg-gray-50 cursor-pointer'
                 }`}>
            {laeuft ? <Loader2 size={13} className="animate-spin" /> : <Upload size={13} />}
            {bild ? 'Bild ersetzen' : 'Bild wählen'}
          </label>
          {bild && !disabled && (
            <button type="button" onClick={() => onChange(null)}
              className="ml-2 inline-flex items-center gap-1.5 px-3 py-1.5 text-xs text-neutral-500 hover:text-red-600 transition">
              <Trash2 size={13} /> Entfernen
            </button>
          )}
          <p className="text-[11px] text-gray-400">
            JPEG, PNG, WebP oder GIF, höchstens 15 MB. Das Bild wird beim
            Hochladen verkleinert.
          </p>
        </div>
      </div>
    </div>
  )
}

// ── Einzelnes Feld rendern ────────────────────────────────────────────────────
function FieldInput({ field, value, onChange, disabled }) {
  const TypeInfo = FIELD_TYPES.find(t => t.key === field.field_type)
  const Icon = TypeInfo?.icon

  const baseInput = "w-full px-4 py-2.5 border border-gray-300 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-transparent transition disabled:bg-gray-50 disabled:text-gray-500"

  const label = (
    <label className="block text-sm font-medium text-gray-700 mb-1">
      {field.name}
      {field.is_required && <span className="text-red-500 ml-1">*</span>}
    </label>
  )

  switch (field.field_type) {
    case 'relation':
      return (
        <RelationField
          field={field}
          value={value}
          onChange={onChange}
          disabled={disabled}
        />
      )

    case 'lookup':
      return <LookupField field={field} value={value} onChange={onChange} disabled={disabled} />

    case 'image':
      return <ImageField field={field} value={value} onChange={onChange} disabled={disabled} />

    case 'textarea':
      return (
        <div>
          {label}
          <textarea
            value={value}
            onChange={(e) => onChange(e.target.value)}
            disabled={disabled}
            required={field.is_required}
            placeholder={field.placeholder || ''}
            rows={3}
            className={`${baseInput} resize-y`}
          />
        </div>
      )

    case 'checkbox':
      return (
        <div className="flex items-center gap-3">
          <input
            type="checkbox"
            checked={!!value}
            onChange={(e) => onChange(e.target.checked)}
            disabled={disabled}
            className="w-5 h-5 rounded accent-primary-600"
            id={`field-${field.id}`}
          />
          <label htmlFor={`field-${field.id}`} className="text-sm font-medium text-gray-700 cursor-pointer">
            {field.name}
            {field.is_required && <span className="text-red-500 ml-1">*</span>}
          </label>
        </div>
      )

    case 'dropdown':
      return (
        <div>
          {label}
          <select
            value={value}
            onChange={(e) => onChange(e.target.value)}
            disabled={disabled}
            required={field.is_required}
            className={`${baseInput} appearance-none bg-surface`}
          >
            <option value="">— bitte wählen —</option>
            {(field.options || []).map((opt) => (
              <option key={opt} value={opt}>{opt}</option>
            ))}
          </select>
        </div>
      )

    case 'number':
      return (
        <div>
          {label}
          <input
            type="number"
            value={value}
            onChange={(e) => onChange(e.target.value)}
            disabled={disabled}
            required={field.is_required}
            placeholder={field.placeholder || '0'}
            step="any"
            className={baseInput}
          />
        </div>
      )

    case 'date':
      return (
        <div>
          {label}
          <input
            type="date"
            value={value}
            onChange={(e) => onChange(e.target.value)}
            disabled={disabled}
            required={field.is_required}
            className={baseInput}
          />
        </div>
      )

    case 'email':
      return (
        <div>
          {label}
          <input
            type="email"
            value={value}
            onChange={(e) => onChange(e.target.value)}
            disabled={disabled}
            required={field.is_required}
            placeholder={field.placeholder || 'name@firma.at'}
            className={baseInput}
          />
        </div>
      )

    case 'phone':
      return (
        <div>
          {label}
          <input
            type="tel"
            value={value}
            onChange={(e) => onChange(e.target.value)}
            disabled={disabled}
            required={field.is_required}
            placeholder={field.placeholder || '+43 1 234 567'}
            className={baseInput}
          />
        </div>
      )

    case 'url':
      return (
        <div>
          {label}
          <input
            type="url"
            value={value}
            onChange={(e) => onChange(e.target.value)}
            disabled={disabled}
            required={field.is_required}
            placeholder={field.placeholder || 'https://'}
            className={baseInput}
          />
        </div>
      )

    default: // text
      return (
        <div>
          {label}
          <div className="relative">
            {Icon && (
              <Icon size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 pointer-events-none" />
            )}
            <input
              type="text"
              value={value}
              onChange={(e) => onChange(e.target.value)}
              disabled={disabled}
              required={field.is_required}
              placeholder={field.placeholder || ''}
              className={`${baseInput} ${Icon ? 'pl-9' : ''}`}
            />
          </div>
        </div>
      )
  }
}
