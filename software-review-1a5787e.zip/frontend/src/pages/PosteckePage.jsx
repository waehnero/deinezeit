import { useState, useEffect, useRef, useCallback, useMemo } from 'react'
import PageHeader from '../components/PageHeader'
import Fab from '../components/Fab'
import {
  Plus, Loader2, X, Megaphone, Sparkles, Camera, Trash2, Pencil,
  Send, CalendarClock, Inbox, Copy, Check, Settings2,
  ChevronLeft, RefreshCw, MapPin, Smile, Bell,
  List, Columns, CalendarDays, Search, Archive, ArchiveRestore, Info, Film,
} from 'lucide-react'
import toast from 'react-hot-toast'
import { posteckeApi } from '../services/api'
import FotoThumb from '../components/PosteckeFotoThumb'
import VideoVorschau from '../components/PosteckeVideoVorschau'
import VideoThumb from '../components/PosteckeVideoThumb'
import PosteckeKanban from '../components/PosteckeKanban'
import PosteckeKalender from '../components/PosteckeKalender'
import ContactSearch from '../components/ContactSearch'
import { useAuth } from '../contexts/AuthContext'

/* ─────────────────────────────────────────────────────────────────────────────
 * Postecke – Etappe 1: Mobile Erfassung, KI-Vorschlag, assistiertes Posten
 * Kanban-/Kalenderansicht folgt in Etappe 2 (gleiche Datenbasis).
 * ──────────────────────────────────────────────────────────────────────────── */

const KANAELE = [
  { id: 'facebook_privat', label: 'Facebook privat',          url: 'https://www.facebook.com/' },
  { id: 'facebook_seite',  label: 'Facebook-Seite',           url: 'https://www.facebook.com/' },
  { id: 'instagram',       label: 'Instagram',                url: 'https://www.instagram.com/' },
  { id: 'linkedin',        label: 'LinkedIn',                 url: 'https://www.linkedin.com/feed/' },
  { id: 'tiktok',          label: 'TikTok',                   url: 'https://www.tiktok.com/' },
  { id: 'youtube',         label: 'YouTube',                  url: 'https://studio.youtube.com/' },
  { id: 'whatsapp',        label: 'WhatsApp (Status/Kanal)',  url: 'https://web.whatsapp.com/' },
  { id: 'x',               label: 'X (Twitter)',              url: 'https://x.com/' },
  { id: 'threads',         label: 'Threads',                  url: 'https://www.threads.net/' },
  { id: 'google_business', label: 'Google Unternehmensprofil', url: 'https://business.google.com/' },
  { id: 'pinterest',       label: 'Pinterest',                url: 'https://www.pinterest.com/' },
  { id: 'sonstige',        label: 'Sonstige',                 url: '' },
]
const kanalInfo = (id) =>
  KANAELE.find(k => k.id === id) || KANAELE[KANAELE.length - 1]

// Einrichtungshilfe je Kanal (Infokasten im Profil-Formular). Erklärt, ob der
// Kanal direkt angebunden werden kann oder nur assistiert bespielt wird, und
// nennt beim Facebook-Seiten-Kanal die Kurzschritte zum Token (Details:
// FACEBOOK-SEITE-ANBINDEN.md). Rest fällt auf den assistierten Weg zurück.
const KANAL_HILFE = {
  facebook_seite: {
    modus: 'Direktanbindung möglich',
    intro: 'Automatisches Veröffentlichen und Planen. Du brauchst zwei Angaben: '
      + 'die Seiten-ID und einen langlebigen Page-Access-Token.',
    schritte: [
      'Auf developers.facebook.com eine App anlegen (Typ „Business", im '
        + 'Entwicklermodus — kein App-Review nötig).',
      'Im Graph API Explorer einen Nutzer-Token mit den Berechtigungen '
        + 'pages_show_list, pages_read_engagement und pages_manage_posts erzeugen '
        + 'und dabei die Seite anhaken.',
      'Die Abfrage „me/accounts" senden: access_token = Page-Access-Token, '
        + 'id = Seiten-ID.',
      'Beides unten im Kasten „Direktanbindung" eintragen, speichern und auf '
        + '„Verbindung testen" klicken.',
    ],
    fuss: 'Ausführliche Anleitung: FACEBOOK-SEITE-ANBINDEN.md im Projektordner.',
  },
  facebook_privat: {
    modus: 'Nur assistiert (Meta-Vorgabe)',
    intro: 'Für private Profile erlaubt Facebook seit 2018 keine automatische '
      + 'Veröffentlichung. DeineZeit bereitet Text, Hashtags und Fotos vor und '
      + 'öffnet Facebook — den letzten Klick zum Posten machst Du selbst.',
  },
  instagram: {
    modus: 'Direktanbindung möglich',
    intro: 'Automatisches Veröffentlichen und Planen. Voraussetzung: ein '
      + 'Instagram-Professionell-Konto (Business oder Creator), das mit einer '
      + 'Facebook-Seite verknüpft ist. Du brauchst zwei Angaben: die '
      + 'Instagram-Konto-ID und einen Access-Token.',
    schritte: [
      'Instagram-Konto auf „Professionell" umstellen und in den Facebook-'
        + 'Seiteneinstellungen mit Deiner Seite verknüpfen.',
      'Dieselbe Meta-App wie für die Facebook-Seite verwenden; im Graph API '
        + 'Explorer einen Token mit instagram_basic, instagram_content_publish '
        + 'und pages_show_list erzeugen.',
      'Die Konto-ID über „me/accounts?fields=instagram_business_account" abfragen.',
      'Konto-ID und Access-Token unten im Kasten „Direktanbindung" eintragen, '
        + 'speichern und „Verbindung testen".',
    ],
    fuss: 'Ausführliche Anleitung: INSTAGRAM-ANBINDEN.md im Projektordner.',
  },
}
const KANAL_HILFE_ASSISTIERT = {
  modus: 'Assistiert',
  intro: 'Text und Hashtags werden in die Zwischenablage kopiert und der Kanal '
    + 'wird geöffnet. Du fügst den Beitrag ein und veröffentlichst ihn selbst; '
    + 'Fotos lädst Du im geöffneten Kanal hoch.',
}
const kanalHilfe = (id) => KANAL_HILFE[id] || KANAL_HILFE_ASSISTIERT

// Bild-Parameter je Profil (siehe Backend BILD_FORMATE / BILD_FILTER)
const BILD_FORMATE = [
  { id: 'original', label: 'Original (kein Zuschnitt)' },
  { id: '1:1',      label: '1:1 Quadrat (empfohlen)' },
  { id: '4:5',      label: '4:5 Hochformat (Insta-Feed)' },
  { id: '16:9',     label: '16:9 Querformat' },
  { id: '9:16',     label: '9:16 Story/Reel' },
]
const BILD_FILTER = [
  { id: 'kein',     label: 'Kein Filter' },
  { id: 'brillant', label: 'Brillant (Auto-Kontrast + Farbe)' },
  { id: 'warm',     label: 'Warm' },
  { id: 'kuehl',    label: 'Kühl' },
  { id: 'kontrast', label: 'Kontrast+' },
  { id: 'sw',       label: 'Schwarz-Weiß' },
]

const STATUS_META = {
  entwurf:         { label: 'Entwurf',        badge: 'bg-neutral-100 text-neutral-600' },
  kontrolle:       { label: 'Zur Kontrolle',  badge: 'bg-amber-100 text-amber-700' },
  geplant:         { label: 'Geplant',        badge: 'bg-primary-50 text-primary-700' },
  veroeffentlicht: { label: 'Veröffentlicht', badge: 'bg-green-100 text-green-700' },
  archiviert:      { label: 'Archiv',         badge: 'bg-neutral-100 text-neutral-400' },
}

function datumZeit(iso) {
  if (!iso) return ''
  const d = new Date(iso)
  return d.toLocaleDateString('de-AT', { weekday: 'short', day: '2-digit', month: '2-digit' }) +
    ' ' + d.toLocaleTimeString('de-AT', { hour: '2-digit', minute: '2-digit' })
}

/** Kompletten Posttext (Text + Hashtags) zusammensetzen */
function postText(post) {
  return [post.text || '', post.hashtags || ''].filter(Boolean).join('\n\n')
}

/* Meta-Prompt: erzeugt in Claude (o.ä.) aus eigenen Beispiel-Posts einen
 * maßgeschneiderten Stil-Prompt, den man anschließend ins Stil-Feld einsetzt. */
const PROMPT_GENERATOR = `Du bist ein Experte für Stilanalyse und Prompt-Engineering.

AUFGABE:
1. Analysiere die folgenden BEISPIELE meiner eigenen Inhalte (Posts/Texte).
2. Extrahiere meinen einzigartigen Schreibstil.
3. Erstelle daraus einen fertigen, wiederverwendbaren Stil-Prompt, mit dem eine
   KI neue Beiträge im GLEICHEN Stil schreiben kann.

BEISPIELE ZUM ANALYSIEREN:
[HIER 5-10 DEINER BESTEN BEISPIELE EINFÜGEN – gerne kurze UND lange, private UND offizielle]

--- Beispiel 1 ---
[Text]

--- Beispiel 2 ---
[Text]

...

ANALYSIERE DABEI:
- Tonalität: Welches Gefühl vermittelt die Stimme (warm, formal, humorvoll, direkt)?
  Wird "ich" verwendet? Werden andere Menschen gewürdigt?
- Struktur: Aufbau (Hook → Details → Abschluss?), Satz- und Absatzlänge, wiederkehrende Muster.
- Wortschatz & Phrasen: Lieblingswörter/-wendungen; Begriffe, die NIE vorkommen; formal vs. locker.
- Formatierung: Absatzlänge, Zeilenumbrüche, Großschreibung, Sonderzeichen.
- Emojis & visuelle Elemente: welche, wie häufig, wie viele pro Post; Listen; Hashtags (viele/wenige/keine).
- Längen-Variabilität: kurze vs. lange Posts, Durchschnittslänge, welche Länge für welchen Anlass.
- Themen: typische Themen, Kategorien (privat/offiziell), Call-to-Action, Fokus auf Menschen oder Fakten.

FASSE ZUSAMMEN:
- 3-5 Kerncharakteristiken und 1-2 einzigartige Erkennungsmerkmale.
- Was wird bewusst NICHT gemacht (Tabus, vermiedene Fehler)?

GIB MIR ALS ERGEBNIS EINEN FERTIGEN STIL-PROMPT MIT:
- Tonalität & Charakter (mit Beispielsätzen, wie die Stimme klingt)
- Lieblingswörter & Phrasen (und was NICHT verwendet wird)
- Standard-Struktur eines Posts (Eröffnung, Hauptteil, Kernbotschaft/Dank, CTA/Wünsche)
- Sprachliche Eigenheiten (Satz-/Absatzlänge, Grammatik)
- Emoji-Richtlinien (welche, wie häufig, max. pro Post)
- Hashtag-Richtlinien
- Kurze Checkliste (5-7 Punkte), damit der Output authentisch bleibt

Gib den Stil-Prompt als zusammenhängenden, copy-paste-fertigen Text aus.`

/* ── Profilverwaltung ────────────────────────────────────────────────────────── */

/** Infokasten mit der Einrichtungshilfe zum gewählten Kanal. */
function KanalEinrichtungshilfe({ kanalId }) {
  const h = kanalHilfe(kanalId)
  return (
    <div className="rounded-lg border border-neutral-200 bg-neutral-50 p-3 flex gap-2.5">
      <Info size={15} className="text-primary-600 shrink-0 mt-0.5" />
      <div className="space-y-1.5 text-[12px] leading-relaxed text-neutral-600">
        <p className="font-medium text-neutral-700">So richtest Du diesen Kanal ein — {h.modus}</p>
        <p>{h.intro}</p>
        {h.schritte && (
          <ol className="list-decimal ml-4 space-y-0.5">
            {h.schritte.map((s, i) => <li key={i}>{s}</li>)}
          </ol>
        )}
        {h.fuss && <p className="text-[11px] text-neutral-400">{h.fuss}</p>}
      </div>
    </div>
  )
}

function ProfilForm({ profil, onSave, onCancel }) {
  const [name, setName] = useState(profil?.name || '')
  const [kanal, setKanal] = useState(profil?.kanal || 'facebook_privat')
  const [stil, setStil] = useState(profil?.stil_prompt || '')
  const [bildFormat, setBildFormat] = useState(profil?.bild_format || 'original')
  const [bildFilter, setBildFilter] = useState(profil?.bild_filter || 'kein')
  // Direktanbindung: Zugangsdaten (werden verschlüsselt gespeichert)
  const [seiteId, setSeiteId] = useState('')          // Facebook-Seite: Seiten-ID
  const [seiteToken, setSeiteToken] = useState('')    // Facebook-Seite: Page-Access-Token
  const [igUserId, setIgUserId] = useState('')        // Instagram: Konto-ID (ig_user_id)
  const [igToken, setIgToken] = useState('')          // Instagram: Access-Token
  const [testeVerb, setTesteVerb] = useState(false)
  const [saving, setSaving] = useState(false)

  const speichern = async () => {
    if (!name.trim()) { toast.error('Bitte einen Namen angeben'); return }
    // Zugang je Kanal zusammenstellen; nur mitschicken, wenn beide Felder gefüllt
    // (leer = unverändert lassen).
    let zugang = null
    if (kanal === 'facebook_seite') {
      if ((seiteId.trim() && !seiteToken.trim()) || (!seiteId.trim() && seiteToken.trim())) {
        toast.error('Bitte Seiten-ID UND Token angeben (oder beides leer lassen)'); return
      }
      if (seiteId.trim() && seiteToken.trim())
        zugang = { page_id: seiteId.trim(), page_token: seiteToken.trim() }
    } else if (kanal === 'instagram') {
      if ((igUserId.trim() && !igToken.trim()) || (!igUserId.trim() && igToken.trim())) {
        toast.error('Bitte Konto-ID UND Token angeben (oder beides leer lassen)'); return
      }
      if (igUserId.trim() && igToken.trim())
        zugang = { ig_user_id: igUserId.trim(), ig_token: igToken.trim() }
    }
    setSaving(true)
    try {
      await onSave({
        name: name.trim(), kanal, stil_prompt: stil.trim() || null,
        bild_format: bildFormat, bild_filter: bildFilter,
        zugang,
      })
    } finally { setSaving(false) }
  }

  const promptGeneratorKopieren = async () => {
    try {
      await navigator.clipboard.writeText(PROMPT_GENERATOR)
      toast.success('Prompt-Generator kopiert — in Claude einfügen, Beispiele ergänzen, Ergebnis hier einsetzen')
    } catch {
      toast.error('Zwischenablage nicht verfügbar — bitte manuell kopieren')
    }
  }

  const verbindungTesten = async () => {
    if (!profil?.id) return
    setTesteVerb(true)
    try {
      const res = await posteckeApi.testeVerbindung(profil.id)
      if (res.data.ok) toast.success(res.data.message)
      else toast.error(res.data.message)
    } catch (e) {
      toast.error(e.response?.data?.detail || 'Verbindungstest fehlgeschlagen')
    } finally { setTesteVerb(false) }
  }

  return (
    <div className="bg-surface rounded-xl border border-neutral-200 p-4 space-y-3">
      <div>
        <label className="text-xs font-medium text-neutral-500">Name</label>
        <input value={name} onChange={e => setName(e.target.value)}
          placeholder="z.B. Facebook privat Oliver"
          className="mt-1 w-full px-3 py-2 rounded-lg border border-neutral-200 text-sm focus:outline-none focus:ring-2 focus:ring-primary-200" />
      </div>
      <div>
        <label className="text-xs font-medium text-neutral-500">Kanal</label>
        <select value={kanal} onChange={e => setKanal(e.target.value)}
          className="mt-1 w-full px-3 py-2 rounded-lg border border-neutral-200 text-sm bg-surface focus:outline-none focus:ring-2 focus:ring-primary-200">
          {KANAELE.map(k => <option key={k.id} value={k.id}>{k.label}</option>)}
        </select>
      </div>
      <KanalEinrichtungshilfe kanalId={kanal} />
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        <div>
          <label className="text-xs font-medium text-neutral-500">Bildformat (Ausspielung)</label>
          <select value={bildFormat} onChange={e => setBildFormat(e.target.value)}
            className="mt-1 w-full px-3 py-2 rounded-lg border border-neutral-200 text-sm bg-surface focus:outline-none focus:ring-2 focus:ring-primary-200">
            {BILD_FORMATE.map(f => <option key={f.id} value={f.id}>{f.label}</option>)}
          </select>
        </div>
        <div>
          <label className="text-xs font-medium text-neutral-500">Foto-Filter</label>
          <select value={bildFilter} onChange={e => setBildFilter(e.target.value)}
            className="mt-1 w-full px-3 py-2 rounded-lg border border-neutral-200 text-sm bg-surface focus:outline-none focus:ring-2 focus:ring-primary-200">
            {BILD_FILTER.map(f => <option key={f.id} value={f.id}>{f.label}</option>)}
          </select>
        </div>
        <p className="sm:col-span-2 text-[11px] text-neutral-400 -mt-1">
          Wird beim Teilen/Herunterladen auf alle Fotos dieses Profils angewendet
          (mittiger Zuschnitt) — die Originale bleiben erhalten.
        </p>
      </div>
      {kanal === 'facebook_seite' && (
        <div className="rounded-lg border border-primary-100 bg-primary-50/40 p-3 space-y-2">
          <p className="text-xs font-medium text-neutral-700">
            Direktanbindung — automatisches Posten &amp; Planen
            {profil?.has_zugang && (
              <span className="ml-2 text-[11px] px-2 py-0.5 rounded-full bg-green-100 text-green-700">verbunden</span>
            )}
          </p>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            <input value={seiteId} onChange={e => setSeiteId(e.target.value)}
              placeholder={profil?.has_zugang ? 'Seiten-ID (leer = unverändert)' : 'Seiten-ID'}
              className="w-full px-3 py-2 rounded-lg border border-neutral-200 text-sm focus:outline-none focus:ring-2 focus:ring-primary-200" />
            <input value={seiteToken} onChange={e => setSeiteToken(e.target.value)} type="password"
              placeholder={profil?.has_zugang ? 'Page-Access-Token (leer = unverändert)' : 'Page-Access-Token'}
              className="w-full px-3 py-2 rounded-lg border border-neutral-200 text-sm focus:outline-none focus:ring-2 focus:ring-primary-200" />
          </div>
          <div className="flex items-center justify-between gap-2 flex-wrap">
            <p className="text-[11px] text-neutral-500">
              Anleitung: FACEBOOK-SEITE-ANBINDEN.md im Projektordner — Meta-App im
              Entwicklermodus genügt, kein App-Review nötig.
            </p>
            {profil?.has_zugang && (
              <button type="button" onClick={verbindungTesten} disabled={testeVerb}
                className="text-xs px-3 py-1.5 rounded-lg border border-neutral-200 bg-surface text-neutral-600 hover:border-primary-300 flex items-center gap-1.5">
                {testeVerb && <Loader2 size={12} className="animate-spin" />} Verbindung testen
              </button>
            )}
          </div>
        </div>
      )}
      {kanal === 'instagram' && (
        <div className="rounded-lg border border-primary-100 bg-primary-50/40 p-3 space-y-2">
          <p className="text-xs font-medium text-neutral-700">
            Direktanbindung — automatisches Posten &amp; Planen
            {profil?.has_zugang && (
              <span className="ml-2 text-[11px] px-2 py-0.5 rounded-full bg-green-100 text-green-700">verbunden</span>
            )}
          </p>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            <input value={igUserId} onChange={e => setIgUserId(e.target.value)}
              placeholder={profil?.has_zugang ? 'Instagram-Konto-ID (leer = unverändert)' : 'Instagram-Konto-ID'}
              className="w-full px-3 py-2 rounded-lg border border-neutral-200 text-sm focus:outline-none focus:ring-2 focus:ring-primary-200" />
            <input value={igToken} onChange={e => setIgToken(e.target.value)} type="password"
              placeholder={profil?.has_zugang ? 'Access-Token (leer = unverändert)' : 'Access-Token'}
              className="w-full px-3 py-2 rounded-lg border border-neutral-200 text-sm focus:outline-none focus:ring-2 focus:ring-primary-200" />
          </div>
          <div className="flex items-center justify-between gap-2 flex-wrap">
            <p className="text-[11px] text-neutral-500">
              Anleitung: INSTAGRAM-ANBINDEN.md im Projektordner — Professionell-Konto
              mit einer Facebook-Seite verknüpft, gleiche Meta-App wie bei der FB-Seite.
            </p>
            {profil?.has_zugang && (
              <button type="button" onClick={verbindungTesten} disabled={testeVerb}
                className="text-xs px-3 py-1.5 rounded-lg border border-neutral-200 bg-surface text-neutral-600 hover:border-primary-300 flex items-center gap-1.5">
                {testeVerb && <Loader2 size={12} className="animate-spin" />} Verbindung testen
              </button>
            )}
          </div>
        </div>
      )}
      <div>
        <div className="flex items-center justify-between gap-2">
          <label className="text-xs font-medium text-neutral-500">
            Stil &amp; Redensart (Vorgabe für die KI)
          </label>
          <button type="button" onClick={promptGeneratorKopieren}
            className="text-[11px] px-2 py-1 rounded-lg border border-neutral-200 bg-surface text-neutral-600 hover:border-primary-300 flex items-center gap-1.5 shrink-0">
            <Copy size={12} /> Prompt-Generator kopieren
          </button>
        </div>
        <textarea value={stil} onChange={e => setStil(e.target.value)} rows={4}
          placeholder="z.B. Locker und persönlich, per Du, gerne Emojis, kurze Sätze, regionaler Bezug zu Ebreichsdorf …"
          className="mt-1 w-full px-3 py-2 rounded-lg border border-neutral-200 text-sm focus:outline-none focus:ring-2 focus:ring-primary-200" />
        <p className="mt-1 text-[11px] text-neutral-400">
          Tipp: „Prompt-Generator kopieren" → in Claude einfügen und 5–10 eigene Beispiel-Posts ergänzen →
          den erzeugten Stil-Prompt hier einsetzen.
        </p>
      </div>
      <div className="flex gap-2 justify-end">
        <button onClick={onCancel}
          className="px-3 py-2 rounded-lg text-sm text-neutral-600 hover:bg-neutral-100">Abbrechen</button>
        <button onClick={speichern} disabled={saving}
          className="px-4 py-2 rounded-lg text-sm font-medium bg-primary-600 text-white hover:bg-primary-700 disabled:opacity-50 flex items-center gap-2">
          {saving && <Loader2 size={14} className="animate-spin" />} Speichern
        </button>
      </div>
    </div>
  )
}

function ProfilVerwaltung({ profile, onReload, onClose }) {
  const [bearbeite, setBearbeite] = useState(null)   // null | 'neu' | profil
  const speichern = async (data) => {
    try {
      if (bearbeite === 'neu') await posteckeApi.createProfil(data)
      else await posteckeApi.updateProfil(bearbeite.id, data)
      toast.success('Profil gespeichert')
      setBearbeite(null)
      onReload()
    } catch (e) {
      toast.error(e.response?.data?.detail || 'Speichern fehlgeschlagen')
    }
  }
  const loeschen = async (p) => {
    if (!window.confirm(`Profil „${p.name}" löschen? Vorhandene Posts bleiben erhalten.`)) return
    try {
      await posteckeApi.deleteProfil(p.id)
      toast.success('Profil gelöscht')
      onReload()
    } catch { toast.error('Löschen fehlgeschlagen') }
  }

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <button onClick={onClose} className="flex items-center gap-1 text-sm text-neutral-500 hover:text-neutral-800">
          <ChevronLeft size={16} /> Zurück zu den Posts
        </button>
        {bearbeite === null && (
          <button onClick={() => setBearbeite('neu')}
            className="flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-medium bg-primary-600 text-white hover:bg-primary-700">
            <Plus size={15} /> Neues Profil
          </button>
        )}
      </div>

      {bearbeite !== null && (
        <ProfilForm profil={bearbeite === 'neu' ? null : bearbeite}
          onSave={speichern} onCancel={() => setBearbeite(null)} />
      )}

      {profile.length === 0 && bearbeite === null && (
        <div className="text-center py-10 text-neutral-400 text-sm">
          Noch keine Profile. Lege je Social-Media-Konto ein Profil mit Stil-Vorgaben an —
          die KI nutzt sie für passende Vorschläge.
        </div>
      )}

      {profile.map(p => (
        <div key={p.id} className="bg-surface rounded-xl border border-neutral-200 p-4 flex items-start gap-3">
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2">
              <span className="font-medium text-sm text-neutral-900">{p.name}</span>
              <span className="text-[11px] px-2 py-0.5 rounded-full bg-primary-50 text-primary-700">
                {kanalInfo(p.kanal).label}
              </span>
              {!p.is_active && (
                <span className="text-[11px] px-2 py-0.5 rounded-full bg-neutral-100 text-neutral-500">inaktiv</span>
              )}
            </div>
            {p.stil_prompt && (
              <p className="text-xs text-neutral-500 mt-1 line-clamp-2">{p.stil_prompt}</p>
            )}
          </div>
          <button onClick={() => setBearbeite(p)} title="Bearbeiten"
            className="p-1.5 rounded-lg text-neutral-400 hover:text-primary-600 hover:bg-primary-50">
            <Pencil size={15} />
          </button>
          <button onClick={() => loeschen(p)} title="Löschen"
            className="p-1.5 rounded-lg text-neutral-400 hover:text-red-600 hover:bg-red-50">
            <Trash2 size={15} />
          </button>
        </div>
      ))}
    </div>
  )
}

/* ── Erfassung / Bearbeitung eines Posts (Vollbild, mobile-first) ───────────── */
function PostEditor({ post, profile, onClose, onSaved }) {
  const istNeu = !post
  const [aktuell, setAktuell] = useState(post || null)   // Post-Objekt vom Server
  const [profilId, setProfilId] = useState(post?.profil_id || (profile[0]?.id ?? null))
  const [kontaktId, setKontaktId] = useState(post?.kontakt_id || null)
  const [kontaktName, setKontaktName] = useState(post?.kontakt_name || null)
  const [beschreibung, setBeschreibung] = useState(post?.beschreibung || '')
  const [text, setText] = useState(post?.text || '')
  const [hashtags, setHashtags] = useState(post?.hashtags || '')
  const [ort, setOrt] = useState(post?.ort || '')
  const [gefuehl, setGefuehl] = useState(post?.gefuehl || '')
  const [neueFotos, setNeueFotos] = useState([])          // File-Objekte vor dem Upload
  const [videoLaedt, setVideoLaedt] = useState(false)     // Video wird gerade hochgeladen
  const [generiert, setGeneriert] = useState(!!post?.text)
  const [laufend, setLaufend] = useState(false)
  const [planenOffen, setPlanenOffen] = useState(false)
  const [geplantAm, setGeplantAm] = useState('')
  const fileRef = useRef(null)
  const videoRef = useRef(null)

  // Fotos für die Web Share API vorladen (muss VOR dem Klick passieren,
  // damit navigator.share synchron im Klick-Kontext aufgerufen werden kann).
  // Ausspielungs-Variante: Zielformat + Filter des Profils sind angewendet.
  const [shareDateien, setShareDateien] = useState([])
  useEffect(() => {
    let aktiv = true
    setShareDateien([])
    const fotos = aktuell?.fotos || []
    if (!navigator.canShare || fotos.length === 0) return
    Promise.all(fotos.map(async f => {
      const res = await posteckeApi.getFotoAusspielung(f.id)
      const name = f.filename.replace(/\.[^.]+$/, '') + '.jpg'
      return new File([res.data], name, { type: 'image/jpeg' })
    })).then(dateien => { if (aktiv) setShareDateien(dateien) }).catch(() => {})
    return () => { aktiv = false }
  }, [aktuell?.fotos, profilId])

  // Natives Teilen mit Dateien möglich? (iPhone/iPad: ja; Desktop: meist nein)
  const kannTeilen = shareDateien.length > 0 &&
    navigator.canShare && navigator.canShare({ files: shareDateien })

  const profil = profile.find(p => p.id === profilId) || null
  const kanal = profil ? kanalInfo(profil.kanal) : null

  // Ein Post ist entweder Foto- oder Video-Post (kein Misch-Post): sobald das
  // eine belegt ist, wird das andere im Editor ausgeblendet.
  const hatFotos = (aktuell?.fotos?.length > 0) || neueFotos.length > 0
  const hatVideo = !!aktuell?.video || videoLaedt

  /** Post am Server anlegen/aktualisieren + neue Fotos hochladen; liefert Post */
  const sicherstellen = useCallback(async () => {
    let p = aktuell
    const daten = {
      profil_id: profilId, beschreibung: beschreibung || null,
      text: text || null, hashtags: hashtags || null,
      ort: ort || null, gefuehl: gefuehl || null,
      kontakt_id: kontaktId, kontakt_name: kontaktName,
    }
    if (!p) {
      const res = await posteckeApi.createPost({
        profil_id: profilId, beschreibung: beschreibung || null,
        kontakt_id: kontaktId, kontakt_name: kontaktName,
      })
      p = res.data
    } else {
      const res = await posteckeApi.updatePost(p.id, daten)
      p = res.data
    }
    if (neueFotos.length > 0) {
      // Fotos EINZELN hochladen: bleibt unter dem nginx-Request-Limit und
      // ein zu großes Einzelfoto bricht nicht den ganzen Stapel ab
      for (const foto of neueFotos) {
        try {
          const res = await posteckeApi.uploadFotos(p.id, [foto])
          p = res.data
        } catch (e) {
          const grund = e.response?.status === 413
            ? 'zu groß für den Server' : (e.response?.data?.detail || 'Upload fehlgeschlagen')
          throw new Error(`Foto „${foto.name}": ${grund}`)
        }
      }
      setNeueFotos([])
    }
    setAktuell(p)
    return p
  }, [aktuell, profilId, beschreibung, text, hashtags, ort, gefuehl, neueFotos, kontaktId, kontaktName])

  const kiVorschlag = async () => {
    if (!profilId) { toast.error('Bitte zuerst ein Profil wählen'); return }
    if (!beschreibung.trim() && neueFotos.length === 0 && !(aktuell?.fotos?.length)) {
      // Ein Video kann die KI nicht ansehen -> für Video-Posts ist die
      // Beschreibung die Grundlage für den Textvorschlag.
      toast.error(aktuell?.video
        ? 'Bitte kurz beschreiben, worum es geht — das Video kann die KI nicht ansehen'
        : 'Bitte Fotos hinzufügen oder kurz beschreiben, worum es geht')
      return
    }
    setLaufend(true)
    try {
      const p = await sicherstellen()
      const res = await posteckeApi.generieren(p.id, beschreibung || null)
      setText(res.data.text || '')
      setHashtags(res.data.hashtags || '')
      if (res.data.ort) setOrt(res.data.ort)
      if (res.data.gefuehl) setGefuehl(res.data.gefuehl)
      setGeneriert(true)
      const neu = await posteckeApi.getPost(p.id)
      setAktuell(neu.data)
      toast.success('Vorschlag erstellt — bitte kontrollieren')
    } catch (e) {
      toast.error(e.response?.data?.detail || e.message || 'KI-Vorschlag fehlgeschlagen')
    } finally { setLaufend(false) }
  }

  const speichern = async (nachricht = 'Gespeichert') => {
    setLaufend(true)
    try {
      const p = await sicherstellen()
      toast.success(nachricht)
      onSaved()
      return p
    } catch (e) {
      toast.error(e.response?.data?.detail || e.message || 'Speichern fehlgeschlagen')
      return null
    } finally { setLaufend(false) }
  }

  /** Direktanbindung: sofort über die API des Kanals veröffentlichen */
  const direktVeroeffentlichen = async () => {
    setLaufend(true)
    try {
      const p = await sicherstellen()
      const res = await posteckeApi.veroeffentlichen(p.id)
      toast.success('Veröffentlicht!')
      if (res.data.extern_url) window.open(res.data.extern_url, '_blank', 'noopener')
      onSaved()
      onClose()
    } catch (e) {
      toast.error(e.response?.data?.detail || e.message || 'Veröffentlichen fehlgeschlagen')
    } finally { setLaufend(false) }
  }

  /** Nach dem Übergeben: speichern + nachfragen, ob veröffentlicht wurde */
  const nachVeroeffentlichungFragen = async () => {
    const p = await speichern('Post gespeichert')
    if (!p) return
    if (window.confirm('Wurde der Post veröffentlicht? Dann verschiebe ich ihn zu „Veröffentlicht".')) {
      await posteckeApi.setStatus(p.id, 'veroeffentlicht')
      onSaved()
      onClose()
    }
  }

  /**
   * Assistiertes Posten.
   * Variante 1 (iPhone/iPad u.a.): Web Share API — natives Teilen-Menü mit
   *   FOTOS + Text, kein erneutes Hochladen. Facebook übernimmt die Fotos;
   *   den Text verwirft die FB-App absichtlich, darum liegt er zusätzlich
   *   in der Zwischenablage (nur einfügen).
   * Variante 2 (Desktop-Fallback): Text in die Zwischenablage + Kanal öffnen.
   * WICHTIG: share/open/clipboard müssen SYNCHRON im Klick-Kontext starten —
   * nach einem await blockiert sie der Popup-Blocker (v.a. Safari/iOS).
   */
  const assistiertPosten = async () => {
    const voll = postText({ text, hashtags })

    if (kannTeilen) {
      try { navigator.clipboard.writeText(voll) } catch { /* optional */ }
      try {
        await navigator.share({ files: shareDateien, text: voll })
      } catch (e) {
        if (e?.name === 'AbortError') return   // Nutzer hat abgebrochen
        toast.error('Teilen fehlgeschlagen — nutze den Zwischenablage-Weg')
      }
      await nachVeroeffentlichungFragen()
      return
    }

    if (kanal?.url) window.open(kanal.url, '_blank', 'noopener')
    try {
      await navigator.clipboard.writeText(voll)
      toast.success('Text in der Zwischenablage — beim Kanal nur noch einfügen')
    } catch {
      toast.error('Zwischenablage nicht verfügbar — Text bitte manuell kopieren')
    }
    await nachVeroeffentlichungFragen()
  }

  /** Desktop-Fallback: alle Fotos herunterladen (Ausspielungs-Variante) */
  const fotosHerunterladen = async () => {
    for (const f of (aktuell?.fotos || [])) {
      try {
        const res = await posteckeApi.getFotoAusspielung(f.id)
        const url = URL.createObjectURL(res.data)
        const a = document.createElement('a')
        a.href = url
        a.download = f.filename.replace(/\.[^.]+$/, '') + '.jpg'
        document.body.appendChild(a)
        a.click()
        a.remove()
        URL.revokeObjectURL(url)
      } catch { toast.error(`Download fehlgeschlagen: ${f.filename}`) }
    }
  }

  const planen = async () => {
    if (!geplantAm) { toast.error('Bitte Datum und Uhrzeit wählen'); return }
    const p = await speichern('Post gespeichert')
    if (!p) return
    try {
      await posteckeApi.setStatus(p.id, 'geplant', new Date(geplantAm).toISOString())
      toast.success('Geplant — der Post wartet im Redaktionsplan')
      onSaved()
      onClose()
    } catch (e) {
      toast.error(e.response?.data?.detail || 'Planen fehlgeschlagen')
    }
  }

  const ablegen = async () => {
    const p = await speichern('In der Postecke abgelegt')
    if (p) onClose()
  }

  const fotoWaehlen = (e) => {
    const dateien = Array.from(e.target.files || [])
    if (dateien.length) setNeueFotos(prev => [...prev, ...dateien])
    e.target.value = ''
  }

  const fotoLoeschen = async (fotoId) => {
    try {
      await posteckeApi.deleteFoto(fotoId)
      const neu = await posteckeApi.getPost(aktuell.id)
      setAktuell(neu.data)
    } catch { toast.error('Foto konnte nicht gelöscht werden') }
  }

  const videoWaehlen = async (e) => {
    const datei = (e.target.files || [])[0]
    e.target.value = ''
    if (!datei) return
    const okTyp = ['video/mp4', 'video/quicktime'].includes(datei.type) ||
      /\.(mp4|mov)$/i.test(datei.name)
    if (!okTyp) { toast.error('Bitte ein MP4- oder MOV-Video wählen'); return }
    if (datei.size > 200 * 1024 * 1024) { toast.error('Video zu groß (max. 200 MB)'); return }
    // Sofort hochladen, damit der Server das Standbild erzeugt und die Vorschau
    // direkt erscheint (unabhängig vom Video-Format des Browsers).
    setVideoLaedt(true)
    try {
      const p = await sicherstellen()
      await posteckeApi.uploadVideo(p.id, datei)
      const neu = await posteckeApi.getPost(p.id)
      setAktuell(neu.data)
    } catch (e2) {
      const grund = e2.response?.status === 413
        ? 'zu groß für den Server' : (e2.response?.data?.detail || e2.message || 'Upload fehlgeschlagen')
      toast.error(`Video „${datei.name}": ${grund}`)
    } finally { setVideoLaedt(false) }
  }

  const videoLoeschen = async () => {
    if (!aktuell?.video) return
    try {
      await posteckeApi.deleteVideo(aktuell.video.id)
      const neu = await posteckeApi.getPost(aktuell.id)
      setAktuell(neu.data)
    } catch { toast.error('Video konnte nicht gelöscht werden') }
  }

  return (
    <div className="fixed inset-0 z-50 bg-neutral-900/40 sheet-safe flex items-end sm:items-center justify-center"
      style={{ paddingTop: 'env(safe-area-inset-top)' }}>
      <div className="bg-neutral-50 w-full sm:max-w-lg rounded-2xl max-h-full lg:max-h-[92vh] overflow-y-auto"
        style={{ paddingBottom: 'env(safe-area-inset-bottom)' }}>

        {/* Kopf */}
        <div className="sticky top-0 bg-neutral-50 border-b border-neutral-200 px-4 py-3 flex items-center justify-between z-10">
          <h2 className="font-semibold text-neutral-900 text-sm flex items-center gap-2">
            <Megaphone size={16} className="text-primary-600" />
            {istNeu ? 'Neuer Post' : 'Post bearbeiten'}
          </h2>
          <button aria-label="Schließen" onClick={onClose} className="p-1.5 rounded-lg hover:bg-neutral-100 text-neutral-500">
            <X size={18} />
          </button>
        </div>

        <div className="p-4 space-y-4">
          {/* Fotos (ausgeblendet, sobald ein Video gewählt ist — kein Misch-Post) */}
          {!hatVideo && (
          <div>
            <label className="text-xs font-medium text-neutral-500">Fotos</label>
            <div className="mt-1 grid grid-cols-4 gap-2">
              {(aktuell?.fotos || []).map(f => (
                <div key={f.id} className="relative aspect-square rounded-lg overflow-hidden group">
                  <FotoThumb fotoId={f.id} className="w-full h-full" />
                  <button onClick={() => fotoLoeschen(f.id)}
                    className="absolute top-1 right-1 p-1 rounded-full bg-neutral-900/60 text-white opacity-70 hover:opacity-100">
                    <X size={12} />
                  </button>
                </div>
              ))}
              {neueFotos.map((f, i) => (
                <div key={i} className="relative aspect-square rounded-lg overflow-hidden">
                  <img src={URL.createObjectURL(f)} alt="" className="w-full h-full object-cover" />
                  <button onClick={() => setNeueFotos(prev => prev.filter((_, j) => j !== i))}
                    className="absolute top-1 right-1 p-1 rounded-full bg-neutral-900/60 text-white opacity-70 hover:opacity-100">
                    <X size={12} />
                  </button>
                </div>
              ))}
              <button onClick={() => fileRef.current?.click()}
                className="aspect-square rounded-lg border-2 border-dashed border-neutral-300 flex flex-col items-center justify-center text-neutral-400 hover:border-primary-400 hover:text-primary-500">
                <Camera size={20} />
                <span className="text-[10px] mt-0.5">Hinzufügen</span>
              </button>
            </div>
            <input ref={fileRef} type="file" accept="image/*" multiple className="hidden" onChange={fotoWaehlen} />
          </div>
          )}

          {/* Video (ausgeblendet, sobald Fotos gewählt sind — max. ein Video je Post) */}
          {!hatFotos && (
          <div>
            <label className="text-xs font-medium text-neutral-500">Video</label>
            {videoLaedt ? (
              <div className="mt-1 w-full py-8 rounded-lg border border-neutral-200 bg-neutral-50 flex flex-col items-center justify-center text-neutral-400">
                <Loader2 size={22} className="animate-spin" />
                <span className="text-[11px] mt-1.5">Video wird hochgeladen &amp; Vorschau erstellt …</span>
              </div>
            ) : aktuell?.video ? (
              <div className="mt-1 relative rounded-lg overflow-hidden">
                <VideoVorschau
                  videoId={aktuell.video.id}
                  hasPoster={aktuell.video.has_poster}
                  className="w-full min-h-[8rem] max-h-64" />
                <button aria-label="Video entfernen" onClick={videoLoeschen}
                  className="absolute top-1 right-1 p-1 rounded-full bg-neutral-900/60 text-white opacity-80 hover:opacity-100 z-10">
                  <X size={14} />
                </button>
                <p className="mt-1 text-[11px] text-neutral-400 truncate">
                  {aktuell.video.filename}
                </p>
              </div>
            ) : (
              <button onClick={() => videoRef.current?.click()}
                className="mt-1 w-full py-4 rounded-lg border-2 border-dashed border-neutral-300 flex flex-col items-center justify-center text-neutral-400 hover:border-primary-400 hover:text-primary-500">
                <Film size={20} />
                <span className="text-[11px] mt-0.5">Video hinzufügen (MP4/MOV, max. 200 MB)</span>
              </button>
            )}
            <input ref={videoRef} type="file" accept="video/mp4,video/quicktime,.mp4,.mov"
              className="hidden" onChange={videoWaehlen} />
          </div>
          )}

          {/* Profil */}
          <div>
            <label className="text-xs font-medium text-neutral-500">Profil</label>
            <div className="mt-1 flex flex-wrap gap-2">
              {profile.filter(p => p.is_active).map(p => (
                <button key={p.id} onClick={() => setProfilId(p.id)}
                  className={`px-3 py-1.5 rounded-full text-xs font-medium border transition-colors ${
                    profilId === p.id
                      ? 'bg-primary-50 border-primary-300 text-primary-700'
                      : 'bg-surface border-neutral-200 text-neutral-600 hover:border-neutral-300'
                  }`}>
                  {p.name}
                </button>
              ))}
              {profile.length === 0 && (
                <span className="text-xs text-neutral-400">
                  Noch kein Profil angelegt — über das Zahnrad oben Profile verwalten.
                </span>
              )}
            </div>
          </div>

          {/* Kontakt (optional) — archivierte Posts landen im Datacenter beim Kontakt */}
          <div>
            <label className="text-xs font-medium text-neutral-500">
              Kontakt (optional — fürs Postsarchiv im Datacenter)
            </label>
            <div className="mt-1">
              <ContactSearch contactId={kontaktId} contactName={kontaktName}
                onChange={(id, name) => { setKontaktId(id); setKontaktName(name) }} />
            </div>
          </div>

          {/* Beschreibung */}
          <div>
            <label className="text-xs font-medium text-neutral-500">
              Was ist los? (Tipp: iOS-Tastatur-Mikrofon zum Diktieren)
            </label>
            <textarea value={beschreibung} onChange={e => setBeschreibung(e.target.value)} rows={3}
              placeholder="Kurz beschreiben: was, wo, mit wem — die KI macht den Rest …"
              className="mt-1 w-full px-3 py-2 rounded-lg border border-neutral-200 text-sm focus:outline-none focus:ring-2 focus:ring-primary-200" />
          </div>

          {/* KI-Vorschlag */}
          <button onClick={kiVorschlag} disabled={laufend}
            className="w-full flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg text-sm font-medium bg-primary-600 text-white hover:bg-primary-700 disabled:opacity-50">
            {laufend ? <Loader2 size={16} className="animate-spin" /> :
              generiert ? <RefreshCw size={16} /> : <Sparkles size={16} />}
            {generiert ? 'Neuen Vorschlag erstellen' : 'KI-Vorschlag erstellen'}
          </button>

          {/* Ergebnis (editierbar) */}
          {(generiert || text) && (
            <div className="space-y-3 bg-surface rounded-xl border border-neutral-200 p-3">
              <div>
                <label className="text-xs font-medium text-neutral-500">Posttext</label>
                <textarea value={text} onChange={e => setText(e.target.value)} rows={6}
                  className="mt-1 w-full px-3 py-2 rounded-lg border border-neutral-200 text-sm focus:outline-none focus:ring-2 focus:ring-primary-200" />
              </div>
              <div>
                <label className="text-xs font-medium text-neutral-500">Hashtags</label>
                <input value={hashtags} onChange={e => setHashtags(e.target.value)}
                  className="mt-1 w-full px-3 py-2 rounded-lg border border-neutral-200 text-sm text-primary-700 focus:outline-none focus:ring-2 focus:ring-primary-200" />
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-xs font-medium text-neutral-500 flex items-center gap-1">
                    <MapPin size={11} /> Ort
                  </label>
                  <input value={ort} onChange={e => setOrt(e.target.value)}
                    className="mt-1 w-full px-3 py-2 rounded-lg border border-neutral-200 text-sm focus:outline-none focus:ring-2 focus:ring-primary-200" />
                </div>
                <div>
                  <label className="text-xs font-medium text-neutral-500 flex items-center gap-1">
                    <Smile size={11} /> Gefühl
                  </label>
                  <input value={gefuehl} onChange={e => setGefuehl(e.target.value)}
                    className="mt-1 w-full px-3 py-2 rounded-lg border border-neutral-200 text-sm focus:outline-none focus:ring-2 focus:ring-primary-200" />
                </div>
              </div>
              {aktuell?.ki_model && (
                <p className="text-[10px] text-neutral-400">Vorschlag von {aktuell.ki_model}</p>
              )}
            </div>
          )}

          {/* Aktionen */}
          {(text || generiert) && (
            <div className="space-y-2">
              {profil?.direktanbindung && (
                <button onClick={direktVeroeffentlichen} disabled={laufend}
                  className="w-full flex items-center gap-3 px-4 py-3 rounded-xl border-2 border-primary-300 bg-primary-50/50 hover:bg-primary-50 text-left">
                  <Send size={18} className="text-primary-600 flex-shrink-0" />
                  <span>
                    <span className="block text-sm font-medium text-neutral-900">Jetzt veröffentlichen</span>
                    <span className="block text-xs text-neutral-500">
                      Direkt auf {kanal?.label || 'dem Kanal'} — Fotos und Text werden automatisch übertragen
                    </span>
                  </span>
                </button>
              )}
              <button onClick={assistiertPosten} disabled={laufend}
                className="w-full flex items-center gap-3 px-4 py-3 rounded-xl border border-neutral-200 bg-surface hover:border-primary-300 text-left">
                <Send size={18} className="text-primary-600 flex-shrink-0" />
                <span>
                  <span className="block text-sm font-medium text-neutral-900">
                    {kannTeilen ? 'Jetzt teilen (Fotos + Text)' : 'Jetzt assistiert posten'}
                  </span>
                  <span className="block text-xs text-neutral-500">
                    {kannTeilen
                      ? `Teilen-Menü öffnet sich — ${kanal?.label || 'App'} wählen, Fotos sind dabei, Text nur einfügen`
                      : `Text in die Zwischenablage, ${kanal?.label || 'Kanal'} öffnet sich — Du machst den letzten Klick`}
                  </span>
                </span>
              </button>
              {!kannTeilen && (aktuell?.fotos?.length > 0) && (
                <button onClick={fotosHerunterladen} disabled={laufend}
                  className="w-full flex items-center gap-3 px-4 py-2.5 rounded-xl border border-neutral-200 bg-surface hover:border-primary-300 text-left">
                  <Camera size={16} className="text-neutral-500 flex-shrink-0" />
                  <span className="text-xs text-neutral-600">
                    Fotos herunterladen ({aktuell.fotos.length}) — fürs Hochladen beim Kanal
                  </span>
                </button>
              )}

              <button onClick={() => setPlanenOffen(v => !v)} disabled={laufend}
                className="w-full flex items-center gap-3 px-4 py-3 rounded-xl border border-neutral-200 bg-surface hover:border-primary-300 text-left">
                <CalendarClock size={18} className="text-primary-600 flex-shrink-0" />
                <span>
                  <span className="block text-sm font-medium text-neutral-900">Planen</span>
                  <span className="block text-xs text-neutral-500">
                    {profil?.direktanbindung
                      ? 'Wird zur geplanten Zeit automatisch veröffentlicht'
                      : 'In den Redaktionsplan mit Termin'}
                  </span>
                </span>
              </button>
              {planenOffen && (
                <div className="flex gap-2 px-1">
                  <input type="datetime-local" value={geplantAm} onChange={e => setGeplantAm(e.target.value)}
                    className="flex-1 px-3 py-2 rounded-lg border border-neutral-200 text-sm bg-surface focus:outline-none focus:ring-2 focus:ring-primary-200" />
                  <button onClick={planen} disabled={laufend}
                    className="px-4 py-2 rounded-lg text-sm font-medium bg-primary-600 text-white hover:bg-primary-700 disabled:opacity-50">
                    <Check size={16} />
                  </button>
                </div>
              )}

              <button onClick={ablegen} disabled={laufend}
                className="w-full flex items-center gap-3 px-4 py-3 rounded-xl border border-neutral-200 bg-surface hover:border-primary-300 text-left">
                <Inbox size={18} className="text-neutral-500 flex-shrink-0" />
                <span>
                  <span className="block text-sm font-medium text-neutral-900">In die Postecke legen</span>
                  <span className="block text-xs text-neutral-500">Als Entwurf für später aufheben</span>
                </span>
              </button>
            </div>
          )}

          {/* Ohne KI-Text nur speichern */}
          {!text && !generiert && (
            <button onClick={ablegen} disabled={laufend}
              className="w-full px-4 py-2.5 rounded-lg text-sm font-medium border border-neutral-200 bg-surface text-neutral-600 hover:border-neutral-300">
              Als Entwurf ablegen
            </button>
          )}
        </div>
      </div>
    </div>
  )
}

/* ── Hauptseite ─────────────────────────────────────────────────────────────── */
export default function PosteckePage() {
  const { isAdmin, hasRecht } = useAuth()
  // Posts anlegen/ändern/veröffentlichen = Schreibrecht, Löschen = Löschrecht.
  // Archivieren zählt hier bewusst als Ändern (nicht wie bei den Stammdaten als
  // Löschen): Es setzt nur den Status und ist über „Wiederherstellen" mit einem
  // Klick zurückgenommen — der Server behandelt es genauso (POST /status).
  // Die Profilverwaltung bleibt Admin-Sache: dort liegen Zugangsdaten der Kanäle
  // und der KI-Schlüssel.
  const darfAendern = hasRecht('postecke', 'schreiben')
  const darfLoeschen = hasRecht('postecke', 'loeschen')
  const [posts, setPosts] = useState([])
  const [profile, setProfile] = useState([])
  const [laden, setLaden] = useState(true)
  const [ansicht, setAnsicht] = useState('posts')       // posts | profile
  const [editor, setEditor] = useState(null)            // null | 'neu' | post
  // Darstellung der Posts: Liste (mobil) | Kanban-Board | Kalender (Redaktionsplan)
  const [darstellung, setDarstellung] = useState(() => {
    try { return localStorage.getItem('postecke_ansicht') || 'liste' } catch { return 'liste' }
  })
  const darstellungWaehlen = (d) => {
    setDarstellung(d)
    try { localStorage.setItem('postecke_ansicht', d) } catch {}
  }

  const laden_ = useCallback(async () => {
    try {
      const [p1, p2] = await Promise.all([posteckeApi.listPosts(), posteckeApi.listProfile()])
      setPosts(p1.data)
      setProfile(p2.data)
    } catch {
      toast.error('Postecke konnte nicht geladen werden')
    } finally { setLaden(false) }
  }, [])
  useEffect(() => { laden_() }, [laden_])

  const profilName = (id) => profile.find(p => p.id === id)?.name || '—'
  const profilKanal = (id) => {
    const p = profile.find(x => x.id === id)
    return p ? kanalInfo(p.kanal).label : null
  }
  // Kanal-ID eines Profils (für Farben im Kalender)
  const profilKanalId = (id) => profile.find(x => x.id === id)?.kanal || null

  const loeschen = async (post) => {
    if (!window.confirm('Diesen Post endgültig löschen (inkl. Fotos)?')) return
    try {
      await posteckeApi.deletePost(post.id)
      toast.success('Post gelöscht')
      laden_()
    } catch { toast.error('Löschen fehlgeschlagen') }
  }

  const archivieren = async (post) => {
    try {
      await posteckeApi.setStatus(post.id, 'archiviert')
      toast.success('Post archiviert')
      laden_()
    } catch { toast.error('Archivieren fehlgeschlagen') }
  }

  const wiederherstellen = async (post) => {
    try {
      await posteckeApi.setStatus(post.id, 'entwurf')
      toast.success('Post wiederhergestellt (Entwurf)')
      laden_()
    } catch { toast.error('Wiederherstellen fehlgeschlagen') }
  }

  // Der Editor ist durchgehend eine Schreib-Oberfläche (KI-Vorschlag,
  // Veröffentlichen, Ablegen). Ohne Änderungsrecht bliebe darin kein einziger
  // Knopf übrig, deshalb wird er gar nicht erst geöffnet — die Liste zeigt
  // Titel, Text, Status und Termin, und der Text lässt sich kopieren.
  const oeffnen = (post) => { if (darfAendern) setEditor(post) }

  const kopieren = async (post) => {
    try {
      await navigator.clipboard.writeText(postText(post))
      toast.success('Text in der Zwischenablage')
    } catch { toast.error('Zwischenablage nicht verfügbar') }
  }

  // Volltextsuche über Titel, Posttext, Beschreibung, Hashtags, Ort und Profil
  const [suche, setSuche] = useState('')
  const gefiltert = useMemo(() => {
    const q = suche.trim().toLowerCase()
    if (!q) return posts
    return posts.filter(p =>
      [p.titel, p.text, p.beschreibung, p.hashtags, p.ort, p.kontakt_name,
       profilName(p.profil_id), profilKanal(p.profil_id)]
        .filter(Boolean).join(' ').toLowerCase().includes(q))
  }, [posts, suche, profile])

  // Archivierte Posts nur in der Liste (eigene Gruppe unten), nicht im Board/Kalender
  const aktivePosts = gefiltert.filter(p => p.status !== 'archiviert')

  const gruppen = ['kontrolle', 'geplant', 'entwurf', 'veroeffentlicht', 'archiviert']
    .map(s => ({ status: s, eintraege: gefiltert.filter(p => p.status === s) }))
    .filter(g => g.eintraege.length > 0)

  if (laden) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader2 size={28} className="animate-spin text-primary-400" />
      </div>
    )
  }

  // Breite: alle Post-Ansichten volle Breite, nur die Profilverwaltung kompakt
  const breite = ansicht === 'profile' ? 'max-w-3xl' : 'max-w-full'

  return (
    <div className={`${breite} mx-auto`}>
      {/* Kopfzeile */}
      <PageHeader icon={Megaphone} title="Postecke" subtitle="Posts mit KI vorbereiten und gezielt veröffentlichen">
        <div className="flex items-center gap-2">
          {isAdmin && (
            <button onClick={() => setAnsicht(a => a === 'profile' ? 'posts' : 'profile')}
              title="Profile verwalten"
              className={`p-2 rounded-lg border ${ansicht === 'profile'
                ? 'bg-primary-50 border-primary-300 text-primary-700'
                : 'bg-surface border-neutral-200 text-neutral-500 hover:text-neutral-800'}`}>
              <Settings2 size={17} />
            </button>
          )}
          {darfAendern && ansicht === 'posts' && (
            <button onClick={() => setEditor('neu')}
              className="hidden sm:flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-medium bg-primary-600 text-white hover:bg-primary-700">
              <Plus size={15} /> Neuer Post
            </button>
          )}
        </div>
      </PageHeader>

      {darfAendern && ansicht === 'posts' && <Fab onClick={() => setEditor('neu')} title="Neuer Post" />}

      {isAdmin && ansicht === 'profile' ? (
        <ProfilVerwaltung profile={profile} onReload={laden_} onClose={() => setAnsicht('posts')} />
      ) : (
        <>
          {/* Ansichtsumschalter + Suche */}
          {posts.length > 0 && (
            <div className="flex flex-wrap items-center gap-3 mb-4">
              <div className="flex items-center gap-1 bg-neutral-100 rounded-lg p-1 w-fit">
                {[
                  { id: 'liste',    icon: List,         label: 'Liste' },
                  { id: 'board',    icon: Columns,      label: 'Board' },
                  { id: 'kalender', icon: CalendarDays, label: 'Kalender' },
                ].map(({ id, icon: Icon, label }) => (
                  <button key={id} onClick={() => darstellungWaehlen(id)}
                    className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-medium transition-colors ${
                      darstellung === id
                        ? 'bg-surface text-neutral-900 shadow-sm'
                        : 'text-neutral-500 hover:text-neutral-800'
                    }`}>
                    <Icon size={13} /> {label}
                  </button>
                ))}
              </div>
              <div className="relative flex-1 min-w-[200px] max-w-sm">
                <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-neutral-400" />
                <input value={suche} onChange={e => setSuche(e.target.value)}
                  placeholder="Suchen (Text, Hashtags, Ort, Profil) …"
                  className="w-full pl-8 pr-8 py-2 rounded-lg border border-neutral-200 text-sm bg-surface focus:outline-none focus:ring-2 focus:ring-primary-200" />
                {suche && (
                  <button onClick={() => setSuche('')}
                    className="absolute right-2 top-1/2 -translate-y-1/2 p-0.5 rounded text-neutral-400 hover:text-neutral-700">
                    <X size={14} />
                  </button>
                )}
              </div>
            </div>
          )}

          {posts.length > 0 && gefiltert.length === 0 && (
            <p className="text-center text-neutral-400 text-sm py-10">
              Keine Treffer für „{suche}".
            </p>
          )}

          {posts.length === 0 && (
            <div className="text-center py-14">
              <Megaphone size={36} className="mx-auto text-neutral-300 mb-3" />
              <p className="text-neutral-500 text-sm mb-1">Noch keine Posts in der Postecke.</p>
              <p className="text-neutral-400 text-xs mb-4">
                {profile.length > 0
                  ? 'Fotos rein, kurz beschreiben — die KI macht den Vorschlag.'
                  : isAdmin
                    ? 'Lege zuerst über das Zahnrad ein Profil an (z.B. „Facebook privat").'
                    /* Ohne Adminrolle gibt es kein Zahnrad — der Hinweis darauf
                       würde ins Leere zeigen. */
                    : 'Ein Administrator muss zuerst ein Profil anlegen (z.B. „Facebook privat").'}
              </p>
              {darfAendern && profile.length > 0 && (
                <button onClick={() => setEditor('neu')}
                  className="inline-flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium bg-primary-600 text-white hover:bg-primary-700">
                  <Plus size={15} /> Ersten Post erstellen
                </button>
              )}
            </div>
          )}

          {darstellung === 'board' && aktivePosts.length > 0 && (
            <PosteckeKanban posts={aktivePosts} profilName={profilName}
              kanalLabel={profilKanal} onOpen={oeffnen} onChanged={laden_}
              onArchivieren={archivieren} onLoeschen={loeschen}
              darfAendern={darfAendern} darfLoeschen={darfLoeschen} />
          )}

          {darstellung === 'kalender' && aktivePosts.length > 0 && (
            <PosteckeKalender posts={aktivePosts} kanalVon={profilKanalId} onOpen={oeffnen} />
          )}

          {darstellung === 'liste' && (
          <div className="space-y-6">
            {gruppen.map(g => (
              <div key={g.status}>
                <h2 className="text-xs font-medium text-neutral-400 uppercase tracking-wider mb-2">
                  {STATUS_META[g.status].label} · {g.eintraege.length}
                </h2>
                <div className="space-y-2">
                  {g.eintraege.map(post => (
                    <div key={post.id}
                      className={`bg-surface rounded-xl border border-neutral-200 p-3 flex gap-3 items-start hover:border-neutral-300 ${
                        darfAendern ? 'cursor-pointer' : ''}`}
                      onClick={() => oeffnen(post)}>
                      {post.fotos?.length > 0 ? (
                        <FotoThumb fotoId={post.fotos[0].id} className="w-14 h-14 rounded-lg flex-shrink-0" />
                      ) : post.video ? (
                        <VideoThumb videoId={post.video.id} hasPoster={post.video.has_poster}
                          className="w-14 h-14 rounded-lg flex-shrink-0" />
                      ) : (
                        <div className="w-14 h-14 rounded-lg bg-neutral-100 flex items-center justify-center flex-shrink-0">
                          <Camera size={18} className="text-neutral-300" />
                        </div>
                      )}
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="text-sm font-medium text-neutral-900 truncate">
                            {post.titel || post.text?.slice(0, 60) || post.beschreibung?.slice(0, 60) || 'Ohne Titel'}
                          </span>
                          <span className={`text-[10px] px-2 py-0.5 rounded-full ${STATUS_META[post.status].badge}`}>
                            {STATUS_META[post.status].label}
                          </span>
                        </div>
                        <div className="flex items-center gap-3 mt-1 text-xs text-neutral-500 flex-wrap">
                          {post.profil_id && (
                            <span>{profilName(post.profil_id)}
                              {profilKanal(post.profil_id) && ` · ${profilKanal(post.profil_id)}`}</span>
                          )}
                          {post.kontakt_name && (
                            <span className="text-neutral-400">@ {post.kontakt_name}</span>
                          )}
                          {post.status === 'geplant' && post.geplant_am && (
                            <span className="flex items-center gap-1 text-primary-600">
                              <Bell size={11} /> {datumZeit(post.geplant_am)}
                            </span>
                          )}
                          {post.status === 'veroeffentlicht' && post.veroeffentlicht_am && (
                            <span className="flex items-center gap-1 text-green-600">
                              <Check size={11} /> {datumZeit(post.veroeffentlicht_am)}
                            </span>
                          )}
                          {post.extern_url && (
                            <a href={post.extern_url} target="_blank" rel="noopener noreferrer"
                              onClick={e => e.stopPropagation()}
                              className="text-primary-600 hover:underline">Beitrag öffnen</a>
                          )}
                          {post.fotos?.length > 0 && <span>{post.fotos.length} Foto{post.fotos.length > 1 ? 's' : ''}</span>}
                          {post.status === 'geplant' && post.publish_error && (
                            <span className="text-red-600 w-full">
                              ⚠ Automatisches Posten fehlgeschlagen: {post.publish_error.slice(0, 120)}
                            </span>
                          )}
                        </div>
                      </div>
                      <div className="flex gap-1" onClick={e => e.stopPropagation()}>
                        {post.text && (
                          <button onClick={() => kopieren(post)} title="Text kopieren"
                            className="p-1.5 rounded-lg text-neutral-400 hover:text-primary-600 hover:bg-primary-50">
                            <Copy size={14} />
                          </button>
                        )}
                        {darfAendern && (post.status === 'archiviert' ? (
                          <button onClick={() => wiederherstellen(post)} title="Wiederherstellen"
                            className="p-1.5 rounded-lg text-neutral-400 hover:text-primary-600 hover:bg-primary-50">
                            <ArchiveRestore size={14} />
                          </button>
                        ) : (
                          <button onClick={() => archivieren(post)} title="Archivieren"
                            className="p-1.5 rounded-lg text-neutral-400 hover:text-amber-600 hover:bg-amber-50">
                            <Archive size={14} />
                          </button>
                        ))}
                        {darfLoeschen && (
                          <button onClick={() => loeschen(post)} title="Löschen"
                            className="p-1.5 rounded-lg text-neutral-400 hover:text-red-600 hover:bg-red-50">
                            <Trash2 size={14} />
                          </button>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
          )}
        </>
      )}

      {editor !== null && (
        <PostEditor
          post={editor === 'neu' ? null : editor}
          profile={profile}
          onClose={() => setEditor(null)}
          onSaved={laden_}
        />
      )}
    </div>
  )
}
