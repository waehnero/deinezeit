import React, { useState, useRef, useEffect } from 'react'
import { useNavigate } from 'react-router'
import { useSettings, mitCacheBuster } from '../contexts/SettingsContext'
import { getAccessToken, settingsApi, systemApi, invoiceApi } from '../services/api'
import toast from 'react-hot-toast'
import RichTextEditor from '../components/RichTextEditor'
import UserManagementPage from './UserManagementPage'
import MailKonten, { KiEinstellungen } from '../components/MailImportVerwaltung'
import DatenschutzEinstellungen from './DatenschutzEinstellungen'
import LasttestAnleitung from '../components/LasttestAnleitung'
import SystemSitzungen from '../components/SystemSitzungen'
import { DESIGN_TEMPLATES } from '../data/designs'
import {
  Settings2, Building2, Palette, HardDrive, Mail,
  Save, Upload, Trash2, Download, Send, Loader2,
  CheckCircle, Eye, EyeOff, RefreshCw, Cloud,
  ImageIcon, Link2, Monitor, Cpu, ArrowUpCircle,
  Users, AlertTriangle, CheckCircle2, XCircle, ChevronDown, ChevronUp,
  Receipt, FileText, BookOpen, Plus, ShieldCheck, ShieldAlert, Lock
} from 'lucide-react'

// ── Farbthemen ────────────────────────────────────────────────────────────────
const THEMES = [
  { id: 'orange', label: 'Orange',  color: '#f97316' },
  { id: 'blue',   label: 'Blau',    color: '#3b82f6' },
  { id: 'green',  label: 'Grün',    color: '#22c55e' },
  { id: 'purple', label: 'Lila',    color: '#a855f7' },
  { id: 'teal',   label: 'Teal',    color: '#14b8a6' },
  { id: 'red',    label: 'Rot',     color: '#f43f5e' },
]

// ── Tab-Komponente ────────────────────────────────────────────────────────────
function Tab({ id, label, icon: Icon, active, onClick }) {
  return (
    <button
      onClick={() => onClick(id)}
      className={`flex items-center gap-2 px-4 py-2.5 text-sm font-medium rounded-xl transition whitespace-nowrap
        ${active
          ? 'bg-primary-600 text-white shadow-sm'
          : 'text-gray-600 hover:bg-gray-100'}`}
    >
      <Icon size={15} />
      {label}
    </button>
  )
}

// ── Formularfeld ──────────────────────────────────────────────────────────────
function Field({ label, children, hint }) {
  return (
    <div>
      <label className="block text-sm font-medium text-gray-700 mb-1">{label}</label>
      {children}
      {hint && <p className="mt-1 text-xs text-gray-400">{hint}</p>}
    </div>
  )
}

function Input({ value, onChange, type = 'text', placeholder, disabled }) {
  return (
    <input
      type={type} value={value} onChange={e => onChange(e.target.value)}
      placeholder={placeholder} disabled={disabled}
      className="w-full px-3 py-2 border border-gray-300 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-primary-500 disabled:bg-gray-50"
    />
  )
}

// ── Tab: Allgemein ────────────────────────────────────────────────────────────
function TabAllgemein({ settings, onSaved }) {
  const { updateSettings } = useSettings()
  const [companyName,    setCompanyName]    = useState(settings.company_name || '')
  const [appSubtitle,    setAppSubtitle]    = useState(settings.app_subtitle || '')
  // Steuerland — ausgebaut ist derzeit nur Österreich. Das Kennzeichen steht
  // trotzdem hier, damit die Meldelogik daran hängt statt an einer Annahme.
  const [companyCountry, setCompanyCountry] = useState(settings.company_country || 'AT')
  const [saving,         setSaving]         = useState(false)
  const [logoUploading,  setLogoUploading]  = useState(false)
  const [favUploading,   setFavUploading]   = useState(false)
  const [contactGroups,  setContactGroups]  = useState([])
  const [selectedContact, setSelectedContact] = useState({
    id:   settings.company_contact_id   || '',
    type: settings.company_contact_type || '',
  })
  const [contactSaving,  setContactSaving]  = useState(false)

  const logoRef   = useRef(null)
  const favRef    = useRef(null)

  const logoUrl        = settings.logo_url        || null
  const logoHeaderUrl  = settings.logo_header_url  || null
  const logoFaviconUrl = settings.logo_favicon_url || null
  const sidebarLogoSource = settings.sidebar_logo_source === 'favicon' ? 'favicon' : 'logo'

  // Schieber: Sidebar zeigt Logo oder Favicon — sofort anwenden und speichern
  const handleSidebarSourceChange = async (source) => {
    updateSettings({ sidebar_logo_source: source })  // Sidebar aktualisiert sich sofort
    try {
      await settingsApi.update({ sidebar_logo_source: source })
      toast.success(source === 'favicon'
        ? 'Sidebar zeigt jetzt das Favicon'
        : 'Sidebar zeigt jetzt das Logo')
    } catch {
      toast.error('Fehler beim Speichern')
      updateSettings({ sidebar_logo_source: source === 'favicon' ? 'logo' : 'favicon' })
    }
  }

  // Kontaktoptionen laden
  useEffect(() => {
    settingsApi.getContactOptions()
      .then(r => setContactGroups(r.data.groups || []))
      .catch(() => {})
  }, [])

  const handleSave = async () => {
    setSaving(true)
    try {
      await settingsApi.update({ company_name: companyName, app_subtitle: appSubtitle, company_country: companyCountry })
      toast.success('Einstellungen gespeichert')
      onSaved()
    } catch { toast.error('Fehler beim Speichern') }
    finally { setSaving(false) }
  }

  const handleLogoUpload = async (e) => {
    const file = e.target.files?.[0]
    if (!file) return
    setLogoUploading(true)
    try {
      const res = await settingsApi.uploadLogo(file)
      updateSettings({
        logo_url:        res.data.logo_url,
        logo_header_url: res.data.logo_header_url,
        logo_favicon_url: res.data.logo_favicon_url,
      })
      toast.success('Logo hochgeladen — 3 Varianten wurden automatisch generiert')
      onSaved()
    } catch (err) {
      toast.error(err.response?.data?.detail || 'Upload fehlgeschlagen')
    } finally {
      setLogoUploading(false)
      if (logoRef.current) logoRef.current.value = ''
    }
  }

  const handleDeleteLogo = async () => {
    try {
      await settingsApi.deleteLogo()
      updateSettings({ logo_url: '', logo_header_url: '', logo_favicon_url: '' })
      toast.success('Logo gelöscht')
      onSaved()
    } catch { toast.error('Fehler beim Löschen') }
  }

  const handleFaviconAutoGenerate = async () => {
    if (!logoUrl) return toast.error('Zuerst ein Logo hochladen')
    // Backend hat Favicon bereits beim Logo-Upload generiert — einfach Settings neu laden
    toast.success('Favicon wurde beim Logo-Upload automatisch generiert')
  }

  const handleFaviconUpload = async (e) => {
    const file = e.target.files?.[0]
    if (!file) return
    setFavUploading(true)
    try {
      const res = await settingsApi.uploadFavicon(file)
      updateSettings({ logo_favicon_url: res.data.logo_favicon_url })
      toast.success('Favicon hochgeladen')
      onSaved()
    } catch (err) {
      toast.error(err.response?.data?.detail || 'Favicon-Upload fehlgeschlagen')
    } finally {
      setFavUploading(false)
      if (favRef.current) favRef.current.value = ''
    }
  }

  const handleContactSave = async () => {
    setContactSaving(true)
    try {
      await settingsApi.update({
        company_contact_id:   selectedContact.id,
        company_contact_type: selectedContact.type,
      })
      toast.success('Firmen-Kontakt gespeichert')
      onSaved()
    } catch { toast.error('Fehler beim Speichern') }
    finally { setContactSaving(false) }
  }

  // Alle Records aus allen Gruppen flach für Selektor
  const allContacts = contactGroups.flatMap(g =>
    g.records.map(r => ({ ...r, type_name: g.type_name, type_slug: g.type_slug }))
  )
  const selectedName = allContacts.find(c => c.id === selectedContact.id)?.display_name || ''

  return (
    <div className="space-y-8">

      {/* Firmendaten */}
      <div className="space-y-4">
        <h3 className="text-sm font-semibold text-gray-500 uppercase tracking-wide">Firmendaten</h3>
        <div className="grid grid-cols-1 gap-4">
          <Field label="Firmenname" hint="Wird in der Sidebar und auf der Login-Seite angezeigt">
            <Input value={companyName} onChange={setCompanyName} placeholder="Meine Firma GmbH" />
          </Field>
          <Field label="Untertitel" hint="Kurze Beschreibung unter dem Firmennamen">
            <Input value={appSubtitle} onChange={setAppSubtitle} placeholder="Zeiterfassung & Stammdaten" />
          </Field>
          <Field label="Steuerland" hint="Bestimmt Steuersätze und Aufbau der Umsatzsteuer-Auswertung. Derzeit ist nur Österreich ausgebaut.">
            <select value={companyCountry} onChange={e => setCompanyCountry(e.target.value)}
              className="w-full border border-neutral-200 rounded-lg px-3 py-2 text-sm">
              <option value="AT">Österreich</option>
            </select>
          </Field>
        </div>
        <div className="flex justify-end">
          <button onClick={handleSave} disabled={saving}
            className="flex items-center gap-2 px-5 py-2.5 bg-primary-600 hover:bg-primary-700 disabled:bg-primary-300 text-white font-medium rounded-xl transition">
            {saving ? <Loader2 size={15} className="animate-spin" /> : <Save size={15} />}
            Speichern
          </button>
        </div>
      </div>

      <hr className="border-gray-100" />

      {/* Logo */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-semibold text-gray-500 uppercase tracking-wide">Firmenlogo</h3>
          <div className="flex gap-2">
            <button onClick={() => logoRef.current?.click()} disabled={logoUploading}
              className="flex items-center gap-2 px-4 py-2 border border-gray-300 rounded-xl text-sm font-medium text-gray-700 hover:bg-gray-50 transition">
              {logoUploading ? <Loader2 size={14} className="animate-spin" /> : <Upload size={14} />}
              {logoUrl ? 'Neues Logo hochladen' : 'Logo hochladen'}
            </button>
            {logoUrl && (
              <button onClick={handleDeleteLogo}
                className="flex items-center gap-2 px-4 py-2 border border-red-200 rounded-xl text-sm font-medium text-red-600 hover:bg-red-50 transition">
                <Trash2 size={14} /> Entfernen
              </button>
            )}
          </div>
          <input ref={logoRef} type="file" accept=".png,.jpg,.jpeg,.svg,.webp" className="hidden" onChange={handleLogoUpload} />
        </div>

        <p className="text-xs text-gray-400">
          PNG, JPG oder WebP hochladen — das System generiert automatisch alle drei Varianten.
          Für beste Qualität empfiehlt sich ein transparentes PNG mit min. 800px Breite.
        </p>

        {/* 3 Varianten-Vorschau */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">

          {/* Sidebar-Logo */}
          <div className="space-y-2">
            <div className="flex items-center gap-1.5 text-xs font-medium text-gray-500">
              <Monitor size={12} /> Sidebar
            </div>
            <div className="h-16 border border-gray-200 rounded-xl bg-gray-50 flex items-center justify-center p-2">
              {logoUrl
                ? <img src={logoUrl} alt="Sidebar" className="max-h-full max-w-full object-contain" />
                : <Building2 size={20} className="text-gray-300" />
              }
            </div>
            <p className="text-xs text-gray-400">Original · Sidebar & Login</p>
          </div>

          {/* Berichtskopf */}
          <div className="space-y-2">
            <div className="flex items-center gap-1.5 text-xs font-medium text-gray-500">
              <ImageIcon size={12} /> Berichtskopf
            </div>
            <div className="h-16 border border-gray-200 rounded-xl bg-surface flex items-center justify-center p-2">
              {logoHeaderUrl
                ? <img src={mitCacheBuster(logoHeaderUrl)} alt="Header" className="max-h-full max-w-full object-contain" />
                : <div className="text-xs text-gray-300 text-center">600 × 120 px<br/>für Berichte</div>
              }
            </div>
            <p className="text-xs text-gray-400">Querformat · Berichte & Dokumente</p>
          </div>

          {/* Favicon */}
          <div className="space-y-2">
            <div className="flex items-center gap-1.5 text-xs font-medium text-gray-500">
              <Monitor size={12} /> Browser-Tab
            </div>
            <div className="h-16 border border-gray-200 rounded-xl bg-gray-100 flex items-center gap-3 px-4">
              <div className="w-8 h-8 border border-gray-200 rounded bg-surface flex items-center justify-center flex-shrink-0 overflow-hidden">
                {logoFaviconUrl
                  ? <img src={mitCacheBuster(logoFaviconUrl)} alt="Favicon" className="w-full h-full object-contain" />
                  : <Monitor size={14} className="text-gray-300" />
                }
              </div>
              <div className="text-xs text-gray-500 min-w-0">
                <div className="font-medium truncate">{companyName || 'DeineZeit'}</div>
                <div className="text-gray-400">Browser-Tab</div>
              </div>
            </div>
            <p className="text-xs text-gray-400">32 × 32 px · Automatisch generiert</p>
          </div>

        </div>

        {/* Schieber: Sidebar-Logo-Quelle (Logo oder Favicon) */}
        <div className="flex items-center justify-between border border-gray-200 rounded-xl px-4 py-3">
          <div className="min-w-0 pr-4">
            <p className="text-sm font-medium text-gray-700">Sidebar-Logo</p>
            <p className="text-xs text-gray-400">Wähle, ob die Sidebar das Original-Logo oder das Favicon anzeigt</p>
          </div>
          <div className="flex items-center gap-2 flex-shrink-0">
            <span className={`text-xs font-medium ${sidebarLogoSource === 'logo' ? 'text-gray-800' : 'text-gray-400'}`}>Logo</span>
            <button
              type="button"
              role="switch"
              aria-checked={sidebarLogoSource === 'favicon'}
              onClick={() => handleSidebarSourceChange(sidebarLogoSource === 'favicon' ? 'logo' : 'favicon')}
              className={`relative w-10 h-5 rounded-full transition-colors ${
                sidebarLogoSource === 'favicon' ? 'bg-primary-600' : 'bg-gray-300'
              }`}
              title="Sidebar-Logo umschalten"
            >
              <span className={`absolute top-0.5 left-0.5 w-4 h-4 bg-surface rounded-full shadow transition-transform ${
                sidebarLogoSource === 'favicon' ? 'translate-x-5' : ''
              }`} />
            </button>
            <span className={`text-xs font-medium ${sidebarLogoSource === 'favicon' ? 'text-gray-800' : 'text-gray-400'}`}>Favicon</span>
          </div>
        </div>
      </div>

      <hr className="border-gray-100" />

      {/* Favicon */}
      <div className="space-y-3">
        <h3 className="text-sm font-semibold text-gray-500 uppercase tracking-wide">Favicon (Browser-Tab)</h3>
        <p className="text-xs text-gray-400">
          Beim Logo-Upload wird der Favicon automatisch als 32×32 Variante generiert.
          Du kannst auch ein eigenes Favicon hochladen — z.B. ein Icon ohne Text.
        </p>

        <div className="flex items-center gap-4">
          {/* Vorschau */}
          <div className="flex-shrink-0">
            {logoFaviconUrl ? (
              <div className="w-16 h-16 border border-gray-200 rounded-xl bg-gray-50 flex items-center justify-center p-2 overflow-hidden">
                <img
                  src={mitCacheBuster(logoFaviconUrl)}
                  alt="Favicon"
                  className="w-8 h-8 object-contain"
                />
              </div>
            ) : (
              <div className="w-16 h-16 border-2 border-dashed border-gray-300 rounded-xl flex items-center justify-center text-gray-300">
                <Monitor size={20} />
              </div>
            )}
          </div>

          {/* Buttons */}
          <div className="flex flex-col gap-2">
            <div className="flex gap-2">
              <button onClick={handleFaviconAutoGenerate} disabled={!logoUrl}
                className="flex items-center gap-2 px-4 py-2 border border-gray-300 rounded-xl text-sm font-medium text-gray-700 hover:bg-gray-50 disabled:opacity-40 transition">
                <RefreshCw size={14} />
                Aus Logo generieren
              </button>
              <button onClick={() => favRef.current?.click()} disabled={favUploading}
                className="flex items-center gap-2 px-4 py-2 border border-gray-300 rounded-xl text-sm font-medium text-gray-700 hover:bg-gray-50 transition">
                {favUploading ? <Loader2 size={14} className="animate-spin" /> : <Upload size={14} />}
                Eigenes hochladen
              </button>
            </div>
            <p className="text-xs text-gray-400">PNG, JPG oder ICO · wird auf 32×32 px skaliert</p>
          </div>
        </div>

        <input ref={favRef} type="file" accept=".png,.jpg,.jpeg,.ico" className="hidden" onChange={handleFaviconUpload} />
      </div>

      <hr className="border-gray-100" />

      {/* Firmen-Kontakt */}
      <div className="space-y-4">
        <h3 className="text-sm font-semibold text-gray-500 uppercase tracking-wide">Firmen-Kontakt (Briefkopf)</h3>
        <p className="text-xs text-gray-400">
          Verknüpfe einen Kontakt aus den Stammdaten als offizielle Firmenadresse —
          diese Daten werden als Briefkopf auf Rechnungen und Dokumenten verwendet.
        </p>

        {contactGroups.length === 0 ? (
          <div className="p-4 border border-dashed border-gray-200 rounded-xl text-sm text-gray-400 text-center">
            Keine Stammdaten-Einträge vorhanden. Zuerst einen Kontakt in den Stammdaten anlegen.
          </div>
        ) : (
          <div className="space-y-3">
            <Field label="Kontakt auswählen">
              <select
                value={selectedContact.id}
                onChange={e => {
                  const id = e.target.value
                  const found = allContacts.find(c => c.id === id)
                  setSelectedContact({ id, type: found?.type_slug || '' })
                }}
                className="w-full px-3 py-2 border border-gray-300 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-primary-500"
              >
                <option value="">— Kein Kontakt ausgewählt —</option>
                {contactGroups.map(group => (
                  <optgroup key={group.type_slug} label={group.type_name}>
                    {group.records.map(r => (
                      <option key={r.id} value={r.id}>{r.display_name}</option>
                    ))}
                  </optgroup>
                ))}
              </select>
            </Field>

            {selectedContact.id && selectedName && (
              <div className="flex items-center gap-2 px-3 py-2 bg-primary-50 border border-primary-200 rounded-xl text-sm text-primary-700">
                <Link2 size={14} />
                <span>Verknüpft mit: <strong>{selectedName}</strong></span>
              </div>
            )}

            <div className="flex justify-end">
              <button onClick={handleContactSave} disabled={contactSaving}
                className="flex items-center gap-2 px-5 py-2.5 bg-primary-600 hover:bg-primary-700 disabled:bg-primary-300 text-white font-medium rounded-xl transition">
                {contactSaving ? <Loader2 size={15} className="animate-spin" /> : <Save size={15} />}
                Kontakt-Verknüpfung speichern
              </button>
            </div>
          </div>
        )}
      </div>

    </div>
  )
}

// ── Tab: Design ───────────────────────────────────────────────────────────────
// Mini-Vorschau einer Designvorlage (stilisierte App-Ansicht aus Vorschaufarben)
function DesignMiniVorschau({ p }) {
  return (
    <div className="w-full h-20 rounded-lg overflow-hidden border flex" style={{ background: p.page, borderColor: p.border }}>
      <div className="w-1/4 h-full border-r" style={{ background: p.sidebar, borderColor: p.border }}>
        <div className="mx-1.5 mt-1.5 h-1.5 rounded-sm opacity-70" style={{ background: p.sidebar === '#ffffff' ? p.border : 'rgba(255,255,255,0.55)' }} />
        <div className="mx-1.5 mt-1 h-1 rounded-sm opacity-50" style={{ background: p.sidebar === '#ffffff' ? p.border : 'rgba(255,255,255,0.35)' }} />
        <div className="mx-1.5 mt-1 h-1 rounded-sm opacity-50" style={{ background: p.sidebar === '#ffffff' ? p.border : 'rgba(255,255,255,0.35)' }} />
      </div>
      <div className="flex-1 p-1.5 space-y-1.5">
        <div className="flex gap-1.5">
          <div className="flex-1 h-6 border" style={{ background: p.surface, borderColor: p.border, borderRadius: p.radius }} />
          <div className="flex-1 h-6 border" style={{ background: p.surface, borderColor: p.border, borderRadius: p.radius }} />
        </div>
        <div className="h-8 border p-1" style={{ background: p.surface, borderColor: p.border, borderRadius: p.radius }}>
          <div className="h-1 w-3/4 rounded-sm" style={{ background: p.text, opacity: 0.65 }} />
          <div className="h-1 w-1/2 rounded-sm mt-1" style={{ background: p.text, opacity: 0.3 }} />
        </div>
      </div>
    </div>
  )
}

// Farbwähler mit „Vorlagenwert"-Zustand (leer = Vorlage bestimmt die Farbe)
function OverrideFarbe({ label, value, onChange }) {
  return (
    <div className="flex items-center justify-between gap-3 p-3 border border-gray-200 rounded-xl">
      <span className="text-sm text-gray-700">{label}</span>
      <div className="flex items-center gap-2">
        {value ? (
          <button onClick={() => onChange('')} className="text-xs text-gray-400 hover:text-gray-600 underline">
            zurücksetzen
          </button>
        ) : (
          <span className="text-xs text-gray-400">Vorlagenwert</span>
        )}
        <input type="color" value={value || '#888888'}
          onChange={(e) => onChange(e.target.value)}
          className="w-9 h-7 rounded border border-gray-200 cursor-pointer" />
      </div>
    </div>
  )
}

function TabDesign({ settings, onSaved }) {
  const [design, setDesign] = useState(settings.design_template || 'standard')
  const [theme, setTheme] = useState(settings.color_theme || 'orange')
  const [brandColor, setBrandColor] = useState(settings.brand_color || '')
  const [textColor, setTextColor] = useState(settings.custom_text_color || '')
  const [bgColor, setBgColor] = useState(settings.custom_bg_color || '')
  const [surfaceColor, setSurfaceColor] = useState(settings.custom_surface_color || '')
  const [saving, setSaving] = useState(false)
  const { updateSettings } = useSettings()

  // Live-Vorschau: Änderungen sofort global anwenden (persistiert wird erst
  // beim Speichern; ohne Speichern gilt nach dem nächsten Laden wieder der
  // gespeicherte Stand)
  const live = (partial) => updateSettings(partial)

  const waehleDesign = (id) => { setDesign(id); live({ design_template: id }) }
  const waehleTheme = (id) => { setTheme(id); setBrandColor(''); live({ color_theme: id, brand_color: '' }) }
  const waehleBrand = (hex) => { setBrandColor(hex); live({ brand_color: hex }) }

  const handleSave = async () => {
    setSaving(true)
    try {
      const payload = {
        design_template:      design,
        color_theme:          theme,
        brand_color:          brandColor,
        custom_text_color:    textColor,
        custom_bg_color:      bgColor,
        custom_surface_color: surfaceColor,
      }
      await settingsApi.update(payload)
      updateSettings(payload)
      toast.success('Design gespeichert')
      onSaved()
    } catch { toast.error('Fehler beim Speichern') }
    finally { setSaving(false) }
  }

  return (
    <div className="space-y-8">
      {/* ── Designvorlage ── */}
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-1">Designvorlage</label>
        <p className="text-xs text-gray-400 mb-3">
          Bestimmt Formsprache, Flächen und Stimmung der gesamten App — auf allen Geräten.
          Die Auswahl wird sofort als Vorschau angewendet.
        </p>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          {DESIGN_TEMPLATES.map(d => (
            <button key={d.id} onClick={() => waehleDesign(d.id)}
              className={`text-left p-3 rounded-2xl border-2 transition
                ${design === d.id ? 'border-primary-500 bg-primary-50/40' : 'border-gray-200 hover:border-gray-300'}`}
            >
              <DesignMiniVorschau p={d.preview} />
              <div className="mt-2 flex items-center justify-between">
                <span className="text-sm font-medium text-gray-800">{d.label}</span>
                <span className="text-[10px] font-medium px-1.5 py-0.5 rounded-full bg-gray-100 text-gray-500">{d.stil}</span>
              </div>
              <p className="mt-1 text-[11px] leading-snug text-gray-400">{d.desc}</p>
            </button>
          ))}
        </div>
      </div>

      {/* ── Markenfarbe ── */}
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-3">Markenfarbe</label>
        <div className="grid grid-cols-3 sm:grid-cols-6 gap-3">
          {THEMES.map(t => (
            <button key={t.id} onClick={() => waehleTheme(t.id)}
              className={`flex flex-col items-center gap-2 p-3 rounded-2xl border-2 transition
                ${theme === t.id && !brandColor ? 'border-gray-800 bg-gray-50' : 'border-gray-200 hover:border-gray-300'}`}
            >
              <div className="w-10 h-10 rounded-full shadow-inner" style={{ backgroundColor: t.color }} />
              <span className="text-xs font-medium text-gray-700">{t.label}</span>
              {theme === t.id && !brandColor && <CheckCircle size={14} className="text-gray-700" />}
            </button>
          ))}
        </div>
        <div className={`mt-3 flex items-center justify-between gap-3 p-3 rounded-xl border-2 transition
          ${brandColor ? 'border-gray-800 bg-gray-50' : 'border-gray-200'}`}>
          <div>
            <span className="text-sm font-medium text-gray-700">Eigene Markenfarbe (Whitelabel)</span>
            <p className="text-xs text-gray-400">Beliebiger Farbton, z. B. die Firmenfarbe des Lizenznehmers — übersteuert die Auswahl oben.</p>
          </div>
          <div className="flex items-center gap-2">
            {brandColor && (
              <button onClick={() => waehleBrand('')} className="text-xs text-gray-400 hover:text-gray-600 underline">
                zurücksetzen
              </button>
            )}
            <input type="color" value={brandColor || '#f97316'}
              onChange={(e) => waehleBrand(e.target.value)}
              className="w-10 h-8 rounded border border-gray-200 cursor-pointer" />
          </div>
        </div>
      </div>

      {/* ── Feinanpassung ── */}
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-1">Feinanpassung (optional)</label>
        <p className="text-xs text-gray-400 mb-3">
          Überschreibt einzelne Farben der gewählten Vorlage. Leer = Vorlage bestimmt die Farbe.
        </p>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <OverrideFarbe label="Textfarbe" value={textColor}
            onChange={(v) => { setTextColor(v); live({ custom_text_color: v }) }} />
          <OverrideFarbe label="Hintergrund" value={bgColor}
            onChange={(v) => { setBgColor(v); live({ custom_bg_color: v }) }} />
          <OverrideFarbe label="Flächen / Karten" value={surfaceColor}
            onChange={(v) => { setSurfaceColor(v); live({ custom_surface_color: v }) }} />
        </div>
      </div>

      <p className="text-xs text-gray-400">
        Vorlage und Farben gelten sofort für alle Benutzer — ohne Neustart. Die Vorschau siehst du
        bereits jetzt; endgültig übernommen wird erst beim Speichern.
      </p>

      <div className="pt-2 flex justify-end">
        <button onClick={handleSave} disabled={saving}
          className="flex items-center gap-2 px-5 py-2.5 bg-primary-600 hover:bg-primary-700 disabled:bg-primary-300 text-white font-medium rounded-xl transition">
          {saving ? <Loader2 size={15} className="animate-spin" /> : <Save size={15} />}
          Design übernehmen
        </button>
      </div>
    </div>
  )
}

// ── Cloud-Speicher Vorschläge ─────────────────────────────────────────────────
const CLOUD_PRESETS = [
  {
    id: 'onedrive',
    label: 'OneDrive',
    hint: 'Automatisch mit Microsoft Cloud synchronisiert',
    color: '#0078d4',
    bg: '#eff6ff',
    border: '#bfdbfe',
    path: (user) => `C:\\Users\\${user}\\OneDrive\\Backups\\DeineZeit`,
  },
  {
    id: 'googledrive',
    label: 'Google Drive',
    hint: 'Automatisch mit Google Drive synchronisiert',
    color: '#1a73e8',
    bg: '#f0fdf4',
    border: '#bbf7d0',
    path: (user) => `C:\\Users\\${user}\\Google Drive\\Backups\\DeineZeit`,
  },
  {
    id: 'dropbox',
    label: 'Dropbox',
    hint: 'Automatisch mit Dropbox synchronisiert',
    color: '#0061ff',
    bg: '#f5f3ff',
    border: '#ddd6fe',
    path: (user) => `C:\\Users\\${user}\\Dropbox\\DeineZeit-Backup`,
  },
]

// Versucht den Windows-Benutzernamen aus dem Backup-Pfad zu extrahieren
function guessUsername(currentDir) {
  if (!currentDir) return 'IhrName'
  const m = currentDir.match(/^[A-Za-z]:\\[Uu]sers\\([^\\]+)/)
  return m ? m[1] : 'IhrName'
}

// ── Tab: Backup ───────────────────────────────────────────────────────────────
function TabBackup({ settings, onSaved }) {
  const [target,        setTarget]        = useState(settings.backup_target || 'local')
  const [backupDir,     setBackupDir]     = useState(settings.backup_dir            || '')
  const [scheduleTime,  setScheduleTime]  = useState(settings.backup_schedule_time  || '02:00')
  const [keepDays,      setKeepDays]      = useState(settings.backup_keep_days      || '30')
  const [saving,        setSaving]        = useState(false)
  const [downloading,   setDownloading]   = useState(false)
  // OneDrive-Backup-Ziel (analog Speicher-Tab)
  const [odUseGraph,     setOdUseGraph]     = useState(settings.backup_onedrive_use_graph_creds === 'true')
  const [odTenantId,     setOdTenantId]     = useState(settings.backup_onedrive_tenant_id  || '')
  const [odClientId,     setOdClientId]     = useState(settings.backup_onedrive_client_id  || '')
  const [odClientSecret, setOdClientSecret] = useState('')
  const [odDriveType,    setOdDriveType]    = useState(settings.backup_onedrive_drive_type || 'personal')
  const [odSiteId,       setOdSiteId]       = useState(settings.backup_onedrive_site_id    || '')
  const [odUser,         setOdUser]         = useState(settings.backup_onedrive_user       || '')
  const [odFolder,       setOdFolder]       = useState(settings.backup_onedrive_folder     || 'DeineZeit-Backups')
  const [testing,        setTesting]        = useState(false)
  const [testResult,     setTestResult]     = useState(null)
  const [running,        setRunning]        = useState(false)
  const [lastRun,        setLastRun]        = useState(null)

  const isOneDrive = target === 'onedrive'

  // Letzte 3 Backups aus backup_history (JSON-Array von ISO-Strings)
  let history = []
  try { history = JSON.parse(settings.backup_history || '[]') } catch {}

  const username = guessUsername(backupDir || settings.backup_dir)

  const handleSave = async () => {
    setSaving(true)
    try {
      const payload = {
        backup_target:        target,
        backup_schedule_time: scheduleTime,
        backup_keep_days:     keepDays,
      }
      if (isOneDrive) {
        payload.backup_onedrive_use_graph_creds = odUseGraph ? 'true' : 'false'
        payload.backup_onedrive_drive_type      = odDriveType
        payload.backup_onedrive_site_id         = odSiteId
        payload.backup_onedrive_user            = odUser
        payload.backup_onedrive_folder          = odFolder
        if (!odUseGraph) {
          payload.backup_onedrive_tenant_id = odTenantId
          payload.backup_onedrive_client_id = odClientId
          if (odClientSecret) payload.backup_onedrive_client_secret = odClientSecret
        }
      } else {
        payload.backup_dir = backupDir
      }
      await settingsApi.update(payload)
      toast.success('Backup-Einstellungen gespeichert')
      onSaved()
      // Nur beim lokalen Ziel den Windows-Aufgabenplaner via URI-Handler aktualisieren
      if (!isOneDrive) window.location.href = 'deinezeit://update-task'
    } catch (e) { toast.error('Fehler beim Speichern: ' + (e?.response?.data?.detail || e.message)) }
    finally { setSaving(false) }
  }

  const handleTestOnedrive = async () => {
    setTesting(true)
    setTestResult(null)
    try {
      const res = await settingsApi.testBackupOnedrive({
        use_graph_creds: odUseGraph ? 'true' : 'false',
        tenant_id:       odTenantId,
        client_id:       odClientId,
        client_secret:   odClientSecret,
        drive_type:      odDriveType,
        site_id:         odSiteId,
        user:            odUser,
        folder:          odFolder,
      })
      setTestResult(res.data)
    } catch (e) {
      setTestResult({ ok: false, message: e?.response?.data?.detail || e.message })
    } finally { setTesting(false) }
  }

  const handleRunOnedrive = async () => {
    setRunning(true)
    try {
      const res = await settingsApi.runBackup()
      setLastRun({ filename: res.data?.filename, url: res.data?.web_url })
      toast.success('Backup nach OneDrive hochgeladen')
      onSaved()
    } catch (e) {
      toast.error(e?.response?.data?.detail || 'Backup fehlgeschlagen')
    } finally { setRunning(false) }
  }

  const handleDownload = async () => {
    setDownloading(true)
    try {
      const res   = await settingsApi.downloadBackup()
      const url   = window.URL.createObjectURL(new Blob([res.data]))
      const a     = document.createElement('a')
      const cd    = res.headers['content-disposition'] || ''
      const match = cd.match(/filename="?([^"]+)"?/)
      a.href      = url
      a.download  = match ? match[1] : `deinezeit_backup_${new Date().toISOString().slice(0,10)}.zip`
      a.click()
      window.URL.revokeObjectURL(url)
      toast.success('Backup heruntergeladen')
      onSaved()
    } catch (err) {
      toast.error(err.response?.data?.detail || 'Backup fehlgeschlagen')
    } finally { setDownloading(false) }
  }

  const fmtBackupDate = (iso) => {
    try {
      return new Date(iso).toLocaleString('de-AT', {
        weekday: 'short', day: '2-digit', month: '2-digit',
        year: 'numeric', hour: '2-digit', minute: '2-digit'
      })
    } catch { return iso }
  }

  return (
    <div className="space-y-6">

      {/* Backup-Ziel */}
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">Backup-Ziel</label>
        <div className="flex gap-2 flex-wrap">
          {[
            { id: 'local',    icon: '💻', label: 'Lokaler Ordner' },
            { id: 'onedrive', icon: '📁', label: 'OneDrive (Graph)' },
          ].map(t => (
            <button key={t.id} onClick={() => { setTarget(t.id); setTestResult(null) }}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg border text-sm transition-all
                ${target === t.id
                  ? 'bg-primary-50 border-primary-400 text-primary-700 font-medium'
                  : 'bg-surface border-gray-200 text-gray-600 hover:border-gray-300'}`}>
              <span>{t.icon}</span>{t.label}
            </button>
          ))}
        </div>
        <p className="mt-2 text-xs text-gray-500">
          {isOneDrive
            ? 'Der Server erstellt das Backup und lädt es direkt via Microsoft Graph nach OneDrive/SharePoint hoch — unabhängig von einem Windows-PC.'
            : 'Backups werden über den Windows-Aufgabenplaner in einen lokalen bzw. Cloud-Sync-Ordner geschrieben.'}
        </p>
      </div>

      {/* ── Lokales Ziel ── */}
      {!isOneDrive && (<>
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-1 flex items-center gap-2">
          <Cloud size={14} className="text-gray-400" />
          Cloud-Speicher (Schnellauswahl)
        </label>
        <p className="text-xs text-gray-400 mb-3">
          Backups werden im Cloud-Sync-Ordner gespeichert und automatisch hochgeladen.
          Benutzernamen ggf. anpassen.
        </p>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          {CLOUD_PRESETS.map(preset => {
            const suggestedPath = preset.path(username)
            const isActive = backupDir === suggestedPath
            return (
              <button
                key={preset.id}
                onClick={() => setBackupDir(suggestedPath)}
                className={`text-left p-3 rounded-xl border-2 transition ${
                  isActive
                    ? 'border-primary-400 bg-primary-50'
                    : 'border-gray-200 hover:border-gray-300 bg-surface'
                }`}
              >
                <div className="font-medium text-sm text-gray-800 mb-0.5 flex items-center gap-1.5">
                  {isActive && <CheckCircle size={13} className="text-primary-500 flex-shrink-0" />}
                  {preset.label}
                </div>
                <div className="text-xs text-gray-400">{preset.hint}</div>
              </button>
            )
          })}
        </div>
      </div>
      <div>
        <Field label="Backup-Ordner" hint="Lokaler oder Cloud-Sync-Pfad für die Backup-Dateien (.zip: Datenbank + Dateien)">
          <Input value={backupDir} onChange={setBackupDir} placeholder="C:\Backups\DeineZeit" />
        </Field>
      </div>
      <div className="p-3 bg-green-50 border border-green-200 rounded-xl text-xs text-green-700">
        <strong>Automatische Synchronisation:</strong> Änderungen werden innerhalb von 30 Sekunden
        automatisch auf den Windows-Aufgabenplaner übertragen — kein manuelles Ausführen nötig.
      </div>
      </>)}

      {/* ── OneDrive-Ziel (analog Speicher-Tab) ── */}
      {isOneDrive && (
        <div className="space-y-4 p-4 bg-gray-50 rounded-xl border border-gray-200">
          <p className="text-xs text-gray-500">
            Microsoft OneDrive oder SharePoint via Graph API (App-Berechtigung
            <strong> Files.ReadWrite.All</strong> erforderlich). Hinweis: Persönliches OneDrive
            (<em>personal</em>) ist mit App-Zugangsdaten meist nicht erreichbar — für den
            Server-Betrieb <strong>SharePoint / OneDrive for Business</strong> mit Site-ID verwenden.
          </p>
          {/* Graph-Credentials Toggle */}
          <label className="flex items-center gap-3 cursor-pointer">
            <div onClick={() => setOdUseGraph(!odUseGraph)}
              className={`w-10 h-6 rounded-full transition-colors flex items-center px-0.5
                ${odUseGraph ? 'bg-primary-500' : 'bg-gray-300'}`}>
              <div className={`w-5 h-5 bg-surface rounded-full shadow transition-transform
                ${odUseGraph ? 'translate-x-4' : 'translate-x-0'}`} />
            </div>
            <span className="text-sm text-gray-700">Graph-Einstellungen aus E-Mail wiederverwenden</span>
          </label>
          {!odUseGraph && (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <Field label="Tenant-ID">
                <Input value={odTenantId} onChange={setOdTenantId} placeholder="00000000-0000-0000-0000-000000000000" />
              </Field>
              <Field label="Client-ID">
                <Input value={odClientId} onChange={setOdClientId} placeholder="App-Registrierung (Client-ID)" />
              </Field>
              <Field label="Client-Secret" hint={settings.backup_onedrive_client_id ? 'Leer lassen = gespeichertes Secret behalten' : ''}>
                <input type="password" value={odClientSecret} onChange={e => setOdClientSecret(e.target.value)}
                  placeholder="••••••••"
                  className="w-full px-3 py-2 border border-gray-300 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-primary-500" />
              </Field>
            </div>
          )}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <Field label="Laufwerkstyp">
              <select value={odDriveType} onChange={e => setOdDriveType(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-primary-500">
                <option value="personal">Persönliches OneDrive</option>
                <option value="sharepoint">SharePoint / OneDrive for Business</option>
              </select>
            </Field>
            {odDriveType === 'personal' && (
              <Field label="OneDrive-Benutzer (E-Mail/UPN)" hint="Pflicht: App-only greift über /users/{E-Mail}/drive zu (nicht /me)">
                <Input value={odUser} onChange={setOdUser} placeholder="benutzer@firma.at" />
              </Field>
            )}
            {odDriveType === 'sharepoint' && (
              <Field label="Site-ID" hint="SharePoint-Site (z.B. contoso.sharepoint.com,GUID,GUID)">
                <Input value={odSiteId} onChange={setOdSiteId} placeholder="contoso.sharepoint.com,…" />
              </Field>
            )}
            <Field label="Zielverzeichnis in OneDrive" hint="Ordner, in den die Backup-Archive (.zip: Datenbank + Dateien) geschrieben werden">
              <Input value={odFolder} onChange={setOdFolder} placeholder="DeineZeit-Backups" />
            </Field>
          </div>

          <div className="flex items-center gap-3 flex-wrap">
            <button onClick={handleTestOnedrive} disabled={testing}
              className="flex items-center gap-2 px-4 py-2 bg-surface border border-gray-300 hover:border-gray-400 disabled:opacity-50 text-gray-700 text-sm font-medium rounded-xl transition">
              {testing ? <Loader2 size={15} className="animate-spin" /> : <Cloud size={15} />}
              Verbindung testen
            </button>
            {testResult && (
              <span className={`text-sm flex items-center gap-1.5 ${testResult.ok ? 'text-green-600' : 'text-red-600'}`}>
                {testResult.ok ? <CheckCircle size={15} /> : <XCircle size={15} />}
                {testResult.message}
              </span>
            )}
          </div>
        </div>
      )}

      <hr className="border-gray-100" />

      {/* Zeitplan / Aufbewahrung (für beide Ziele) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <Field label="Tägliche Backup-Zeit" hint={isOneDrive ? 'Uhrzeit für das automatische Server-Backup' : 'Uhrzeit für den automatischen Windows-Task'}>
          <Input value={scheduleTime} onChange={setScheduleTime} placeholder="02:00" />
        </Field>
        <Field label="Aufbewahrung" hint={isOneDrive ? 'Ältere Backups im Zielordner werden automatisch gelöscht' : undefined}>
          <select value={keepDays} onChange={e => setKeepDays(e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-primary-500">
            <option value="7">7 Tage</option>
            <option value="14">14 Tage</option>
            <option value="30">30 Tage</option>
            <option value="60">60 Tage</option>
            <option value="90">90 Tage</option>
            <option value="365">1 Jahr</option>
          </select>
        </Field>
      </div>

      <div className="flex justify-end">
        <button onClick={handleSave} disabled={saving}
          className="flex items-center gap-2 px-5 py-2.5 bg-primary-600 hover:bg-primary-700 disabled:bg-primary-300 text-white font-medium rounded-xl transition">
          {saving ? <Loader2 size={15} className="animate-spin" /> : <Save size={15} />}
          Einstellungen speichern
        </button>
      </div>

      <hr className="border-gray-100" />

      {/* Manuelles Backup */}
      <div className="p-4 border border-gray-200 rounded-2xl bg-gray-50 space-y-3">
        <div>
          <p className="text-sm font-medium text-gray-700">Backup jetzt erstellen</p>
          <p className="text-xs text-gray-400 mt-0.5">
            {isOneDrive
              ? 'Erstellt sofort einen vollständigen Datenbank-Dump und lädt ihn nach OneDrive hoch.'
              : 'Erstellt sofort einen vollständigen Datenbank-Dump und lädt ihn in deinen Download-Ordner.'}
          </p>
        </div>
        {isOneDrive ? (
          <div className="space-y-2">
            <button onClick={handleRunOnedrive} disabled={running}
              className="flex items-center gap-2 px-5 py-2.5 bg-gray-800 hover:bg-gray-900 disabled:bg-gray-400 text-white text-sm font-medium rounded-xl transition">
              {running
                ? <><Loader2 size={15} className="animate-spin" /> Sichere nach OneDrive…</>
                : <><Cloud size={15} /> Jetzt nach OneDrive sichern</>}
            </button>
            {lastRun && (
              <div className="text-xs text-gray-600">
                <CheckCircle size={13} className="inline text-green-500 mr-1" />
                {lastRun.filename} hochgeladen
                {lastRun.url && <> — <a href={lastRun.url} target="_blank" rel="noreferrer" className="text-primary-600 underline break-all">in OneDrive öffnen</a></>}
              </div>
            )}
          </div>
        ) : (
          <button onClick={handleDownload} disabled={downloading}
            className="flex items-center gap-2 px-5 py-2.5 bg-gray-800 hover:bg-gray-900 disabled:bg-gray-400 text-white text-sm font-medium rounded-xl transition">
            {downloading
              ? <><Loader2 size={15} className="animate-spin" /> Erstelle Backup…</>
              : <><Download size={15} /> Backup herunterladen</>}
          </button>
        )}
      </div>

      <hr className="border-gray-100" />

      {/* Letzte 3 Backups */}
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-3">Letzte Backups</label>
        {history.length === 0 ? (
          <p className="text-sm text-gray-400">Noch kein Backup aufgezeichnet.</p>
        ) : (
          <div className="divide-y divide-gray-100 border border-gray-200 rounded-xl overflow-hidden">
            {history.map((iso, i) => (
              <div key={i} className="flex items-center gap-3 px-4 py-3 bg-surface">
                <div className={`w-2 h-2 rounded-full flex-shrink-0 ${i === 0 ? 'bg-green-400' : 'bg-gray-300'}`} />
                <span className="text-sm text-gray-700">{fmtBackupDate(iso)}</span>
                {i === 0 && <span className="ml-auto text-xs text-green-600 font-medium">Letztes</span>}
              </div>
            ))}
          </div>
        )}
      </div>

    </div>
  )
}

// ── E-Mail-Anbieter ───────────────────────────────────────────────────────────
const EMAIL_PROVIDERS = [
  {
    id:       'office365',
    label:    'Office 365',
    emoji:    '🏢',
    mode:     'graph',   // nutzt Microsoft Graph API
    hint:     null,      // Anleitung wird separat als GraphGuide gerendert
  },
  {
    id:       'gmail',
    label:    'Gmail',
    emoji:    '📧',
    mode:     'smtp',
    host:     'smtp.gmail.com',
    port:     '587',
    tls:      true,
    hint: {
      type: 'info',
      text: 'Bei aktivierter 2-Faktor-Authentifizierung muss ein App-Passwort verwendet werden: Google-Konto → Sicherheit → App-Passwörter. Das normale Google-Passwort funktioniert dann nicht.',
    },
  },
  {
    id:       'gmx',
    label:    'GMX',
    emoji:    '📬',
    mode:     'smtp',
    host:     'smtp.gmx.net',
    port:     '587',
    tls:      true,
    hint: {
      type: 'info',
      text: 'SMTP-Zugang in GMX aktivieren: Einstellungen → E-Mail → POP3/IMAP Abruf → SMTP-Zugang aktivieren.',
    },
  },
  {
    id:       'webde',
    label:    'web.de',
    emoji:    '📮',
    mode:     'smtp',
    host:     'smtp.web.de',
    port:     '587',
    tls:      true,
    hint: {
      type: 'info',
      text: 'SMTP-Zugang in web.de aktivieren: Einstellungen → E-Mail → Externe Programme.',
    },
  },
  {
    id:       'custom',
    label:    'Eigener Server',
    emoji:    '🖥️',
    mode:     'smtp',
    host:     null,
    port:     null,
    tls:      null,
    hint:     null,
  },
]

// ── Azure-Schritt-für-Schritt-Anleitung (Office 365 / Graph) ─────────────────
function GraphGuide() {
  const [open, setOpen] = useState(true)
  const steps = [
    {
      num: '1',
      title: 'App in Azure AD registrieren',
      body: (
        <>
          Öffne <strong>portal.azure.com</strong> → <strong>Microsoft Entra ID</strong> (früher Azure Active Directory) →{' '}
          <strong>App-Registrierungen</strong> → <strong>Neue Registrierung</strong>.{' '}
          Name frei wählbar (z.&thinsp;B. „DeineZeit Mail"), Kontotyp:{' '}
          <em>Nur Konten in diesem Organisationsverzeichnis</em>. Redirect-URI leer lassen. Klick auf <strong>Registrieren</strong>.
        </>
      ),
    },
    {
      num: '2',
      title: 'API-Berechtigung Mail.Send hinzufügen',
      body: (
        <>
          In der neuen App: <strong>API-Berechtigungen</strong> → <strong>Berechtigung hinzufügen</strong> →{' '}
          <strong>Microsoft Graph</strong> → <strong>Anwendungsberechtigungen</strong> → Suche nach{' '}
          <code className="bg-blue-100 px-1 rounded">Mail.Send</code> → Haken setzen → <strong>Berechtigungen hinzufügen</strong>.{' '}
          Danach: <strong>Administratorzustimmung erteilen</strong> (blauer Button) → bestätigen.{' '}
          Der Status muss auf <em>✅ Gewährt</em> wechseln.
        </>
      ),
    },
    {
      num: '3',
      title: 'Client-Secret erstellen',
      body: (
        <>
          <strong>Zertifikate &amp; Geheimnisse</strong> → <strong>Neuer geheimer Clientschlüssel</strong> →{' '}
          Beschreibung eingeben, Ablauf wählen (empfohlen: 24 Monate) → <strong>Hinzufügen</strong>.{' '}
          Den angezeigten <strong>Wert</strong> sofort kopieren — er wird danach nicht mehr vollständig angezeigt!
        </>
      ),
    },
    {
      num: '4',
      title: 'IDs aus der Übersicht kopieren',
      body: (
        <>
          Zurück zur <strong>Übersicht</strong> der App-Registrierung. Dort findest du:{' '}
          <strong>Anwendungs-ID (Client)</strong> und <strong>Verzeichnis-ID (Mandant / Tenant)</strong>.{' '}
          Beide Werte unten eintragen.
        </>
      ),
    },
    {
      num: '5',
      title: 'Absender-Postfach',
      body: (
        <>
          Das Konto unter <strong>Absender-E-Mail</strong> muss ein echtes Postfach in deinem Microsoft 365-Tenant sein{' '}
          (z.&thinsp;B. <code className="bg-blue-100 px-1 rounded">noreply@firma.at</code>).{' '}
          Die App sendet im Namen dieses Postfachs — dafür ist keine MFA oder SMTP-AUTH nötig.
        </>
      ),
    },
  ]

  return (
    <div className="rounded-xl border border-blue-200 bg-blue-50 overflow-hidden text-sm">
      <button
        type="button"
        onClick={() => setOpen(o => !o)}
        className="w-full flex items-center justify-between px-4 py-3 text-blue-800 font-medium hover:bg-blue-100 transition"
      >
        <span className="flex items-center gap-2">
          <span>🔷</span>
          Schritt-für-Schritt: App in Azure AD einrichten
        </span>
        <span className="text-blue-400">{open ? <ChevronUp size={16}/> : <ChevronDown size={16}/>}</span>
      </button>
      {open && (
        <div className="px-4 pb-4 space-y-4 text-blue-900">
          <p className="text-xs text-blue-600 -mt-1">
            Einmalige Einrichtung · dauert ca. 5 Minuten · du brauchst Global-Admin-Rechte in Microsoft 365
          </p>
          <ol className="space-y-4">
            {steps.map(s => (
              <li key={s.num} className="flex gap-3">
                <span className="flex-shrink-0 w-6 h-6 rounded-full bg-blue-600 text-white text-xs font-bold flex items-center justify-center mt-0.5">
                  {s.num}
                </span>
                <div>
                  <p className="font-semibold mb-0.5">{s.title}</p>
                  <p className="leading-relaxed text-blue-800">{s.body}</p>
                </div>
              </li>
            ))}
          </ol>
          <div className="mt-3 p-3 bg-blue-100 rounded-lg text-xs text-blue-700 leading-relaxed">
            <strong>Warum Graph API statt SMTP?</strong> Microsoft deaktiviert zunehmend die klassische SMTP-Authentifizierung
            (Basic Auth). Mit Graph API und Client Credentials funktioniert der Versand zuverlässig — auch wenn
            Security Defaults oder MFA aktiv sind, ohne dass ein Passwort gespeichert werden muss.
          </div>
        </div>
      )}
    </div>
  )
}

// ── Passwort-Feld mit Sichtbarkeits-Toggle ────────────────────────────────────
function SecretInput({ value, onChange, placeholder = '••••••••', hint }) {
  const [show, setShow] = useState(false)
  return (
    <Field label={null} hint={hint}>
      <div className="relative">
        <input
          type={show ? 'text' : 'password'} value={value}
          onChange={e => onChange(e.target.value)}
          placeholder={placeholder}
          className="w-full px-3 py-2 pr-10 border border-gray-300 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-primary-500"
        />
        <button type="button" onClick={() => setShow(s => !s)} aria-label={show ? 'Wert verbergen' : 'Wert anzeigen'}
          className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600">
          {show ? <EyeOff size={14}/> : <Eye size={14}/>}
        </button>
      </div>
    </Field>
  )
}

// ── Tab: E-Mail ───────────────────────────────────────────────────────────────
function TabEmail({ settings, onSaved }) {
  // Gemeinsam
  const [fromName,    setFromName]    = useState(settings.smtp_from_name  || '')
  const [fromEmail,   setFromEmail]   = useState(settings.smtp_from_email || '')
  // SMTP
  const [host,        setHost]        = useState(settings.smtp_host  || '')
  const [port,        setPort]        = useState(settings.smtp_port  || '587')
  const [user,        setUser]        = useState(settings.smtp_user  || '')
  const [password,    setPassword]    = useState('')
  const [tls,         setTls]         = useState(settings.smtp_tls !== 'false')
  // Graph
  const [tenantId,    setTenantId]    = useState(settings.ms_tenant_id  || '')
  const [clientId,    setClientId]    = useState(settings.ms_client_id  || '')
  const [clientSecret, setClientSecret] = useState('')

  const [saving,      setSaving]      = useState(false)
  const [testEmail,   setTestEmail]   = useState('')
  const [testing,     setTesting]     = useState(false)

  // Aktiver Anbieter: aus gespeichertem email_provider ableiten, sonst erste Auswahl
  const savedProvider = settings.email_provider === 'graph' ? 'office365' : (
    settings.smtp_host === 'smtp.gmail.com' ? 'gmail' :
    settings.smtp_host === 'smtp.gmx.net'   ? 'gmx'   :
    settings.smtp_host === 'smtp.web.de'    ? 'webde'  :
    settings.smtp_host                      ? 'custom' : null
  )
  const [activeProvider, setActiveProvider] = useState(savedProvider)

  const isGraph = activeProvider === 'office365'

  const selectProvider = (provider) => {
    setActiveProvider(provider.id)
    if (provider.mode === 'smtp' && provider.host !== null) {
      setHost(provider.host)
      setPort(provider.port)
      setTls(provider.tls)
    }
  }

  const currentHint = EMAIL_PROVIDERS.find(p => p.id === activeProvider)?.hint

  const handleSave = async () => {
    setSaving(true)
    try {
      const payload = {
        email_provider: isGraph ? 'graph' : 'smtp',
        smtp_from_name:  fromName,
        smtp_from_email: fromEmail,
      }
      if (isGraph) {
        payload.ms_tenant_id = tenantId
        payload.ms_client_id = clientId
        if (clientSecret) payload.ms_client_secret = clientSecret
      } else {
        payload.smtp_host = host
        payload.smtp_port = port
        payload.smtp_user = user
        payload.smtp_tls  = tls ? 'true' : 'false'
        if (password) payload.smtp_password = password
      }
      await settingsApi.update(payload)
      toast.success('E-Mail-Einstellungen gespeichert')
      setPassword('')
      setClientSecret('')
      onSaved()
    } catch { toast.error('Fehler beim Speichern') }
    finally { setSaving(false) }
  }

  const handleTest = async () => {
    if (!testEmail) return toast.error('Bitte eine Empfänger-E-Mail eingeben')
    setTesting(true)
    try {
      const res = await settingsApi.testEmail(testEmail)
      toast.success(res.data.message || 'Test-Mail gesendet!')
    } catch (err) {
      toast.error(err.response?.data?.detail || 'Versand fehlgeschlagen')
    } finally { setTesting(false) }
  }

  const canTest = isGraph ? (tenantId && clientId && fromEmail) : !!host

  return (
    <div className="space-y-5">

      {/* Anbieter-Auswahl */}
      <div>
        <p className="text-sm font-medium text-gray-700 mb-2">Anbieter auswählen</p>
        <div className="flex flex-wrap gap-2">
          {EMAIL_PROVIDERS.map(provider => (
            <button
              key={provider.id}
              type="button"
              onClick={() => selectProvider(provider)}
              className={`flex items-center gap-2 px-3 py-2 rounded-xl border-2 text-sm font-medium transition ${
                activeProvider === provider.id
                  ? 'border-primary-500 bg-primary-50 text-primary-700'
                  : 'border-gray-200 text-gray-600 hover:border-gray-300 hover:bg-gray-50'
              }`}
            >
              <span>{provider.emoji}</span>
              {provider.label}
              {provider.mode === 'graph' && (
                <span className="text-xs bg-blue-100 text-blue-700 px-1.5 py-0.5 rounded-full font-normal">Graph API</span>
              )}
            </button>
          ))}
        </div>
      </div>

      {/* Gemeinsame Felder: Absender */}
      {activeProvider && (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <Field label="Absender-Name">
            <Input value={fromName} onChange={setFromName} placeholder="DeineZeit" />
          </Field>
          <Field label="Absender-E-Mail">
            <Input value={fromEmail} onChange={setFromEmail} placeholder="noreply@firma.at" type="email" />
          </Field>
        </div>
      )}

      {/* ── Office 365 / Graph API ── */}
      {isGraph && (
        <div className="space-y-4">
          <GraphGuide />

          <div className="grid grid-cols-1 gap-4">
            <Field label="Tenant-ID (Verzeichnis-ID)" hint="Aus der App-Übersicht in Azure AD → Verzeichnis-ID">
              <Input value={tenantId} onChange={setTenantId} placeholder="xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx" />
            </Field>
            <Field label="Client-ID (Anwendungs-ID)" hint="Aus der App-Übersicht in Azure AD → Anwendungs-ID">
              <Input value={clientId} onChange={setClientId} placeholder="xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx" />
            </Field>
            <Field label="Client-Secret" hint="Leer lassen um das gespeicherte Secret zu behalten">
              <SecretInput
                value={clientSecret}
                onChange={setClientSecret}
                placeholder="Neues Secret eingeben (leer = gespeichertes behalten)"
              />
            </Field>
          </div>
        </div>
      )}

      {/* ── SMTP (alle anderen Anbieter) ── */}
      {!isGraph && activeProvider && (
        <div className="space-y-4">
          {/* SMTP-Hinweis des Anbieters */}
          {currentHint && (
            <div className={`p-4 rounded-xl text-sm ${
              currentHint.type === 'warning'
                ? 'bg-amber-50 border border-amber-200 text-amber-800'
                : 'bg-blue-50 border border-blue-200 text-blue-800'
            }`}>
              <div className="flex gap-2 mb-1 font-medium">
                <span>{currentHint.type === 'warning' ? '⚠️' : 'ℹ️'}</span>
                <span>Hinweis</span>
              </div>
              <p className="leading-relaxed ml-6">{currentHint.text}</p>
            </div>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <Field label="SMTP-Server (Host)">
              <Input value={host} onChange={setHost} placeholder="smtp.example.com" />
            </Field>
            <Field label="Port">
              <Input value={port} onChange={setPort} placeholder="587" />
            </Field>
            <Field label="Benutzername">
              <Input value={user} onChange={setUser} placeholder="user@example.com" />
            </Field>
            <Field label="Passwort" hint="Leer lassen um das gespeicherte Passwort zu behalten">
              <SecretInput value={password} onChange={setPassword} />
            </Field>
          </div>

          <div className="flex items-center gap-3">
            <input type="checkbox" id="tls" checked={tls} onChange={e => setTls(e.target.checked)}
              className="w-4 h-4 rounded accent-primary-600" />
            <label htmlFor="tls" className="text-sm font-medium text-gray-700 cursor-pointer">
              STARTTLS verwenden (empfohlen für Port 587)
            </label>
          </div>
        </div>
      )}

      {/* Speichern */}
      {activeProvider && (
        <div className="flex justify-end pt-1">
          <button onClick={handleSave} disabled={saving}
            className="flex items-center gap-2 px-5 py-2.5 bg-primary-600 hover:bg-primary-700 disabled:bg-primary-300 text-white font-medium rounded-xl transition">
            {saving ? <Loader2 size={15} className="animate-spin" /> : <Save size={15} />}
            Speichern
          </button>
        </div>
      )}

      {activeProvider && <hr className="border-gray-100" />}

      {/* Test-Mail */}
      {activeProvider && (
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">Test-E-Mail senden</label>
          <p className="text-xs text-gray-400 mb-3">
            Zuerst speichern, dann testen.
            {isGraph && ' Verwendet Microsoft Graph API.'}
          </p>
          <div className="flex gap-3">
            <input
              type="email" value={testEmail} onChange={e => setTestEmail(e.target.value)}
              placeholder="empfaenger@example.com"
              className="flex-1 px-3 py-2 border border-gray-300 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-primary-500"
            />
            <button onClick={handleTest} disabled={testing || !canTest}
              className="flex items-center gap-2 px-4 py-2 border border-gray-300 rounded-xl text-sm font-medium text-gray-700 hover:bg-gray-50 disabled:opacity-50 transition">
              {testing ? <Loader2 size={14} className="animate-spin" /> : <Send size={14} />}
              Senden
            </button>
          </div>
          {!canTest && (
            <p className="text-xs text-orange-500 mt-2">
              {isGraph
                ? 'Bitte zuerst Tenant-ID, Client-ID und Absender-E-Mail eingeben und speichern.'
                : 'Bitte zuerst SMTP-Server eingeben und speichern.'}
            </p>
          )}
        </div>
      )}
    </div>
  )
}

// ── Tab: System & Updates ─────────────────────────────────────────────────────
// ── Karte: Zustand des HTTPS-Zertifikats ──────────────────────────────────────
// Beantwortet in einem Blick beide Fragen, die im Ernstfall zählen: Wie lange
// ist das Zertifikat noch gültig — und kümmert sich die Automatik noch darum?
// Die zweite Frage ist die wichtigere: fällt die Erneuerung aus, bleibt das
// Zertifikat noch wochenlang gültig, und niemand merkt etwas.
function SslKarte({ status }) {
  const STILE = {
    ok:         { box: 'bg-green-50 border-green-200',  text: 'text-green-800',  icon: ShieldCheck },
    warnung:    { box: 'bg-amber-50 border-amber-200',  text: 'text-amber-800',  icon: AlertTriangle },
    kritisch:   { box: 'bg-red-50 border-red-200',      text: 'text-red-800',    icon: ShieldAlert },
    abgelaufen: { box: 'bg-red-50 border-red-200',      text: 'text-red-800',    icon: ShieldAlert },
  }
  const stil = STILE[status.status] || STILE.warnung
  const Icon = stil.icon
  const inOrdnung = status.status === 'ok'

  const datum = status.gueltig_bis
    ? new Date(status.gueltig_bis).toLocaleDateString('de-DE',
        { day: '2-digit', month: '2-digit', year: 'numeric' })
    : null

  return (
    <div className={`border rounded-xl p-4 space-y-3 ${stil.box}`}>
      <p className={`text-sm font-medium flex items-start gap-2 ${stil.text}`}>
        <Icon size={16} className="mt-0.5 shrink-0" />
        <span>{status.meldung}</span>
      </p>

      <div className={`text-xs space-y-1 ${stil.text} opacity-90`}>
        {datum && (
          <div>
            Gültig bis <strong>{datum}</strong>
            {typeof status.tage_verbleibend === 'number' &&
              ` (noch ${status.tage_verbleibend} Tage)`}
          </div>
        )}
        {status.automatik_laeuft === true && (
          <div>Automatische Erneuerung: <strong>aktiv</strong></div>
        )}
        {status.automatik_laeuft === false && (
          <div>Automatische Erneuerung: <strong>ausgefallen</strong></div>
        )}
      </div>

      {!inOrdnung && (
        <div className={`text-xs ${stil.text}`}>
          <p className="mb-1.5">Auf dem Server ausführen — das erneuert das
            Zertifikat, startet die Automatik wieder und lässt den Webserver das
            neue Zertifikat einlesen:</p>
          <code className="block bg-white/60 px-3 py-2 rounded-lg font-mono">
            sudo bash /opt/deinezeit/scripts/ssl-renew.sh
          </code>
        </div>
      )}
    </div>
  )
}

function TabSystem() {
  const [versionInfo, setVersionInfo]     = useState(null)
  const [changelog, setChangelog]         = useState('')
  const [showChangelog, setShowChangelog] = useState(false)
  const [loading, setLoading]             = useState(true)
  const [checking, setChecking]           = useState(false)
  const [sslStatus, setSslStatus]         = useState(null)

  useEffect(() => {
    loadVersionInfo()
    loadSslStatus()
  }, [])

  const loadSslStatus = async () => {
    try {
      const res = await systemApi.getSslStatus()
      setSslStatus(res.data)
    } catch { /* ignorieren — die System-Seite soll deswegen nicht leer bleiben */ }
  }

  const loadVersionInfo = async () => {
    setLoading(true)
    try {
      const res = await systemApi.getVersion()
      setVersionInfo(res.data)
    } catch {
      // ignorieren
    } finally {
      setLoading(false)
    }
  }

  const handleCheckUpdate = async () => {
    setChecking(true)
    try {
      const res = await systemApi.getVersion()
      setVersionInfo(res.data)
      if (!res.data.update_available) {
        toast.success('Sie verwenden bereits die neueste Version.')
      } else {
        toast('Eine neuere Version liegt auf GitHub — sie wird automatisch ausgerollt.')
      }
    } catch {
      toast.error('Versionsprüfung fehlgeschlagen.')
    } finally {
      setChecking(false)
    }
  }

  const handleShowChangelog = async () => {
    if (showChangelog) { setShowChangelog(false); return }
    try {
      const res = await systemApi.getChangelog()
      setChangelog(res.data.content)
      setShowChangelog(true)
    } catch {
      toast.error('Changelog konnte nicht geladen werden.')
    }
  }

  const isLocalMode = versionInfo?.local_mode === true

  return (
    <div className="space-y-6">
      {/* Versions-Info */}
      <div>
        <h3 className="text-base font-semibold text-gray-900 mb-3 flex items-center gap-2">
          <Cpu size={16} className="text-primary-500" />
          Versionsinformation
        </h3>

        {loading ? (
          <div className="flex items-center gap-2 text-gray-400 text-sm">
            <Loader2 size={15} className="animate-spin" /> Wird geladen…
          </div>
        ) : (
          <div className="bg-gray-50 rounded-xl p-4 space-y-2 text-sm">
            <div className="flex justify-between">
              <span className="text-gray-500">Installierte Version</span>
              <span className="font-mono font-semibold text-gray-800">v{versionInfo?.current}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-500">Neueste Version</span>
              <span className="font-mono font-semibold text-gray-800">
                {versionInfo?.github_check_ok === false
                  ? <span className="text-amber-600">GitHub nicht erreichbar</span>
                  : `v${versionInfo?.latest}`}
              </span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-gray-500">Status</span>
              {isLocalMode ? (
                <span className="flex items-center gap-1 text-blue-600 font-medium">
                  <Monitor size={13} />
                  Lokale Instanz
                </span>
              ) : versionInfo?.update_available ? (
                <span className="flex items-center gap-1 text-amber-600 font-medium">
                  <AlertTriangle size={13} />
                  Neuere Version auf GitHub — Deploy steht aus
                </span>
              ) : versionInfo?.github_check_ok === false ? (
                <span className="flex items-center gap-1 text-amber-600 font-medium">
                  <AlertTriangle size={13} />
                  Prüfung fehlgeschlagen
                </span>
              ) : (
                <span className="flex items-center gap-1 text-green-600 font-medium">
                  <CheckCircle2 size={13} />
                  Aktuell
                </span>
              )}
            </div>
            {versionInfo?.github_check_ok === false && !isLocalMode && (
              <p className="text-xs text-amber-700 bg-amber-50 rounded-lg px-3 py-2 mt-1">
                GitHub konnte nicht erreicht werden — die Anzeige „Neueste Version" ist deshalb unvollständig.
              </p>
            )}
          </div>
        )}

        <div className="flex gap-2 mt-3">
          <button onClick={handleCheckUpdate} disabled={checking}
            className="btn-secondary text-sm py-1.5 px-3 flex items-center gap-1.5">
            {checking ? <Loader2 size={13} className="animate-spin" /> : <RefreshCw size={13} />}
            Auf Updates prüfen
          </button>
          <button onClick={handleShowChangelog}
            className="btn-secondary text-sm py-1.5 px-3 flex items-center gap-1.5">
            {showChangelog ? <ChevronUp size={13} /> : <ChevronDown size={13} />}
            Änderungsprotokoll
          </button>
        </div>

        {showChangelog && changelog && (
          <div className="mt-3 bg-gray-50 rounded-xl p-4 max-h-64 overflow-y-auto">
            <pre className="text-xs text-gray-700 whitespace-pre-wrap font-sans leading-relaxed">
              {changelog}
            </pre>
          </div>
        )}
      </div>

      <hr className="border-gray-100" />

      {/* HTTPS-Zertifikat — Restlaufzeit und ob sich die Erneuerung noch von
          selbst kümmert. Steht bewusst weit oben: ein abgelaufenes Zertifikat
          sperrt alle Benutzer aus, und man sieht es sonst erst, wenn es zu
          spät ist. */}
      {sslStatus && sslStatus.status !== 'nicht_konfiguriert' && (
        <div>
          <h3 className="text-base font-semibold text-gray-900 mb-3 flex items-center gap-2">
            <Lock size={16} className="text-primary-500" />
            HTTPS-Zertifikat
          </h3>
          <SslKarte status={sslStatus} />
        </div>
      )}

      {sslStatus && sslStatus.status !== 'nicht_konfiguriert' && (
        <hr className="border-gray-100" />
      )}

      {/* Aktualisierung — bewusst OHNE Knopf. Das In-App-Update (Backend baut
          den Server per Docker-Socket neu) wurde am 04.09.2026 gestrichen
          (Audit SEC-002, K-21): Der Docker-Socket im Backend war gleichbedeutend
          mit root auf dem Server. */}
      <div>
        <h3 className="text-base font-semibold text-gray-900 mb-3 flex items-center gap-2">
          <ArrowUpCircle size={16} className="text-primary-500" />
          Aktualisierung
        </h3>
        {isLocalMode ? (
          <div className="bg-blue-50 border border-blue-200 rounded-xl p-4 space-y-2">
            <p className="text-sm font-medium text-blue-800 flex items-center gap-2">
              <Monitor size={15} />
              Lokale Entwicklungsinstanz
            </p>
            <p className="text-sm text-blue-700">
              Um auf eine neue Version zu aktualisieren, bitte im Projektverzeichnis ausführen:
            </p>
            <code className="block mt-2 bg-blue-100 text-blue-900 text-xs px-3 py-2 rounded-lg font-mono">
              git pull &amp;&amp; docker compose -f docker-compose.local.yml up -d --build
            </code>
          </div>
        ) : (
          <div className="bg-gray-50 rounded-xl p-4 text-sm text-gray-600 space-y-1">
            <p>
              Neue Versionen werden <strong>automatisch</strong> eingespielt: Nach jeder
              Änderung auf GitHub prüft die CI den Code, und erst bei grüner Prüfung
              wird der Server aktualisiert (GitHub Actions → „Deploy").
            </p>
            <p className="text-xs text-gray-500">
              Ein Update von Hand ist nicht vorgesehen. Bei Bedarf am Server:
              <code className="ml-1 font-mono">cd /opt/deinezeit &amp;&amp; sudo bash scripts/deploy.sh</code>
            </p>
          </div>
        )}
      </div>

      <hr className="border-gray-100" />

      {/* Angemeldete Sitzungen — auch nützlich vor einem Update oder Lasttest:
          Erst nachsehen, wer arbeitet, dann neu starten. */}
      <SystemSitzungen />
    </div>
  )
}

// ── Tab: Rechnungen ───────────────────────────────────────────────────────────
const TEMPLATE_NAMES = {
  1: 'Klassisch',
  2: 'Modern',
  3: 'Kompakt',
  4: 'Elegant',
  5: 'Farbenfroh',
}

const TEMPLATE_DESCRIPTIONS = {
  1: 'Zweispaltig, Logo rechts — seriöser Stil für alle Branchen',
  2: 'Dunkler Header-Block, minimalistische Typografie',
  3: 'Dichtes Layout, ideal für kurze Rechnungen',
  4: 'Goldene Linie, Serif-Schrift, viel Weißraum',
  5: 'Primärfarbe als Akzent, auffällig und modern',
}

function TabRechnung({ embedded = false }) { // eslint-disable-line
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [customCss, setCustomCss] = useState('')
  const [showCustomEditor, setShowCustomEditor] = useState(false)
  const [previewTemplate, setPreviewTemplate] = useState(null) // null = kein Popup
  const [previewHtml, setPreviewHtml] = useState('')
  const [previewLoading, setPreviewLoading] = useState(false)

  const [bankIban, setBankIban] = useState('')
  const [bankBic, setBankBic] = useState('')
  const [bankName, setBankName] = useState('')
  const [defaultTemplate, setDefaultTemplate] = useState(1)
  const [defaultTaxRate, setDefaultTaxRate] = useState(20)
  const [paymentDays, setPaymentDays] = useState(30)
  // Vorbelegung der Angebots-Bindefrist; 0 = keine Vorbelegung
  const [offerValidDays, setOfferValidDays] = useState(30)
  const [erechnungAktiv, setErechnungAktiv] = useState(false)
  const [kleinunternehmerText, setKleinunternehmerText] = useState('')
  const [contactHint, setContactHint] = useState('')  // Info ob Bankdaten aus Kontakt kamen
  // PDF-Archivierung ins Datacenter. Bewusst OHNE eigenen Vorgabewert — die
  // wirksamen Auslöser kommen vom Backend (auch wenn noch nichts gespeichert
  // ist). Ein Vorgabewert hier würde den echten beim Speichern überschreiben.
  const [archiveTriggers, setArchiveTriggers] = useState([])
  // Steuersätze — ebenfalls ohne eigenen Vorgabewert, die wirksamen Sätze
  // liefert das Backend mit (services/tax_rates.py).
  const [taxRates, setTaxRates] = useState([])
  // Mahnstufen und Zinsparameter, ebenfalls vom Backend vorbelegt
  // (services/dunning.py). Der Basiszinssatz bleibt bewusst leer, solange er
  // nicht gepflegt ist — geraten wird er nicht.
  const [dunningLevels, setDunningLevels] = useState([])
  const [baseRate, setBaseRate] = useState('')
  const [surchargeB2b, setSurchargeB2b] = useState('')
  const [rateB2c, setRateB2c] = useState('')
  const [interestMode, setInterestMode] = useState('auto')

  // Bankfelder aus Kontakt-Daten erkennen (sucht nach IBAN/BIC/Bank in allen Feldern)
  function extractBankFromContact(data) {
    if (!data) return {}
    const result = {}
    const keys = Object.keys(data)
    for (const k of keys) {
      const kl = k.toLowerCase()
      const v = String(data[k] || '').trim()
      if (!v) continue
      if (!result.iban && (kl.includes('iban'))) result.iban = v
      if (!result.bic  && (kl.includes('bic') || kl.includes('swift'))) result.bic = v
      if (!result.bank && (kl.includes('bank') && !kl.includes('iban') && !kl.includes('bic'))) result.bank = v
    }
    return result
  }

  useEffect(() => {
    Promise.all([
      invoiceApi.getSettings(),
      settingsApi.getCompanyContact(),
    ]).then(([invRes, contactRes]) => {
      const s = invRes.data
      const bank = s.bank || {}
      const savedIban = typeof bank === 'object' ? bank.iban || '' : ''
      const savedBic  = typeof bank === 'object' ? bank.bic  || '' : ''
      const savedBank = typeof bank === 'object' ? bank.bank || '' : ''
      setBankIban(savedIban); setBankBic(savedBic); setBankName(savedBank)
      setDefaultTemplate(s.default_template || 1)
      setCustomCss(s.custom_template_css || '')
      setDefaultTaxRate(s.default_tax_rate || 20)
      setPaymentDays(s.default_payment_days || 30)
      setOfferValidDays(s.default_offer_valid_days ?? 30)
      setErechnungAktiv(!!s.erechnung_aktiv)
      setKleinunternehmerText(typeof s.kleinunternehmer_text === 'string' ? s.kleinunternehmer_text.replace(/^"|"$/g, '') : '')
      if (Array.isArray(s.archive_triggers)) setArchiveTriggers(s.archive_triggers)
      if (Array.isArray(s.tax_rates)) setTaxRates(s.tax_rates)
      if (Array.isArray(s.dunning_levels)) setDunningLevels(s.dunning_levels)
      setBaseRate(s.dunning_base_rate ?? '')
      setSurchargeB2b(s.dunning_surcharge_b2b ?? '')
      setRateB2c(s.dunning_rate_b2c ?? '')
      setInterestMode(s.dunning_interest_mode || 'auto')
      const contact = contactRes.data?.contact
      if (contact?.data) {
        const fc = extractBankFromContact(contact.data)
        if (!savedIban && fc.iban) setBankIban(fc.iban)
        if (!savedBic  && fc.bic)  setBankBic(fc.bic)
        if (!savedBank && fc.bank) setBankName(fc.bank)
        if (fc.iban || fc.bic || fc.bank) setContactHint(`Bankdaten aus Kontakt "${contact.display_name}" übernommen`)
      }
    }).catch(() => {}).finally(() => setLoading(false))
  }, [])

  async function handleSave() {
    setSaving(true)
    try {
      await Promise.all([
        invoiceApi.updateSetting('bank', { iban: bankIban, bic: bankBic, bank: bankName }),
        invoiceApi.updateSetting('default_template', Number(defaultTemplate)),
        invoiceApi.updateSetting('default_tax_rate', Number(defaultTaxRate)),
        invoiceApi.updateSetting('default_payment_days', Number(paymentDays)),
        invoiceApi.updateSetting('default_offer_valid_days', Number(offerValidDays)),
        invoiceApi.updateSetting('erechnung_aktiv', erechnungAktiv),
        invoiceApi.updateSetting('kleinunternehmer_text', kleinunternehmerText),
        invoiceApi.updateSetting('archive_triggers', archiveTriggers),
        invoiceApi.updateSetting('tax_rates', taxRates),
        invoiceApi.updateSetting('dunning_levels', dunningLevels),
        // Leerer Basiszinssatz bleibt leer: Dann rechnet das Mahnwesen
        // bewusst keine Verzugszinsen, statt mit 0 % zu tun als wären es keine.
        invoiceApi.updateSetting('dunning_base_rate', baseRate === '' ? null : Number(baseRate)),
        invoiceApi.updateSetting('dunning_surcharge_b2b', Number(surchargeB2b || 0)),
        invoiceApi.updateSetting('dunning_rate_b2c', Number(rateB2c || 0)),
        invoiceApi.updateSetting('dunning_interest_mode', interestMode),
        showCustomEditor && invoiceApi.updateSetting('custom_template_css', customCss),
      ].filter(Boolean))
      toast.success('Verkaufseinstellungen gespeichert')
    } catch { toast.error('Fehler beim Speichern') }
    finally { setSaving(false) }
  }

  if (loading) return <div className="flex justify-center py-8"><Loader2 size={24} className="animate-spin text-neutral-400" /></div>

  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-sm font-semibold text-gray-500 uppercase tracking-wide mb-4">Bankverbindung</h3>
        {contactHint && (
          <div className="mb-3 flex items-center gap-2 text-xs text-green-700 bg-green-50 border border-green-200 rounded-lg px-3 py-2">
            <CheckCircle2 size={13} /> {contactHint}
          </div>
        )}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          <div><label className="block text-xs font-medium text-neutral-600 mb-1">IBAN</label>
            <input value={bankIban} onChange={e => setBankIban(e.target.value)} placeholder="AT12 3456 7890 1234 5678" className="w-full border border-neutral-200 rounded-lg px-3 py-2 text-sm" /></div>
          <div><label className="block text-xs font-medium text-neutral-600 mb-1">BIC</label>
            <input value={bankBic} onChange={e => setBankBic(e.target.value)} placeholder="BKAUATWW" className="w-full border border-neutral-200 rounded-lg px-3 py-2 text-sm" /></div>
          <div><label className="block text-xs font-medium text-neutral-600 mb-1">Bankname</label>
            <input value={bankName} onChange={e => setBankName(e.target.value)} placeholder="Bank Austria" className="w-full border border-neutral-200 rounded-lg px-3 py-2 text-sm" /></div>
        </div>
      </div>
      <hr className="border-gray-100" />
      <div>
        <h3 className="text-sm font-semibold text-gray-500 uppercase tracking-wide mb-4">Standard-Einstellungen</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div><label className="block text-xs font-medium text-neutral-600 mb-1">Standard-MwSt.-Satz (%)</label>
            <select value={defaultTaxRate} onChange={e => setDefaultTaxRate(e.target.value)} className="w-full border border-neutral-200 rounded-lg px-3 py-2 text-sm">
              <option value={20}>20 %</option><option value={10}>10 %</option><option value={0}>0 %</option>
            </select></div>
          <div><label className="block text-xs font-medium text-neutral-600 mb-1">Standard-Zahlungsziel (Tage)</label>
            <input type="number" value={paymentDays} onChange={e => setPaymentDays(e.target.value)} className="w-full border border-neutral-200 rounded-lg px-3 py-2 text-sm" min={0} max={365} /></div>
          <div><label className="block text-xs font-medium text-neutral-600 mb-1">Angebot gültig (Tage)</label>
            <input type="number" value={offerValidDays} onChange={e => setOfferValidDays(e.target.value)} className="w-full border border-neutral-200 rounded-lg px-3 py-2 text-sm" min={0} max={365} />
            <p className="text-xs text-neutral-400 mt-1">0 = keine Vorbelegung</p></div>
        </div>
        <div className="mt-3"><label className="block text-xs font-medium text-neutral-600 mb-1">Kleinunternehmer-Hinweistext</label>
          <textarea value={kleinunternehmerText} onChange={e => setKleinunternehmerText(e.target.value)} rows={2} className="w-full border border-neutral-200 rounded-lg px-3 py-2 text-sm resize-none" /></div>

        {/* E-Rechnung. Vorgabe ist aus: Sie ändert das Dateiformat jedes
            versendeten Belegs und gehört bewusst eingeschaltet. */}
        <label className="mt-4 flex items-start gap-3 p-3 border border-neutral-200 rounded-lg cursor-pointer hover:bg-neutral-50">
          <input type="checkbox" checked={erechnungAktiv}
            onChange={e => setErechnungAktiv(e.target.checked)} className="mt-0.5 w-4 h-4 rounded" />
          <div>
            <p className="text-sm font-medium text-neutral-800">E-Rechnung einbetten (ZUGFeRD 2.5 / Factur-X)</p>
            <p className="text-xs text-neutral-500 mt-0.5 leading-relaxed">
              Versendete Rechnungen und Gutschriften bekommen die Rechnungsdaten als
              Datei ins PDF eingebettet. Für den Empfänger sieht der Beleg unverändert
              aus; wer die Daten verarbeiten kann, spart das Abtippen. Fehlt an einem
              Beleg eine Pflichtangabe, geht wie bisher ein gewöhnliches PDF hinaus —
              der Versand bleibt in jedem Fall möglich.
            </p>
          </div>
        </label>
      </div>
      <hr className="border-gray-100" />
      <div>
        <h3 className="text-sm font-semibold text-gray-500 uppercase tracking-wide mb-1">Automatische Archivierung</h3>
        <p className="text-xs text-neutral-500 mb-4">
          Bei den gewählten Ereignissen wird automatisch ein PDF des Belegs erzeugt und im Datacenter
          unter dem Kontakt in einem Unterordner je Belegart abgelegt (Dateiname mit Datum &amp; Uhrzeit).
        </p>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
          {[
            { key: 'email',      label: 'Bei E-Mail-Versand' },
            { key: 'gesendet',   label: 'Status „Gesendet“' },
            { key: 'angenommen', label: 'Status „Angenommen“' },
            { key: 'abgelehnt',  label: 'Status „Abgelehnt“' },
            { key: 'bezahlt',    label: 'Status „Bezahlt“' },
            { key: 'storniert',  label: 'Status „Storniert“' },
          ].map(t => (
            <label key={t.key} className="flex items-center gap-2 p-2.5 border border-neutral-200 rounded-lg cursor-pointer hover:bg-neutral-50 text-sm">
              <input type="checkbox" checked={archiveTriggers.includes(t.key)}
                onChange={() => setArchiveTriggers(a => a.includes(t.key) ? a.filter(x => x !== t.key) : [...a, t.key])}
                className="w-4 h-4 rounded" />
              <span className="text-neutral-700">{t.label}</span>
            </label>
          ))}
        </div>
      </div>
      <hr className="border-gray-100" />
      <div>
        <h3 className="text-sm font-semibold text-gray-500 uppercase tracking-wide mb-1">Steuersätze</h3>
        <p className="text-xs text-neutral-500 mb-4">
          Diese Sätze stehen im Belegformular zur Auswahl. Der USt-Code wandert in den
          Buchhaltungs-Export — welche Codes gelten, sagt dir deine Steuerberatung.
          Reverse Charge ist kein Satz und steht im Formular immer zur Verfügung.
        </p>
        <div className="space-y-2">
          <div className="hidden sm:grid grid-cols-12 gap-2 px-1 text-xs font-medium text-neutral-500">
            <span className="col-span-2">Satz %</span>
            <span className="col-span-3">Bezeichnung</span>
            <span className="col-span-2">USt-Code</span>
            <span className="col-span-1">UVA-KZ</span>
            <span className="col-span-2">Aktiv</span>
            <span className="col-span-2">Standard</span>
          </div>
          {taxRates.map((t, i) => (
            <div key={i} className="grid grid-cols-12 gap-2 items-center">
              <input type="number" step="0.1" value={t.satz}
                onChange={e => setTaxRates(l => l.map((x, j) => j === i ? { ...x, satz: Number(e.target.value) } : x))}
                className="col-span-2 border border-neutral-200 rounded-lg px-2 py-1.5 text-sm text-right" />
              <input value={t.bezeichnung || ''}
                onChange={e => setTaxRates(l => l.map((x, j) => j === i ? { ...x, bezeichnung: e.target.value } : x))}
                className="col-span-3 border border-neutral-200 rounded-lg px-2 py-1.5 text-sm" />
              <input value={t.ust_code || ''}
                onChange={e => setTaxRates(l => l.map((x, j) => j === i ? { ...x, ust_code: e.target.value } : x))}
                className="col-span-2 border border-neutral-200 rounded-lg px-2 py-1.5 text-sm font-mono" />
              {/* Kennzahl im Formular U30 — leer lassen, wenn unklar; die
                  Auswertung weist solche Zeilen als „nicht zugeordnet" aus. */}
              <input value={t.uva_kz || ''} placeholder="—" title="Kennzahl im UVA-Formular U30"
                onChange={e => setTaxRates(l => l.map((x, j) => j === i ? { ...x, uva_kz: e.target.value } : x))}
                className="col-span-1 border border-neutral-200 rounded-lg px-2 py-1.5 text-sm font-mono text-center" />
              <label className="col-span-2 flex items-center gap-1.5 text-xs text-neutral-600">
                <input type="checkbox" checked={!!t.aktiv} className="w-4 h-4 rounded"
                  onChange={e => setTaxRates(l => l.map((x, j) => j === i ? { ...x, aktiv: e.target.checked } : x))} />
                wählbar
              </label>
              <div className="col-span-2 flex items-center justify-between gap-1">
                <label className="flex items-center gap-1.5 text-xs text-neutral-600">
                  {/* Nur ein Standardsatz — er belegt neue Positionen vor. */}
                  <input type="radio" name="standardsatz" checked={!!t.standard} className="w-4 h-4"
                    onChange={() => setTaxRates(l => l.map((x, j) => ({ ...x, standard: j === i })))} />
                  Standard
                </label>
                <button aria-label="Satz entfernen" type="button" title="Satz entfernen"
                  onClick={() => setTaxRates(l => l.filter((_, j) => j !== i))}
                  className="p-1 text-neutral-400 hover:text-red-500"><Trash2 size={13} /></button>
              </div>
            </div>
          ))}
        </div>
        <button type="button"
          onClick={() => setTaxRates(l => [...l, { satz: 0, bezeichnung: '', ust_code: '', aktiv: true, standard: false }])}
          className="mt-3 flex items-center gap-1.5 text-sm text-primary-600 hover:underline">
          <Plus size={14} /> Steuersatz hinzufügen
        </button>
      </div>

      <hr className="border-gray-100" />
      <div>
        <h3 className="text-sm font-semibold text-gray-500 uppercase tracking-wide mb-1">Mahnstufen</h3>
        <p className="text-xs text-neutral-500 mb-4">
          Die Wartezeit zählt bei der ersten Stufe ab Fälligkeit, danach ab der vorigen
          Mahnung. Mahngebühr und Verzugszinsen sind Schadenersatz und nicht
          umsatzsteuerbar — sie stehen auf dem Mahnschreiben, laufen aber bewusst nicht
          in Umsatz, UVA oder Buchungsjournal.
        </p>
        <div className="space-y-2">
          <div className="hidden sm:grid grid-cols-12 gap-2 px-1 text-xs font-medium text-neutral-500">
            <span className="col-span-4">Bezeichnung</span>
            <span className="col-span-2">nach Tagen</span>
            <span className="col-span-2">Nachfrist</span>
            <span className="col-span-2">Gebühr €</span>
            <span className="col-span-2">Zinsen</span>
          </div>
          {dunningLevels.map((s, i) => (
            <div key={i} className="grid grid-cols-12 gap-2 items-center">
              <input value={s.label || ''}
                onChange={e => setDunningLevels(l => l.map((x, j) => j === i ? { ...x, label: e.target.value } : x))}
                className="col-span-4 border border-neutral-200 rounded-lg px-2 py-1.5 text-sm" />
              <input type="number" min="0" value={s.days_after ?? 0}
                onChange={e => setDunningLevels(l => l.map((x, j) => j === i ? { ...x, days_after: Number(e.target.value) } : x))}
                className="col-span-2 border border-neutral-200 rounded-lg px-2 py-1.5 text-sm text-right" />
              <input type="number" min="0" value={s.grace_days ?? 0}
                onChange={e => setDunningLevels(l => l.map((x, j) => j === i ? { ...x, grace_days: Number(e.target.value) } : x))}
                className="col-span-2 border border-neutral-200 rounded-lg px-2 py-1.5 text-sm text-right" />
              <input type="number" step="0.01" min="0" value={s.fee ?? 0}
                onChange={e => setDunningLevels(l => l.map((x, j) => j === i ? { ...x, fee: e.target.value } : x))}
                className="col-span-2 border border-neutral-200 rounded-lg px-2 py-1.5 text-sm text-right" />
              <div className="col-span-2 flex items-center justify-between gap-1">
                <label className="flex items-center gap-1.5 text-xs text-neutral-600">
                  <input type="checkbox" checked={!!s.interest} className="w-4 h-4 rounded"
                    onChange={e => setDunningLevels(l => l.map((x, j) => j === i ? { ...x, interest: e.target.checked } : x))} />
                  berechnen
                </label>
                <button aria-label="Stufe entfernen" type="button" title="Stufe entfernen"
                  onClick={() => setDunningLevels(l => l.filter((_, j) => j !== i)
                                                       .map((x, j) => ({ ...x, level: j + 1 })))}
                  className="p-1 text-neutral-400 hover:text-red-500"><Trash2 size={13} /></button>
              </div>
              <textarea value={s.text || ''} rows={2}
                placeholder="Text auf dem Mahnschreiben"
                onChange={e => setDunningLevels(l => l.map((x, j) => j === i ? { ...x, text: e.target.value } : x))}
                className="col-span-12 border border-neutral-200 rounded-lg px-2 py-1.5 text-sm resize-none mb-1" />
            </div>
          ))}
        </div>
        <button type="button"
          onClick={() => setDunningLevels(l => [...l, {
            level: l.length + 1, label: `${l.length}. Mahnung`, days_after: 14,
            grace_days: 7, fee: 0, interest: true, text: '',
          }])}
          className="mt-3 flex items-center gap-1.5 text-sm text-primary-600 hover:underline">
          <Plus size={14} /> Mahnstufe hinzufügen
        </button>

        <h4 className="text-xs font-semibold text-neutral-600 uppercase tracking-wide mt-6 mb-2">Verzugszinsen</h4>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
          <div>
            <label className="block text-xs font-medium text-neutral-600 mb-1">Basiszinssatz %</label>
            <input type="number" step="0.01" value={baseRate} placeholder="nicht gepflegt"
              onChange={e => setBaseRate(e.target.value)}
              className="w-full border border-neutral-200 rounded-lg px-2 py-1.5 text-sm text-right" />
          </div>
          <div>
            <label className="block text-xs font-medium text-neutral-600 mb-1">Aufschlag B2B %</label>
            <input type="number" step="0.1" value={surchargeB2b}
              onChange={e => setSurchargeB2b(e.target.value)}
              className="w-full border border-neutral-200 rounded-lg px-2 py-1.5 text-sm text-right" />
          </div>
          <div>
            <label className="block text-xs font-medium text-neutral-600 mb-1">Satz B2C %</label>
            <input type="number" step="0.1" value={rateB2c}
              onChange={e => setRateB2c(e.target.value)}
              className="w-full border border-neutral-200 rounded-lg px-2 py-1.5 text-sm text-right" />
          </div>
          <div>
            <label className="block text-xs font-medium text-neutral-600 mb-1">Welcher Satz gilt</label>
            <select value={interestMode} onChange={e => setInterestMode(e.target.value)}
              className="w-full border border-neutral-200 rounded-lg px-2 py-1.5 text-sm">
              <option value="auto">automatisch (UID = B2B)</option>
              <option value="b2b">immer B2B</option>
              <option value="b2c">immer B2C</option>
            </select>
          </div>
        </div>
        <p className="text-xs text-neutral-500 mt-2">
          In Österreich sind es bei Geschäften zwischen Unternehmen 9,2 Prozentpunkte
          über dem Basiszinssatz (§ 456 UGB), gegenüber Verbrauchern 4 % (§ 1000 ABGB).
          Der Basiszinssatz ändert sich halbjährlich — solange er hier leer ist, weist
          das Mahnschreiben bewusst keine Zinsen aus.
        </p>
      </div>

      <hr className="border-gray-100" />
      <div>
        <h3 className="text-sm font-semibold text-gray-500 uppercase tracking-wide mb-4">PDF-Vorlage</h3>
        <div className="grid grid-cols-2 md:grid-cols-5 gap-3 mb-5">
          {[1, 2, 3, 4, 5].map(n => (
            <div key={n} className={`flex flex-col rounded-xl border-2 transition-all overflow-hidden ${Number(defaultTemplate) === n ? 'border-primary-500' : 'border-neutral-200'}`}>
              <button onClick={() => setDefaultTemplate(n)} className={`flex flex-col items-center gap-2 p-3 w-full ${Number(defaultTemplate) === n ? 'bg-primary-50' : 'bg-surface hover:bg-neutral-50'}`}>
                <FileText size={24} className={Number(defaultTemplate) === n ? 'text-primary-600' : 'text-neutral-400'} />
                <span className={`text-xs font-semibold ${Number(defaultTemplate) === n ? 'text-primary-700' : 'text-neutral-700'}`}>{TEMPLATE_NAMES[n]}</span>
                <span className="text-xs text-neutral-400 text-center leading-tight">{TEMPLATE_DESCRIPTIONS[n]}</span>
                {Number(defaultTemplate) === n && <span className="text-xs bg-primary-600 text-white px-2 py-0.5 rounded-full">Standard</span>}
              </button>
              <button onClick={async () => {
                setPreviewTemplate(n); setPreviewHtml(''); setPreviewLoading(true)
                try {
                  const token = getAccessToken()
                  const res = await fetch(`/api/invoices/template-preview/${n}`, { headers: { Authorization: `Bearer ${token}` } })
                  setPreviewHtml(await res.text())
                } catch { setPreviewHtml('<p style="padding:2rem;color:red">Fehler</p>') }
                finally { setPreviewLoading(false) }
              }} className="w-full py-1.5 text-xs text-neutral-500 hover:text-primary-600 hover:bg-neutral-50 border-t border-neutral-100 flex items-center justify-center gap-1">
                <Eye size={12} /> Vorschau
              </button>
            </div>
          ))}
        </div>
        {previewTemplate && (
          <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50 p-4 sheet-safe">
            <div className="max-h-full overflow-y-auto bg-surface rounded-2xl shadow-2xl flex flex-col w-full max-w-4xl" style={{height: '90vh'}}>
              <div className="flex items-center justify-between px-5 py-3 border-b border-neutral-200">
                <span className="font-semibold text-neutral-800">Vorschau: {TEMPLATE_NAMES[previewTemplate]}</span>
                <div className="flex gap-2">
                  <button onClick={() => { setDefaultTemplate(previewTemplate); setPreviewTemplate(null) }} className="px-3 py-1.5 text-xs bg-primary-600 text-white rounded-lg hover:bg-primary-700">Als Standard verwenden</button>
                  <button onClick={() => setPreviewTemplate(null)} className="p-1.5 rounded-lg hover:bg-neutral-100 text-neutral-500"><XCircle size={18} /></button>
                </div>
              </div>
              <div className="flex-1 overflow-hidden rounded-b-2xl relative">
                {previewLoading && <div className="absolute inset-0 flex items-center justify-center bg-surface z-10"><Loader2 size={28} className="animate-spin text-neutral-400" /></div>}
                <iframe srcdoc={previewHtml} className="w-full h-full border-0" sandbox="allow-same-origin" />
              </div>
            </div>
          </div>
        )}
        <div className="border border-neutral-200 rounded-xl overflow-hidden">
          <button onClick={() => setShowCustomEditor(!showCustomEditor)} className="w-full flex items-center justify-between px-4 py-3 text-sm font-medium text-neutral-700 hover:bg-neutral-50">
            <span className="flex items-center gap-2"><FileText size={15} /> Eigene Vorlage (CSS-Editor)</span>
            {showCustomEditor ? <ChevronUp size={15} /> : <ChevronDown size={15} />}
          </button>
          {showCustomEditor && (
            <div className="border-t border-neutral-100 p-4">
              <p className="text-xs text-neutral-500 mb-2">Überschreibe das Standard-CSS. Selektoren: <code className="bg-neutral-100 px-1 rounded">.positions</code>, <code className="bg-neutral-100 px-1 rounded">h1</code>, <code className="bg-neutral-100 px-1 rounded">.bank-box</code> etc.</p>
              <textarea value={customCss} onChange={e => setCustomCss(e.target.value)} rows={10} placeholder="/* body { font-family: Georgia, serif; } */" className="w-full border border-neutral-200 rounded-lg px-3 py-2 text-xs font-mono resize-y" spellCheck={false} />
            </div>
          )}
        </div>
      </div>
      <div className="flex justify-end pt-2">
        <button onClick={handleSave} disabled={saving} className="flex items-center gap-2 px-4 py-2 bg-primary-600 text-white rounded-lg text-sm hover:bg-primary-700 disabled:opacity-60">
          {saving ? <Loader2 size={14} className="animate-spin" /> : <Save size={14} />} Speichern
        </button>
      </div>
    </div>
  )
}

// ── Belegnummern-Sektion ──────────────────────────────────────────────────────
const DOC_TYPE_META = {
  rechnung:     { label: 'Rechnung',     prefix: 'RE' },
  angebot:      { label: 'Angebot',      prefix: 'AN' },
  gutschrift:   { label: 'Gutschrift',   prefix: 'GS' },
  lieferschein: { label: 'Lieferschein', prefix: 'LS' },
}

function BelegnummernSection() {
  const [sequences, setSequences] = useState([])
  const [loading, setLoading] = useState(true)
  const [year, setYear] = useState(new Date().getFullYear())
  const [edits, setEdits] = useState({})
  const [saving, setSaving] = useState({})

  async function load() {
    setLoading(true)
    try {
      const res = await invoiceApi.getNumberSequences(year)
      setSequences(res.data)
      const e = {}
      res.data.forEach(s => { e[s.doc_type] = { format: s.format, last_sequence: String(s.last_sequence) } })
      setEdits(e)
    } catch { toast.error('Fehler beim Laden der Belegnummern') }
    finally { setLoading(false) }
  }

  useEffect(() => { load() }, [year]) // eslint-disable-line

  function preview(docType) {
    const e = edits[docType]; if (!e) return '—'
    try {
      const seq = parseInt(e.last_sequence || 0) + 1
      return e.format.replace('{year}', year).replace('{seq:03d}', String(seq).padStart(3,'0')).replace('{seq:04d}', String(seq).padStart(4,'0')).replace('{seq}', String(seq))
    } catch { return '—' }
  }

  async function handleSave(docType) {
    setSaving(s => ({...s, [docType]: true}))
    try {
      await invoiceApi.updateNumberSequence(docType, { year, format: edits[docType].format, last_sequence: parseInt(edits[docType].last_sequence) })
      toast.success(`${DOC_TYPE_META[docType]?.label} gespeichert`)
      load()
    } catch (err) { toast.error(err.response?.data?.detail || 'Fehler') }
    finally { setSaving(s => ({...s, [docType]: false})) }
  }

  if (loading) return <div className="flex justify-center py-4"><Loader2 size={20} className="animate-spin text-neutral-400" /></div>

  return (
    <div>
      <div className="flex items-center justify-between mb-4">
        <p className="text-xs text-neutral-500">
          Platzhalter: <code className="bg-neutral-100 px-1 rounded">{'{year}'}</code> = Jahr,{' '}
          <code className="bg-neutral-100 px-1 rounded">{'{seq:03d}'}</code> = 3-stellige Nummer
        </p>
        <div className="flex items-center gap-2">
          <label className="text-xs text-neutral-500">Jahr:</label>
          <select value={year} onChange={e => setYear(Number(e.target.value))} className="border border-neutral-200 rounded px-2 py-1 text-sm">
            {[0,1,2,3].map(i => { const y = new Date().getFullYear() - i + 1; return <option key={y} value={y}>{y}</option> })}
          </select>
        </div>
      </div>
      <div className="space-y-3">
        {sequences.map(seq => {
          const meta = DOC_TYPE_META[seq.doc_type] || {}
          const e = edits[seq.doc_type] || {}
          return (
            <div key={seq.doc_type} className="border border-neutral-200 rounded-xl p-4">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  <span className="text-xs font-mono font-bold bg-neutral-100 text-neutral-600 px-2 py-0.5 rounded">{meta.prefix}</span>
                  <span className="text-sm font-medium text-neutral-800">{meta.label}</span>
                </div>
                <span className="text-xs text-neutral-400">Nächste: <strong className="text-neutral-700 font-mono">{preview(seq.doc_type)}</strong></span>
              </div>
              <div className="grid grid-cols-12 gap-3 items-end">
                <div className="col-span-6">
                  <label className="block text-xs font-medium text-neutral-500 mb-1">Nummernformat</label>
                  <input value={e.format || ''} onChange={ev => setEdits(d => ({...d, [seq.doc_type]: {...d[seq.doc_type], format: ev.target.value}}))}
                    placeholder={`${meta.prefix}-{year}-{seq:03d}`} className="w-full border border-neutral-200 rounded-lg px-3 py-2 text-sm font-mono" />
                </div>
                <div className="col-span-3">
                  <label className="block text-xs font-medium text-neutral-500 mb-1">Letzter Zähler {year}</label>
                  <input type="number" min={0} value={e.last_sequence ?? seq.last_sequence}
                    onChange={ev => setEdits(d => ({...d, [seq.doc_type]: {...d[seq.doc_type], last_sequence: ev.target.value}}))}
                    className="w-full border border-neutral-200 rounded-lg px-3 py-2 text-sm text-right" />
                </div>
                <div className="col-span-3">
                  <button onClick={() => handleSave(seq.doc_type)} disabled={saving[seq.doc_type]}
                    className="w-full flex items-center justify-center gap-1.5 px-3 py-2 text-sm bg-primary-600 text-white rounded-lg hover:bg-primary-700 disabled:opacity-60">
                    {saving[seq.doc_type] ? <Loader2 size={14} className="animate-spin" /> : <Save size={14} />} Speichern
                  </button>
                </div>
              </div>
              {seq.last_sequence > 0 && <p className="text-xs text-neutral-400 mt-2">{seq.last_sequence} Belege in {year} · Nächste freie Nr.: {seq.next_sequence}</p>}
            </div>
          )
        })}
      </div>
    </div>
  )
}

// ── Tab: Kontenplan → umgezogen ──────────────────────────────────────────────
//
// Der Kontenplan lag hier als Reiter und war damit nur für Admins erreichbar.
// Er ist Arbeitsmittel der Buchhaltung, nicht Konfiguration der Anwendung, und
// steht jetzt unter Buchhaltung → Kontenplan (pages/KontenplanPage.jsx).
//
// Der Reiter bleibt vorerst als Wegweiser stehen: Wer ihn hier gewohnt ist,
// sucht sonst. Ändern darf die Konten weiterhin nur ein Admin — das prüft das
// Backend, nicht die Oberfläche.
function TabKontenplanHinweis() {
  const navigate = useNavigate()
  return (
    <div className="rounded-xl border border-neutral-200 bg-neutral-50 p-5">
      <h3 className="text-sm font-semibold text-neutral-700 mb-1">Der Kontenplan ist umgezogen</h3>
      <p className="text-sm text-neutral-600 mb-4">
        Du findest ihn jetzt im Bereich <strong>Buchhaltung</strong>. Dort steht er allen
        zur Verfügung, die mit den Zahlen arbeiten — geändert werden darf er weiterhin
        nur von einem Administrator.
      </p>
      <button onClick={() => navigate('/buchhaltung/konten')}
        className="inline-flex items-center gap-1.5 px-3 py-2 text-sm bg-primary-600 text-white rounded-lg hover:bg-primary-700">
        Zum Kontenplan
      </button>
    </div>
  )
}

// ── Tab: Allgemein + Design (horizontale Unter-Tabs) ─────────────────────────
function TabAllgemeinWrapper({ settings, onSaved }) {
  const [sub, setSub] = useState('firma')
  const subTabs = [
    { id: 'firma',  label: 'Firmendaten' },
    { id: 'design', label: 'Design'      },
  ]
  return (
    <div>
      <div className="flex flex-wrap gap-1 bg-neutral-100 p-1 rounded-lg mb-5 w-fit max-w-full">
        {subTabs.map(t => (
          <button key={t.id} onClick={() => setSub(t.id)}
            className={`px-4 py-1.5 text-sm rounded-md transition-all whitespace-nowrap ${sub === t.id ? 'bg-surface text-neutral-900 shadow-sm font-medium' : 'text-neutral-600 hover:text-neutral-800'}`}>
            {t.label}
          </button>
        ))}
      </div>
      {sub === 'firma'  && <TabAllgemein settings={settings} onSaved={onSaved} />}
      {sub === 'design' && <TabDesign    settings={settings} onSaved={onSaved} />}
    </div>
  )
}

// ── Tab: Parameter (horizontale Unter-Tabs) ───────────────────────────────────
function TabParameter() {
  const [sub, setSub] = useState('belege')
  const subTabs = [
    { id: 'belege',        label: 'Verkaufseinstellungen' },
    { id: 'nummern',       label: 'Belegnummern'       },
    { id: 'konten',        label: 'Kontenplan (EKR)'   },
    { id: 'emailvorlagen', label: 'E-Mail-Vorlagen'    },
  ]
  return (
    <div>
      <div className="flex flex-wrap gap-1 bg-neutral-100 p-1 rounded-lg mb-5 w-fit max-w-full">
        {subTabs.map(t => (
          <button key={t.id} onClick={() => setSub(t.id)}
            className={`px-4 py-1.5 text-sm rounded-md transition-all whitespace-nowrap ${sub === t.id ? 'bg-surface text-neutral-900 shadow-sm font-medium' : 'text-neutral-600 hover:text-neutral-800'}`}>
            {t.label}
          </button>
        ))}
      </div>
      {sub === 'belege'        && <TabRechnung embedded />}
      {sub === 'nummern'       && <BelegnummernSection />}
      {sub === 'konten'        && <TabKontenplanHinweis />}
      {sub === 'emailvorlagen' && <TabEmailVorlagen />}
    </div>
  )
}

// ── Tab: Lasttest ─────────────────────────────────────────────────────────────
// Nur die Anleitung, kein Startknopf — die Begründung steht in der Komponente.
// Die passende Variante (Server/lokal) wird aus `local_mode` vorausgewählt,
// bleibt aber umschaltbar: Man liest die Server-Anleitung oft am Notebook.
function TabLasttest() {
  const [istLokal, setIstLokal] = useState(null)

  useEffect(() => {
    systemApi.getVersion()
      .then(res => setIstLokal(res.data?.local_mode === true))
      .catch(() => setIstLokal(false))
  }, [])

  if (istLokal === null) {
    return (
      <div className="flex items-center justify-center py-10 text-gray-400">
        <Loader2 size={22} className="animate-spin" />
      </div>
    )
  }
  return <LasttestAnleitung istLokal={istLokal} />
}


// ── Tab: System + Backup (horizontale Unter-Tabs) ────────────────────────────
function TabSystemWrapper({ settings, onSaved }) {
  const [sub, setSub] = useState('system')
  const subTabs = [
    { id: 'system',   label: 'System' },
    // Stillgelegt am 29.08.2026: Der Reiter bleibt sichtbar, aber ausgegraut.
    // Verstecken wäre unehrlich — man soll sehen, dass es die Funktion gibt
    // und dass sie gerade überarbeitet wird, statt sich zu fragen, ob man sie
    // sich eingebildet hat.
    { id: 'lasttest', label: 'Lasttest', deaktiviert: true,
      hinweis: 'Wird überarbeitet — vorerst nicht verfügbar' },
    { id: 'backup',   label: 'Backup' },
    { id: 'email',    label: 'E-Mail' },
    { id: 'ki',       label: 'KI & Mail-Import' },
    { id: 'speicher', label: 'Speicher' },
  ]
  return (
    <div>
      <div className="flex flex-wrap gap-1 bg-neutral-100 p-1 rounded-lg mb-5 w-fit max-w-full">
        {subTabs.map(t => (
          <button key={t.id}
            onClick={() => !t.deaktiviert && setSub(t.id)}
            disabled={t.deaktiviert}
            title={t.hinweis || undefined}
            className={`px-4 py-1.5 text-sm rounded-md transition-all whitespace-nowrap ${
              t.deaktiviert
                ? 'text-neutral-400 cursor-not-allowed'
                : sub === t.id
                  ? 'bg-surface text-neutral-900 shadow-sm font-medium'
                  : 'text-neutral-600 hover:text-neutral-800'}`}>
            {t.label}
          </button>
        ))}
      </div>
      {sub === 'system'   && <TabSystem />}
      {/* 'lasttest' ist stillgelegt und über den Reiter nicht erreichbar.
          Die Zeile bleibt stehen, damit beim Wiederfreischalten nur das
          `deaktiviert` oben entfernt werden muss. */}
      {sub === 'lasttest' && <TabLasttest />}
      {sub === 'backup'   && <TabBackup   settings={settings} onSaved={onSaved} />}
      {sub === 'email'    && <TabEmail    settings={settings} onSaved={onSaved} />}
      {sub === 'ki' && (
        <div className="space-y-8">
          <KiEinstellungen />
          <div className="border-t border-neutral-100 pt-6">
            <MailKonten global />
          </div>
        </div>
      )}
      {sub === 'speicher' && <TabSpeicher settings={settings} onSaved={onSaved} />}
    </div>
  )
}

// ── Speicher-Konsolidierung (alle Dateien zum aktiven Provider umziehen) ──────
const PROVIDER_LABELS = { minio: 'MinIO', nextcloud: 'Nextcloud', seadrive: 'SeaDrive', onedrive: 'OneDrive' }
const provLabel = (id) => PROVIDER_LABELS[id] || id

function StorageMigrationPanel() {
  const [status,       setStatus]       = useState(null)
  const [loading,      setLoading]      = useState(true)
  const [migrating,    setMigrating]    = useState(false)
  const [deleteSource, setDeleteSource] = useState(false)
  const [result,       setResult]       = useState(null)
  // Re-Path (Ordnerstruktur auf Kundennamen)
  const [repathStatus, setRepathStatus] = useState(null)
  const [repathing,    setRepathing]    = useState(false)
  const [repathResult, setRepathResult] = useState(null)

  const refresh = async () => {
    setLoading(true)
    try {
      const [mig, rep] = await Promise.all([
        settingsApi.storageMigrationStatus(),
        settingsApi.storageRepathStatus(),
      ])
      setStatus(mig.data)
      setRepathStatus(rep.data)
    } catch { /* still. Anzeige bleibt leer */ }
    finally { setLoading(false) }
  }
  useEffect(() => { refresh() }, [])

  const handleRepath = async () => {
    if (!window.confirm('Bestehende Dateien im Speicher in Ordner mit Kundennamen verschieben? '
      + 'Die Dateien werden im jeweiligen Speicher umbenannt/verschoben.')) return
    setRepathing(true)
    setRepathResult(null)
    try {
      const res = await settingsApi.storageRepath()
      setRepathResult(res.data)
      if (res.data.failed === 0) toast.success(`${res.data.moved} Datei(en) umgezogen`)
      else toast.error(`${res.data.moved} umgezogen, ${res.data.failed} fehlgeschlagen`)
      refresh()
    } catch (e) {
      toast.error('Umstellung fehlgeschlagen: ' + (e?.response?.data?.detail || e.message))
    } finally { setRepathing(false) }
  }

  const handleMigrate = async () => {
    if (!window.confirm(
      `Alle Dateien, die nicht bei „${provLabel(status?.active)}" liegen, dorthin kopieren`
      + (deleteSource ? ' und die Quelldateien anschließend löschen' : '') + '?')) return
    setMigrating(true)
    setResult(null)
    try {
      const res = await settingsApi.storageMigrate(deleteSource)
      setResult(res.data)
      if (res.data.failed === 0) toast.success(`${res.data.migrated} Datei(en) migriert`)
      else toast.error(`${res.data.migrated} migriert, ${res.data.failed} fehlgeschlagen`)
      refresh()
    } catch (e) {
      toast.error('Migration fehlgeschlagen: ' + (e?.response?.data?.detail || e.message))
    } finally { setMigrating(false) }
  }

  if (loading) return null
  if (!status) return null

  const pending = status.pending || 0
  const dist = Object.entries(status.counts || {})

  return (
    <div className="mt-8 pt-6 border-t border-neutral-200 space-y-3">
      <div>
        <h3 className="text-sm font-semibold text-neutral-800">Dateien konsolidieren</h3>
        <p className="text-xs text-neutral-500 mt-0.5">
          Verschiebt alle vorhandenen Dateien zum aktuell aktiven Speicher
          („{provLabel(status.active)}"). Nützlich nach einem Provider-Wechsel.
        </p>
      </div>

      {dist.length > 0 && (
        <div className="flex flex-wrap gap-2 text-xs">
          {dist.map(([prov, n]) => (
            <span key={prov} className={`px-2 py-1 rounded-lg border ${prov === status.active
              ? 'bg-green-50 border-green-200 text-green-700' : 'bg-neutral-50 border-neutral-200 text-neutral-600'}`}>
              {provLabel(prov)}: {n}
            </span>
          ))}
        </div>
      )}

      {pending === 0 ? (
        <p className="text-xs text-green-600 flex items-center gap-1.5">
          <CheckCircle size={14} /> Alle {status.total} Dateien liegen bereits bei „{provLabel(status.active)}".
        </p>
      ) : (
        <>
          <label className="flex items-center gap-2 text-xs text-neutral-600 cursor-pointer">
            <input type="checkbox" checked={deleteSource} onChange={e => setDeleteSource(e.target.checked)} />
            Quelldateien nach erfolgreichem Kopieren löschen
          </label>
          <button onClick={handleMigrate} disabled={migrating}
            className="flex items-center gap-2 px-4 py-2 rounded-lg bg-neutral-800 hover:bg-neutral-900 text-white text-sm font-medium disabled:opacity-50">
            {migrating ? <><Loader2 size={14} className="animate-spin" /> Migriere…</>
                       : <><RefreshCw size={14} /> {pending} Datei(en) zu „{provLabel(status.active)}" migrieren</>}
          </button>
          <p className="text-xs text-neutral-400">
            Kann je nach Dateimenge dauern. Bricht nicht ab, wenn einzelne Dateien fehlschlagen.
          </p>
        </>
      )}

      {result && (
        <div className={`text-xs p-3 rounded-lg border ${result.failed === 0
          ? 'bg-green-50 border-green-200 text-green-800' : 'bg-amber-50 border-amber-200 text-amber-800'}`}>
          <div>{result.migrated} migriert · {result.skipped} bereits am Ziel · {result.failed} fehlgeschlagen</div>
          {result.errors?.length > 0 && (
            <ul className="mt-1 list-disc list-inside space-y-0.5">
              {result.errors.map((er, i) => <li key={i} className="break-all">{er}</li>)}
            </ul>
          )}
        </div>
      )}

      {/* Ordnerstruktur auf Kundennamen umstellen */}
      <div className="pt-4 mt-2 border-t border-neutral-100 space-y-2">
        <div>
          <h4 className="text-sm font-semibold text-neutral-800">Ordner auf Kundennamen umstellen</h4>
          <p className="text-xs text-neutral-500 mt-0.5">
            Verschiebt bestehende Dateien im Speicher aus den ID-Ordnern in Ordner mit dem
            Kundennamen (z.B. <code>kontakte/WWInterface GmbH/…</code>) — passend zur Datacenter-Anzeige.
          </p>
        </div>
        {repathStatus && (repathStatus.pending === 0 ? (
          <p className="text-xs text-green-600 flex items-center gap-1.5">
            <CheckCircle size={14} /> Alle Dateien liegen bereits in Namensordnern.
          </p>
        ) : (
          <>
            <button onClick={handleRepath} disabled={repathing}
              className="flex items-center gap-2 px-4 py-2 rounded-lg bg-neutral-800 hover:bg-neutral-900 text-white text-sm font-medium disabled:opacity-50">
              {repathing ? <><Loader2 size={14} className="animate-spin" /> Stelle um…</>
                         : <><RefreshCw size={14} /> {repathStatus.pending} Datei(en) auf Kundennamen umstellen</>}
            </button>
            <p className="text-xs text-neutral-400">Verschiebt die Dateien im Speicher und löscht die alten ID-Ordner-Dateien.</p>
          </>
        ))}
        {repathResult && (
          <div className={`text-xs p-3 rounded-lg border ${repathResult.failed === 0
            ? 'bg-green-50 border-green-200 text-green-800' : 'bg-amber-50 border-amber-200 text-amber-800'}`}>
            <div>{repathResult.moved} umgezogen · {repathResult.skipped} bereits ok · {repathResult.failed} fehlgeschlagen</div>
            {repathResult.errors?.length > 0 && (
              <ul className="mt-1 list-disc list-inside space-y-0.5">
                {repathResult.errors.map((er, i) => <li key={i} className="break-all">{er}</li>)}
              </ul>
            )}
          </div>
        )}
      </div>
    </div>
  )
}

// ── Tab: Speicher ────────────────────────────────────────────────────────────
const STORAGE_PROVIDERS = [
  { id: 'minio',     label: 'MinIO',     icon: '🗄️', hint: 'Lokaler MinIO-Objektspeicher (Standard)' },
  { id: 'nextcloud', label: 'Nextcloud', icon: '☁️', hint: 'WebDAV-URL: https://cloud.example.com/remote.php/dav/files/BENUTZERNAME' },
  { id: 'seadrive',  label: 'SeaDrive',  icon: '🌊', hint: 'WebDAV-URL: https://seadrive.example.com/seafdav' },
  { id: 'onedrive',  label: 'OneDrive',  icon: '📁', hint: 'Microsoft OneDrive oder SharePoint via Graph API (App-Berechtigung Files.ReadWrite.All erforderlich)' },
]

function TabSpeicher({ settings, onSaved }) {
  const rawBackend = settings.storage_backend || 'minio'
  const initProvider = ['minio','nextcloud','seadrive','onedrive'].includes(rawBackend) ? rawBackend : 'minio'

  const [provider,         setProvider]         = useState(initProvider)
  // WebDAV
  const [url,              setUrl]              = useState(settings.webdav_url         || '')
  const [user,             setUser]             = useState(settings.webdav_user        || '')
  const [password,         setPassword]         = useState('')
  const [rootFolder,       setRootFolder]       = useState(settings.webdav_root_folder || 'DeineZeit')
  // OneDrive
  const [odUseGraph,       setOdUseGraph]       = useState(settings.onedrive_use_graph_creds === 'true')
  const [odTenantId,       setOdTenantId]       = useState(settings.onedrive_tenant_id  || '')
  const [odClientId,       setOdClientId]       = useState(settings.onedrive_client_id  || '')
  const [odClientSecret,   setOdClientSecret]   = useState('')
  const [odDriveType,      setOdDriveType]      = useState(settings.onedrive_drive_type || 'personal')
  const [odSiteId,         setOdSiteId]         = useState(settings.onedrive_site_id    || '')
  const [odUser,           setOdUser]           = useState(settings.onedrive_user       || '')
  const [odRootFolder,     setOdRootFolder]     = useState(settings.onedrive_root_folder|| 'DeineZeit')

  const [saving,      setSaving]      = useState(false)
  const [testing,     setTesting]     = useState(false)
  const [testResult,  setTestResult]  = useState(null)

  const isWebDav   = ['nextcloud','seadrive'].includes(provider)
  const isOneDrive = provider === 'onedrive'
  const providerHint = STORAGE_PROVIDERS.find(p => p.id === provider)?.hint || ''

  const handleTest = async () => {
    setTesting(true)
    setTestResult(null)
    try {
      const payload = { storage_backend: isOneDrive ? 'onedrive' : isWebDav ? 'webdav' : 'minio' }
      if (isWebDav) {
        Object.assign(payload, { webdav_url: url, webdav_user: user, webdav_password: password, webdav_root_folder: rootFolder })
      }
      if (isOneDrive) {
        Object.assign(payload, {
          onedrive_use_graph_creds: odUseGraph ? 'true' : 'false',
          onedrive_tenant_id:       odTenantId,
          onedrive_client_id:       odClientId,
          onedrive_client_secret:   odClientSecret,
          onedrive_drive_type:      odDriveType,
          onedrive_site_id:         odSiteId,
          onedrive_user:            odUser,
          onedrive_root_folder:     odRootFolder,
        })
      }
      const res = await settingsApi.testStorage(payload)
      setTestResult(res.data)
    } catch (e) {
      setTestResult({ ok: false, message: e?.response?.data?.detail || e.message })
    } finally {
      setTesting(false)
    }
  }

  const handleSave = async () => {
    setSaving(true)
    try {
      const payload = { storage_backend: provider }
      if (isWebDav) {
        payload.webdav_url         = url
        payload.webdav_user        = user
        payload.webdav_root_folder = rootFolder
        if (password) payload.webdav_password = password
      }
      if (isOneDrive) {
        payload.onedrive_use_graph_creds = odUseGraph ? 'true' : 'false'
        payload.onedrive_drive_type      = odDriveType
        payload.onedrive_site_id         = odSiteId
        payload.onedrive_user            = odUser
        payload.onedrive_root_folder     = odRootFolder
        if (!odUseGraph) {
          payload.onedrive_tenant_id  = odTenantId
          payload.onedrive_client_id  = odClientId
          if (odClientSecret) payload.onedrive_client_secret = odClientSecret
        }
      }
      await settingsApi.update(payload)
      await settingsApi.applyStorage()
      toast.success('Speicher-Einstellungen gespeichert')
      onSaved && onSaved()
    } catch (e) {
      toast.error('Fehler beim Speichern: ' + (e?.response?.data?.detail || e.message))
    } finally {
      setSaving(false)
    }
  }

  return (
    <div className="space-y-6 max-w-xl">
      <div>
        <label className="block text-sm font-medium text-neutral-700 mb-2">Storage-Provider</label>
        <div className="flex gap-2 flex-wrap">
          {STORAGE_PROVIDERS.map(p => (
            <button key={p.id} onClick={() => { setProvider(p.id); setTestResult(null) }}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg border text-sm transition-all
                ${provider === p.id
                  ? 'bg-orange-50 border-orange-400 text-orange-700 font-medium'
                  : 'bg-surface border-neutral-200 text-neutral-600 hover:border-neutral-300'}`}>
              <span>{p.icon}</span>{p.label}
            </button>
          ))}
        </div>
        {providerHint && <p className="mt-2 text-xs text-neutral-500">{providerHint}</p>}
      </div>

      {isWebDav && (
        <div className="space-y-4 p-4 bg-neutral-50 rounded-xl border border-neutral-200">
          <div>
            <label className="block text-xs font-medium text-neutral-500 mb-1">WebDAV-URL</label>
            <input type="text" value={url} onChange={e => setUrl(e.target.value)}
              placeholder={provider === 'nextcloud'
                ? 'https://cloud.example.com/remote.php/dav/files/BENUTZERNAME'
                : 'https://seadrive.example.com/seafdav'}
              className="w-full border border-neutral-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-orange-300" />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-neutral-500 mb-1">Benutzername</label>
              <input type="text" value={user} onChange={e => setUser(e.target.value)}
                className="w-full border border-neutral-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-orange-300" />
            </div>
            <div>
              <label className="block text-xs font-medium text-neutral-500 mb-1">Passwort / App-Passwort</label>
              <input type="password" value={password} onChange={e => setPassword(e.target.value)}
                placeholder={settings.webdav_password ? '••••••••' : ''}
                className="w-full border border-neutral-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-orange-300" />
            </div>
          </div>
          <div>
            <label className="block text-xs font-medium text-neutral-500 mb-1">Root-Ordner in der Cloud</label>
            <input type="text" value={rootFolder} onChange={e => setRootFolder(e.target.value)}
              placeholder="DeineZeit"
              className="w-full border border-neutral-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-orange-300" />
            <p className="mt-1 text-xs text-neutral-400">Übergeordneter Ordner, unter dem alle Datacenter-Dateien abgelegt werden.</p>
          </div>
        </div>
      )}

      {isOneDrive && (
        <div className="space-y-4 p-4 bg-neutral-50 rounded-xl border border-neutral-200">
          {/* Graph-Credentials Toggle */}
          <label className="flex items-center gap-3 cursor-pointer">
            <div onClick={() => setOdUseGraph(!odUseGraph)}
              className={`w-10 h-6 rounded-full transition-colors flex items-center px-0.5
                ${odUseGraph ? 'bg-orange-500' : 'bg-neutral-300'}`}>
              <div className={`w-5 h-5 bg-surface rounded-full shadow transition-transform
                ${odUseGraph ? 'translate-x-4' : 'translate-x-0'}`} />
            </div>
            <span className="text-sm text-neutral-700">Graph-Einstellungen aus E-Mail wiederverwenden</span>
          </label>
          {!odUseGraph && (
            <div className="space-y-3">
              <div>
                <label className="block text-xs font-medium text-neutral-500 mb-1">Tenant-ID</label>
                <input type="text" value={odTenantId} onChange={e => setOdTenantId(e.target.value)}
                  placeholder="xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx"
                  className="w-full border border-neutral-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-orange-300" />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-neutral-500 mb-1">Client-ID</label>
                  <input type="text" value={odClientId} onChange={e => setOdClientId(e.target.value)}
                    className="w-full border border-neutral-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-orange-300" />
                </div>
                <div>
                  <label className="block text-xs font-medium text-neutral-500 mb-1">Client-Secret</label>
                  <input type="password" value={odClientSecret} onChange={e => setOdClientSecret(e.target.value)}
                    placeholder={settings.onedrive_client_secret ? '••••••••' : ''}
                    className="w-full border border-neutral-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-orange-300" />
                </div>
              </div>
            </div>
          )}
          {/* Drive-Typ */}
          <div>
            <label className="block text-xs font-medium text-neutral-500 mb-2">Laufwerk</label>
            <div className="flex gap-2">
              {[{id:'personal',label:'Persönliches OneDrive'},{id:'sharepoint',label:'SharePoint'}].map(dt => (
                <button key={dt.id} onClick={() => setOdDriveType(dt.id)}
                  className={`px-3 py-1.5 rounded-lg border text-sm transition-all
                    ${odDriveType === dt.id
                      ? 'bg-orange-50 border-orange-400 text-orange-700 font-medium'
                      : 'bg-surface border-neutral-200 text-neutral-600 hover:border-neutral-300'}`}>
                  {dt.label}
                </button>
              ))}
            </div>
          </div>
          {odDriveType === 'personal' && (
            <div>
              <label className="block text-xs font-medium text-neutral-500 mb-1">OneDrive-Benutzer (E-Mail / UPN)</label>
              <input type="text" value={odUser} onChange={e => setOdUser(e.target.value)}
                placeholder="benutzer@firma.at"
                className="w-full border border-neutral-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-orange-300" />
              <p className="mt-1 text-xs text-neutral-400">Pflicht bei persönlichem OneDrive: App-only greift über <code>/users/&#123;E-Mail&#125;/drive</code> zu (nicht <code>/me</code>). Der Benutzer braucht eine OneDrive-for-Business-Lizenz.</p>
            </div>
          )}
          {odDriveType === 'sharepoint' && (
            <div>
              <label className="block text-xs font-medium text-neutral-500 mb-1">SharePoint Site-ID</label>
              <input type="text" value={odSiteId} onChange={e => setOdSiteId(e.target.value)}
                placeholder="wwinterfacegmbh.sharepoint.com,abc123,def456"
                className="w-full border border-neutral-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-orange-300" />
              <p className="mt-1 text-xs text-neutral-400">Format: hostname,siteId,webId — oder hostname:/sites/Name. Reiner Hostname = Root-Site.</p>
            </div>
          )}
          <div>
            <label className="block text-xs font-medium text-neutral-500 mb-1">Root-Ordner in OneDrive</label>
            <input type="text" value={odRootFolder} onChange={e => setOdRootFolder(e.target.value)}
              placeholder="DeineZeit"
              className="w-full border border-neutral-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-orange-300" />
          </div>
        </div>
      )}

            {testResult && (
        <div className={`flex items-start gap-2 p-3 rounded-lg text-sm border
          ${testResult.ok ? 'bg-green-50 border-green-200 text-green-800' : 'bg-red-50 border-red-200 text-red-800'}`}>
          {testResult.ok
            ? <CheckCircle2 size={16} className="mt-0.5 shrink-0 text-green-600" />
            : <XCircle     size={16} className="mt-0.5 shrink-0 text-red-600" />}
          <span>{testResult.message}</span>
        </div>
      )}

      <div className="flex items-center gap-3">
        {(isWebDav || isOneDrive) && (
          <button onClick={handleTest}
            disabled={testing || (isWebDav && (!url || !user)) || (isOneDrive && !odUseGraph && (!odTenantId || !odClientId))}
            className="flex items-center gap-2 px-4 py-2 rounded-lg border border-neutral-200 text-sm text-neutral-700 hover:bg-neutral-50 disabled:opacity-50">
            {testing ? <Loader2 size={14} className="animate-spin" /> : <Cloud size={14} />}
            Verbindung testen
          </button>
        )}
        <button onClick={handleSave} disabled={saving}
          className="flex items-center gap-2 px-4 py-2 rounded-lg bg-orange-500 hover:bg-orange-600 text-white text-sm font-medium disabled:opacity-50">
          {saving ? <Loader2 size={14} className="animate-spin" /> : <Save size={14} />}
          Speichern
        </button>
      </div>

      <StorageMigrationPanel />
    </div>
  )
}

// ── Tab: E-Mail-Vorlagen ──────────────────────────────────────────────────────
const DOC_TYPES_VORLAGEN = [
  { key: 'rechnung',             label: 'Rechnung'            },
  { key: 'angebot',              label: 'Angebot'             },
  { key: 'auftragsbestaetigung', label: 'Auftragsbestätigung' },
  { key: 'gutschrift',           label: 'Gutschrift'          },
  { key: 'lieferschein',         label: 'Lieferschein'        },
]

const PLACEHOLDERS = [
  { key: '{nummer}',   label: 'Belegnummer'   },
  { key: '{kontakt}',  label: 'Kontakt'       },
  { key: '{firma}',    label: 'Firma'         },
  { key: '{betrag}',   label: 'Betrag'        },
  { key: '{datum}',    label: 'Datum'         },
  { key: '{faellig}',  label: 'Fällig am'     },
  { key: '{belegart}', label: 'Belegart'      },
]

function TabEmailVorlagen() {
  const [activeType, setActiveType] = useState('rechnung')
  const [subject, setSubject] = useState('')
  const [bodyHtml, setBodyHtml] = useState('')
  const [saving, setSaving] = useState(false)
  const [loading, setLoading] = useState(false)
  const subjectRef = React.useRef(null)

  useEffect(() => {
    setLoading(true)
    invoiceApi.getEmailTemplate(activeType)
      .then(r => { setSubject(r.data.subject || ''); setBodyHtml(r.data.body_html || '') })
      .catch(() => {})
      .finally(() => setLoading(false))
  }, [activeType])

  function insertPlaceholder(ph) {
    // Insert into focused element (subject or body)
    const el = subjectRef.current
    if (document.activeElement === el) {
      const start = el.selectionStart
      const end   = el.selectionEnd
      const next  = subject.slice(0, start) + ph + subject.slice(end)
      setSubject(next)
      setTimeout(() => { el.setSelectionRange(start + ph.length, start + ph.length); el.focus() }, 0)
    } else {
      // Insert into TipTap editor (append at cursor)
      setBodyHtml(prev => prev + ph)
    }
  }

  async function handleSave() {
    setSaving(true)
    try {
      await invoiceApi.updateEmailTemplate(activeType, { subject, body_html: bodyHtml })
      toast.success('Vorlage gespeichert')
    } catch { toast.error('Fehler beim Speichern') }
    finally { setSaving(false) }
  }

  return (
    <div>
      {/* Belegart-Tabs */}
      <div className="flex gap-1 bg-neutral-100 p-1 rounded-lg mb-5 flex-wrap w-fit">
        {DOC_TYPES_VORLAGEN.map(t => (
          <button key={t.key} onClick={() => setActiveType(t.key)}
            className={`px-3 py-1.5 text-sm rounded-md transition-all ${activeType === t.key ? 'bg-surface text-neutral-900 shadow-sm font-medium' : 'text-neutral-600 hover:text-neutral-800'}`}>
            {t.label}
          </button>
        ))}
      </div>

      {loading ? (
        <div className="flex items-center justify-center h-32"><Loader2 size={20} className="animate-spin text-neutral-400" /></div>
      ) : (
        <div className="space-y-4">
          {/* Platzhalter */}
          <div>
            <p className="text-xs text-neutral-500 mb-1.5">Platzhalter einfügen — klicke einen an und er wird an der Cursorposition eingefügt:</p>
            <div className="flex flex-wrap gap-1.5">
              {PLACEHOLDERS.map(p => (
                <button key={p.key} type="button" onClick={() => insertPlaceholder(p.key)}
                  className="text-xs px-2 py-1 bg-blue-50 text-blue-700 border border-blue-200 rounded-md hover:bg-blue-100 font-mono">
                  {p.key}
                  <span className="font-sans text-blue-500 ml-1">({p.label})</span>
                </button>
              ))}
            </div>
          </div>

          {/* Betreff */}
          <div>
            <label className="block text-sm font-medium text-neutral-700 mb-1">Betreff</label>
            <input
              ref={subjectRef}
              value={subject}
              onChange={e => setSubject(e.target.value)}
              className="w-full border border-neutral-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary-300"
              placeholder="z.B. Rechnung {nummer} von {firma}"
            />
          </div>

          {/* Body */}
          <div>
            <label className="block text-sm font-medium text-neutral-700 mb-1">E-Mail-Text</label>
            <RichTextEditor value={bodyHtml} onChange={setBodyHtml} minHeight="220px" />
          </div>

          <div className="flex justify-end">
            <button onClick={handleSave} disabled={saving}
              className="flex items-center gap-2 px-4 py-2 text-sm bg-primary-600 text-white rounded-lg hover:bg-primary-700 disabled:opacity-60">
              {saving ? <Loader2 size={14} className="animate-spin" /> : <Save size={14} />}
              {saving ? 'Speichert…' : 'Vorlage speichern'}
            </button>
          </div>
        </div>
      )}
    </div>
  )
}

// ── Hauptseite ────────────────────────────────────────────────────────────────
export default function SettingsPage() {
  const [activeTab, setActiveTab] = useState('allgemein')
  const [reloading, setReloading] = useState(false)
  const { settings, loading, loadSettings } = useSettings()

  // Beim Öffnen einmal frisch laden: Der Server gibt die vollständige
  // Konfiguration nur an einen angemeldeten Administrator heraus. Der erste
  // Ladevorgang beim App-Start lief noch ohne Anmeldung und hat deshalb nur
  // die Darstellungsfelder (Firmenname, Farben, Logo) geliefert.
  useEffect(() => { loadSettings() }, [])

  const handleReload = async () => {
    setReloading(true)
    await loadSettings()
    setReloading(false)
    toast.success('Einstellungen neu geladen')
  }

  const tabs = [
    { id: 'allgemein',   label: 'Allgemein',   icon: Building2   },
    { id: 'parameter',   label: 'Parameter',   icon: BookOpen    },
    { id: 'benutzer',    label: 'Benutzer',    icon: Users       },
    { id: 'datenschutz', label: 'Datenschutz', icon: ShieldCheck },
    { id: 'system',      label: 'System',      icon: Cpu         },
  ]

  if (loading) return (
    <div className="flex items-center justify-center h-64">
      <Loader2 size={28} className="animate-spin text-primary-400" />
    </div>
  )

  return (
    <div className="max-w-3xl mx-auto">
      <div className="flex items-center gap-3 mb-8">
        <div className="p-2 bg-primary-50 rounded-xl"><Settings2 size={22} className="text-primary-600" /></div>
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Einstellungen</h1>
          <p className="text-sm text-gray-400 mt-0.5">Programm konfigurieren</p>
        </div>
        <button aria-label="Neu laden" onClick={handleReload} disabled={reloading} className="ml-auto p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-xl transition" title="Neu laden">
          <RefreshCw size={16} className={reloading ? 'animate-spin' : ''} />
        </button>
      </div>
      <div className="flex gap-2 mb-6 flex-wrap">
        {tabs.map(t => <Tab key={t.id} {...t} active={activeTab === t.id} onClick={setActiveTab} />)}
      </div>
      <div className="card p-6">
        {activeTab === 'allgemein'  && <TabAllgemeinWrapper settings={settings} onSaved={loadSettings} />}
        {activeTab === 'parameter'  && <TabParameter />}
        {activeTab === 'benutzer'   && <UserManagementPage />}
        {activeTab === 'datenschutz' && <DatenschutzEinstellungen settings={settings} onSaved={loadSettings} />}
        {activeTab === 'system'     && <TabSystemWrapper settings={settings} onSaved={loadSettings} />}
      </div>
    </div>
  )
}
