import { useState, useEffect, useCallback, useRef, useLayoutEffect } from 'react'
import PageHeader from '../components/PageHeader'
import { Receipt } from 'lucide-react'
import Fab from '../components/Fab'
import { createPortal } from 'react-dom'
import { useNavigate } from 'react-router'
import { invoiceApi, datacenterApi, masterdataApi } from '../services/api'
import RichTextEditor from '../components/RichTextEditor'
import toast from 'react-hot-toast'
import { useAuth } from '../contexts/AuthContext'
import {
  Plus, Search, FileText, RefreshCw, Download,
  CheckCircle2, Clock, XCircle, Send, Eye,
  MoreHorizontal, RotateCcw, Mail, MailCheck, MailX,
  Paperclip, X as XIcon, HardDrive, Upload, Copy, Repeat, Trash2, Wallet,
  Layers, FileCheck
} from 'lucide-react'

function fmtDate(d) {
  if (!d) return '—'
  return new Date(d).toLocaleDateString('de-AT', { day: '2-digit', month: '2-digit', year: 'numeric' })
}
// Entwürfe tragen noch keine Belegnummer — sie fällt erst beim Finalisieren.
function belegNr(inv) {
  return inv?.number || 'Entwurf'
}
function fmtEuro(n) {
  if (n === null || n === undefined) return '—'
  return Number(n).toLocaleString('de-AT', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + ' €'
}

// Abrechnungsstufe. Technisch bleibt es eine Rechnung — sichtbar muss aber
// sein, welche: Der Unterschied zwischen Anzahlung und Schlussrechnung ist
// für den Kunden wie für die Prüfung wesentlich.
const STUFEN_LABEL = {
  anzahlung: 'Anzahlung',
  teil:      'Teilrechnung',
  schluss:   'Schlussrechnung',
}
const STUFEN_FARBE = {
  anzahlung: 'bg-sky-100 text-sky-700',
  teil:      'bg-indigo-100 text-indigo-700',
  schluss:   'bg-emerald-100 text-emerald-700',
}

const RECURRING_TAB = '__recurring__'

const DOC_TYPES = [
  { key: '',                     label: 'Alle' },
  { key: 'rechnung',             label: 'Rechnungen' },
  { key: 'angebot',              label: 'Angebote' },
  { key: 'auftragsbestaetigung', label: 'Auftragsbestätigungen' },
  { key: 'gutschrift',           label: 'Gutschriften' },
  { key: 'lieferschein',         label: 'Lieferscheine' },
  { key: RECURRING_TAB,          label: 'Wiederkehrend' },
]

const STATUS_BADGE = {
  entwurf:      { label: 'Entwurf',    cls: 'bg-neutral-100 text-neutral-600' },
  gesendet:     { label: 'Gesendet',   cls: 'bg-blue-100 text-blue-700' },
  offen:        { label: 'Offen',      cls: 'bg-amber-100 text-amber-700' },
  teilbezahlt:  { label: 'Teilbezahlt', cls: 'bg-lime-100 text-lime-800' },
  bezahlt:      { label: 'Bezahlt',    cls: 'bg-green-100 text-green-700' },
  ueberfaellig: { label: 'Überfällig', cls: 'bg-red-100 text-red-700' },
  storniert:    { label: 'Storniert',  cls: 'bg-neutral-200 text-neutral-500 line-through' },
  angenommen:   { label: 'Angenommen', cls: 'bg-green-100 text-green-700' },
  abgelehnt:    { label: 'Abgelehnt',  cls: 'bg-red-100 text-red-700' },
}

function StatusBadge({ status }) {
  const s = STATUS_BADGE[status] || { label: status, cls: 'bg-neutral-100 text-neutral-600' }
  return <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${s.cls}`}>{s.label}</span>
}

function DocTypeBadge({ type }) {
  const map = { rechnung: 'RE', angebot: 'AN', auftragsbestaetigung: 'AB', gutschrift: 'GS', lieferschein: 'LS' }
  return <span className="text-xs font-mono font-bold text-neutral-400">{map[type] || type}</span>
}

export default function InvoicePage() {
  const navigate = useNavigate()
  // Belegarbeit = Änderungsrecht auf Verkauf; Stornieren und Löschen verlangen
  // das Löschrecht (siehe ActionMenu). Belege ansehen und das PDF öffnen bleibt
  // beim Leserecht.
  const { hasRecht } = useAuth()
  const darfAendern = hasRecht('verkauf', 'schreiben')
  const darfLoeschen = hasRecht('verkauf', 'loeschen')
  const [invoices, setInvoices] = useState([])
  const [loading, setLoading] = useState(true)
  const [activeTab, setActiveTab] = useState('')
  const [search, setSearch] = useState('')
  const [statusFilter, setStatusFilter] = useState('')
  const [actionMenu, setActionMenu] = useState(null)
  const [cancelDialog, setCancelDialog] = useState(null)
  const [paidDialog, setPaidDialog] = useState(null)
  const [sendDialog, setSendDialog] = useState(null)
  const [duplicateDialog, setDuplicateDialog] = useState(null)
  const [advanceDialog, setAdvanceDialog] = useState(null)
  const [selected, setSelected] = useState(new Set())
  const [sentStatus, setSentStatus] = useState({}) // id → 'ok' | 'error'

  const load = useCallback(async () => {
    setLoading(true)
    try {
      let res
      if (activeTab === RECURRING_TAB) {
        // Wiederkehrende Vorlagen (aus Hauptliste ausgeblendet)
        res = await invoiceApi.listTemplates()
      } else {
        const params = {}
        if (activeTab) params.doc_type = activeTab
        if (search) params.search = search
        if (statusFilter) params.status = statusFilter
        res = await invoiceApi.list(params)
      }
      setInvoices(res.data)
    } catch { toast.error('Fehler beim Laden') }
    finally { setLoading(false) }
  }, [activeTab, search, statusFilter])

  useEffect(() => { load() }, [load])
  useEffect(() => { const t = setTimeout(() => load(), 400); return () => clearTimeout(t) }, [search]) // eslint-disable-line

  async function handleCancel(invoice, mode) {
    try {
      await invoiceApi.cancel(invoice.id, mode)
      toast.success(mode === 'with_credit' ? 'Storniert + Gutschrift erstellt' : 'Storniert')
      setCancelDialog(null); load()
    } catch (e) { toast.error(e.response?.data?.detail || 'Fehler') }
  }

  // Zahlungen werden im PaidDialog erfasst; die Liste wird danach neu geladen.

  async function handleSetStatus(invoice, status) {
    const labels = { offen: 'Als offen markiert', gesendet: 'Als gesendet markiert', angenommen: 'Als angenommen markiert', abgelehnt: 'Als abgelehnt markiert' }
    try {
      await invoiceApi.setStatus(invoice.id, status)
      toast.success(labels[status] || 'Status geändert'); load()
    } catch (e) { toast.error(e.response?.data?.detail || 'Fehler') }
  }

  /**
   * Umwandeln, mit Rückfrage bei abgelaufener Bindefrist.
   *
   * Das Backend antwortet in dem Fall mit 409 und dem Grund im Klartext. Erst
   * wenn der Anwender bestätigt, wird derselbe Aufruf mit `trotz_ablauf`
   * wiederholt — die Entscheidung ist kaufmännisch, nicht technisch.
   */
  async function umwandeln(invoice, aufruf, erfolgstext) {
    try {
      const res = await aufruf(invoice.id)
      toast.success(erfolgstext)
      navigate(`/invoices/${res.data.id}`)
    } catch (e) {
      if (e.response?.status === 409) {
        if (!window.confirm(`${e.response.data.detail}\n\nTrotzdem umwandeln?`)) return
        try {
          const res = await aufruf(invoice.id, true)
          toast.success(erfolgstext)
          navigate(`/invoices/${res.data.id}`)
        } catch (e2) { toast.error(e2.response?.data?.detail || 'Fehler') }
        return
      }
      toast.error(e.response?.data?.detail || 'Fehler')
    }
  }

  const handleConvertToAb = (invoice) =>
    umwandeln(invoice, invoiceApi.convertToAb, 'Auftragsbestätigung als Entwurf erstellt')

  const handleConvertToInvoice = (invoice) =>
    umwandeln(invoice, invoiceApi.convertToInvoice, 'Rechnung als Entwurf erstellt')

  async function handleDelete(invoice) {
    if (!window.confirm(`${belegNr(invoice)} wirklich löschen?`)) return
    try {
      await invoiceApi.delete(invoice.id); toast.success('Gelöscht'); load()
    } catch (e) { toast.error(e.response?.data?.detail || 'Fehler') }
  }

  /**
   * Anzahlung anfordern. Die Rückfrage bei abgelaufener Bindefrist gilt hier
   * genauso wie beim Umwandeln — auch eine Anzahlung stützt sich auf die
   * Preise des Angebots.
   */
  async function handleAdvance(invoice, daten) {
    const anfordern = (trotzdem) => invoiceApi.createAdvance(invoice.id, daten, trotzdem)
    try {
      const res = await anfordern(false)
      toast.success('Anzahlungsrechnung als Entwurf erstellt')
      setAdvanceDialog(null)
      navigate(`/invoices/${res.data.id}/edit`)
    } catch (e) {
      if (e.response?.status === 409) {
        if (!window.confirm(`${e.response.data.detail}\n\nTrotzdem anfordern?`)) return
        try {
          const res = await anfordern(true)
          toast.success('Anzahlungsrechnung als Entwurf erstellt')
          setAdvanceDialog(null)
          navigate(`/invoices/${res.data.id}/edit`)
        } catch (e2) { toast.error(e2.response?.data?.detail || 'Fehler') }
        return
      }
      toast.error(e.response?.data?.detail || 'Fehler')
    }
  }

  async function handleFinal(invoice) {
    try {
      const res = await invoiceApi.createFinal(invoice.id, {
        // Die Gesamtleistung stammt aus dem Beleg, aus dem heraus die
        // Schlussrechnung angestoßen wurde — üblicherweise dem Angebot.
        from_invoice_id: invoice.id,
      })
      toast.success('Schlussrechnung als Entwurf erstellt — bitte die Positionen prüfen')
      navigate(`/invoices/${res.data.id}/edit`)
    } catch (e) { toast.error(e.response?.data?.detail || 'Fehler') }
  }

  async function handleDuplicate(invoice, opts) {
    try {
      const res = await invoiceApi.duplicate(invoice.id, opts)
      toast.success('Als neuer Entwurf dupliziert')
      setDuplicateDialog(null)
      navigate(`/invoices/${res.data.id}/edit`)
    } catch (e) { toast.error(e.response?.data?.detail || 'Fehler') }
  }

  function toggleSelect(id) {
    setSelected(s => { const n = new Set(s); n.has(id) ? n.delete(id) : n.add(id); return n })
  }
  function toggleAll() {
    setSelected(s => s.size === invoices.length ? new Set() : new Set(invoices.map(i => i.id)))
  }

  return (
    <div className="">
      <PageHeader icon={Receipt} title="Verkauf" subtitle="Rechnungen · Angebote · Auftragsbestätigungen · Gutschriften · Lieferscheine">
        <div className="flex flex-col sm:flex-row sm:items-center gap-2">
          {darfAendern && selected.size > 0 && (
            <button onClick={() => setSendDialog({ invoices: invoices.filter(i => selected.has(i.id)), mode: 'bulk' })}
              className="flex items-center justify-center gap-1.5 px-3 py-2 text-sm bg-blue-600 text-white rounded-lg hover:bg-blue-700">
              <Mail size={15} /> {selected.size} Beleg{selected.size > 1 ? 'e' : ''} senden
            </button>
          )}
          {darfAendern && (
            <div className="flex items-center gap-2">
              {/* Offene Posten, Mahnlauf, Verkaufsbuch, Monatsabschluss und
                  Kontenplan liegen im Bereich Buchhaltung und werden über den
                  Menüpunkt erreicht. Hier steht nur noch die Belegarbeit. */}
              <button onClick={() => navigate('/invoices/new' + (activeTab ? '?type=' + activeTab : ''))}
                className="flex-1 hidden sm:flex items-center justify-center gap-1.5 px-3 py-2 text-sm bg-primary-600 text-white rounded-lg hover:bg-primary-700">
                <Plus size={15} /> Neu erstellen
              </button>
              <Fab onClick={() => navigate('/invoices/new' + (activeTab ? '?type=' + activeTab : ''))} title="Neu erstellen" />
            </div>
          )}
        </div>
      </PageHeader>

      <div className="flex gap-1 bg-neutral-100 p-1 rounded-lg mb-4 overflow-x-auto flex-nowrap sm:flex-wrap sm:w-fit -mx-4 px-4 sm:mx-0 sm:px-1">
        {DOC_TYPES.map(t => (
          <button key={t.key} onClick={() => setActiveTab(t.key)}
            className={`px-3 py-1.5 text-sm rounded-md transition-all whitespace-nowrap shrink-0 ${activeTab === t.key ? 'bg-surface text-neutral-900 shadow-sm font-medium' : 'text-neutral-600 hover:text-neutral-800'}`}>
            {t.label}
          </button>
        ))}
      </div>

      <div className="flex flex-col sm:flex-row sm:items-center gap-3 mb-4">
        <div className="relative flex-1 sm:max-w-sm">
          <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-neutral-400" />
          <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Nummer, Titel, Kontakt, Artikel, Projekt…"
            className="w-full pl-9 pr-3 py-2 text-sm border border-neutral-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary-300" />
        </div>
        <div className="flex items-center gap-3">
          <select value={statusFilter} onChange={e => setStatusFilter(e.target.value)}
            className="flex-1 sm:flex-none text-sm border border-neutral-200 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-primary-300">
            <option value="">Alle Status</option>
            {Object.entries(STATUS_BADGE).map(([k, v]) => <option key={k} value={k}>{v.label}</option>)}
          </select>
          <button aria-label="Liste aktualisieren" onClick={load} className="p-2 text-neutral-500 hover:text-neutral-800">
            <RefreshCw size={15} className={loading ? 'animate-spin' : ''} />
          </button>
        </div>
      </div>

      <div className="bg-surface border border-neutral-200 rounded-xl overflow-visible">
        {loading && invoices.length === 0 ? (
          <div className="flex items-center justify-center py-16 text-neutral-400">
            <RefreshCw size={20} className="animate-spin mr-2" /> Laden…
          </div>
        ) : invoices.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-16 text-neutral-400">
            <FileText size={40} className="mb-3 opacity-30" />
            <p className="text-sm">Keine Dokumente gefunden</p>
            {darfAendern && (
              <button onClick={() => navigate('/invoices/new' + (activeTab ? '?type=' + activeTab : ''))} className="mt-3 text-sm text-primary-600 hover:underline">Erstes Dokument erstellen</button>
            )}
          </div>
        ) : (
          <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-neutral-100 bg-neutral-50">
                {/* Die Auswahlspalte dient allein dem Sammelversand — ohne
                    Änderungsrecht gäbe es dazu keinen Knopf. */}
                {darfAendern && (
                  <th className="px-3 py-3 w-10">
                    <input type="checkbox" checked={selected.size === invoices.length && invoices.length > 0}
                      onChange={toggleAll} className="w-4 h-4 rounded cursor-pointer" />
                  </th>
                )}
                <th className="text-left px-4 py-3 font-medium text-neutral-500 w-8"></th>
                <th className="text-left px-4 py-3 font-medium text-neutral-500">Nummer</th>
                <th className="text-left px-4 py-3 font-medium text-neutral-500 hidden md:table-cell">Datum</th>
                <th className="text-left px-4 py-3 font-medium text-neutral-500 hidden md:table-cell">Fällig</th>
                <th className="text-left px-4 py-3 font-medium text-neutral-500 hidden sm:table-cell">Titel</th>
                <th className="text-left px-4 py-3 font-medium text-neutral-500 hidden lg:table-cell">Kontakt</th>
                <th className="text-right px-4 py-3 font-medium text-neutral-500">Betrag</th>
                <th className="text-left px-4 py-3 font-medium text-neutral-500">Status</th>
                <th className="px-4 py-3 w-10"></th>
              </tr>
            </thead>
            <tbody className="divide-y divide-neutral-50">
              {invoices.map(inv => (
                <tr key={inv.id}
                  className={`hover:bg-neutral-50 cursor-pointer ${selected.has(inv.id) ? 'bg-blue-50' : ((inv.recurring_source_id || inv.is_recurring_template) ? 'bg-violet-50' : '')}`}
                  onClick={() => navigate(`/invoices/${inv.id}`)}>
                  {darfAendern && (
                    <td className="px-3 py-3" onClick={e => { e.stopPropagation(); toggleSelect(inv.id) }}>
                      <input type="checkbox" checked={selected.has(inv.id)} onChange={() => toggleSelect(inv.id)} className="w-4 h-4 rounded cursor-pointer" />
                    </td>
                  )}
                  <td className="px-4 py-3"><DocTypeBadge type={inv.doc_type} /></td>
                  <td className="px-4 py-3 font-mono font-medium text-neutral-800 whitespace-nowrap">
                    <span className="inline-flex items-center gap-1.5">
                      {inv.recurring_source_id && <Repeat size={13} className="text-violet-500 shrink-0" title="Automatisch aus wiederkehrender Vorlage erzeugt" />}
                      {inv.is_recurring_template && <Repeat size={13} className="text-violet-600 shrink-0" title="Wiederkehrende Vorlage" />}
                      {inv.number
                        ? inv.number
                        : <span className="text-neutral-400 italic" title="Die Belegnummer wird beim Finalisieren vergeben">Entwurf</span>}
                    </span>
                    {inv.billing_stage && (
                      <span className={`ml-1.5 text-[11px] px-1.5 py-0.5 rounded font-sans font-medium ${STUFEN_FARBE[inv.billing_stage] || 'bg-neutral-100 text-neutral-600'}`}
                        title="Gehört zu einem Abrechnungsvorgang">
                        {STUFEN_LABEL[inv.billing_stage] || inv.billing_stage}
                      </span>
                    )}
                  </td>
                  <td className="px-4 py-3 text-neutral-600 hidden md:table-cell whitespace-nowrap">{fmtDate(inv.date)}</td>
                  <td className="px-4 py-3 text-neutral-600 hidden md:table-cell whitespace-nowrap">
                    {inv.due_date ? (
                      <span className={new Date(inv.due_date) < new Date() && inv.status === 'offen' ? 'text-red-600 font-medium' : ''}>
                        {fmtDate(inv.due_date)}
                      </span>
                    ) : '—'}
                  </td>
                  <td className="px-4 py-3 text-neutral-700 hidden sm:table-cell">{inv.title || '—'}</td>
                  <td className="px-4 py-3 text-neutral-500 text-sm hidden lg:table-cell">{inv.contact_name || '—'}</td>
                  <td className="px-4 py-3 text-right font-medium text-neutral-800 whitespace-nowrap">{fmtEuro(inv.total)}</td>
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-2">
                      <StatusBadge status={inv.status} />
                      {/* Abgelaufen ist KEIN Status, sondern aus der Bindefrist
                          abgeleitet — deshalb ein zusätzliches Kennzeichen und
                          kein Ersatz für den Status. */}
                      {inv.expired && (
                        <span title={`Bindefrist am ${fmtDate(inv.valid_until)} abgelaufen`}
                          className="text-xs px-2 py-0.5 rounded-full font-medium bg-orange-100 text-orange-700">
                          Abgelaufen
                        </span>
                      )}
                      {(inv.status === 'gesendet' || sentStatus[inv.id] === 'ok') && sentStatus[inv.id] !== 'error' && (
                        <MailCheck size={15} className="text-green-500 shrink-0" title="Erfolgreich versendet" />
                      )}
                      {sentStatus[inv.id] === 'error' && (
                        <MailX size={15} className="text-orange-500 shrink-0" title="Versand fehlgeschlagen" />
                      )}
                    </div>
                  </td>
                  <td className="px-4 py-3" onClick={e => e.stopPropagation()}>
                    <div className="relative">
                      <button
                        onClick={e => {
                          e.stopPropagation()
                          const rect = e.currentTarget.getBoundingClientRect()
                          setActionMenu(actionMenu === inv.id ? null : { id: inv.id, rect })
                        }}
                        className="p-1 rounded hover:bg-neutral-100 text-neutral-400 hover:text-neutral-700">
                        <MoreHorizontal size={16} />
                      </button>
                      {actionMenu?.id === inv.id && (
                        <ActionMenu invoice={inv}
                          anchorRect={actionMenu.rect}
                          onClose={() => setActionMenu(null)}
                          onSetStatus={s => { setActionMenu(null); handleSetStatus(inv, s) }}
                          onConvertToAb={() => { setActionMenu(null); handleConvertToAb(inv) }}
                          onConvertToInvoice={() => { setActionMenu(null); handleConvertToInvoice(inv) }}
                          onAdvance={() => { setActionMenu(null); setAdvanceDialog(inv) }}
                          onFinal={() => { setActionMenu(null); handleFinal(inv) }}
                          onSend={() => { setActionMenu(null); setSendDialog({ invoices: [inv], mode: 'single' }) }}
                          onCancel={() => { setActionMenu(null); setCancelDialog(inv) }}
                          onPaid={() => { setActionMenu(null); setPaidDialog(inv) }}
                          onDuplicate={() => { setActionMenu(null); setDuplicateDialog(inv) }}
                          onDelete={() => { setActionMenu(null); handleDelete(inv) }}
                          onEdit={() => navigate(`/invoices/${inv.id}/edit`)}
                          darfAendern={darfAendern} darfLoeschen={darfLoeschen} />
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          </div>
        )}
      </div>

      {sendDialog && (
        <SendDialog invoices={sendDialog.invoices} onClose={() => setSendDialog(null)}
          onSent={(ids, status, close = true) => {
            setSentStatus(prev => {
              const next = { ...prev }
              ids.forEach(id => { next[id] = status })
              return next
            })
            if (close) { setSendDialog(null); setSelected(new Set()); load() }
          }} />
      )}
      {cancelDialog && (
        <CancelDialog invoice={cancelDialog} onClose={() => setCancelDialog(null)}
          onConfirm={mode => handleCancel(cancelDialog, mode)} />
      )}
      {paidDialog && (
        <PaidDialog invoice={paidDialog} onClose={() => { setPaidDialog(null); load() }}
          onConfirm={() => load()} darfLoeschen={darfLoeschen} />
      )}
      {duplicateDialog && (
        <DuplicateDialog invoice={duplicateDialog} onClose={() => setDuplicateDialog(null)}
          onConfirm={opts => handleDuplicate(duplicateDialog, opts)} />
      )}
      {advanceDialog && (
        <AdvanceDialog invoice={advanceDialog} onClose={() => setAdvanceDialog(null)}
          onConfirm={daten => handleAdvance(advanceDialog, daten)} />
      )}
    </div>
  )
}

// Rechte im Zeilenmenü: „Öffnen" bleibt immer da — den Beleg ansehen darf, wer
// die Liste sehen darf. Alles, was den Beleg oder seinen Status verändert
// (Duplizieren, Status setzen, Umwandeln, Anzahlung, Schlussrechnung, Versand,
// Zahlungen), verlangt das Änderungsrecht. Stornieren und Löschen verlangen das
// Löschrecht — so hält es auch der Server (invoice.cancel_invoice hängt
// ausdrücklich an require_loeschen).
function ActionMenu({ invoice, anchorRect, onClose, onSetStatus, onConvertToAb, onConvertToInvoice,
                      onAdvance, onFinal, onSend, onCancel, onPaid, onDuplicate, onDelete, onEdit,
                      darfAendern = true, darfLoeschen = true }) {
  const menuRef = useRef(null)
  const MENU_WIDTH = 224 // w-56 = 14rem = 224px

  useEffect(() => {
    const h = e => { if (!menuRef.current?.contains(e.target)) onClose() }
    document.addEventListener('mousedown', h)
    return () => document.removeEventListener('mousedown', h)
  }, [onClose])

  // Berechne Position: unter oder über dem Button
  const spaceBelow = window.innerHeight - anchorRect.bottom
  const estimatedHeight = 320 // px, Schätzung
  const openUp = spaceBelow < estimatedHeight && anchorRect.top > estimatedHeight

  const style = {
    position: 'fixed',
    right: window.innerWidth - anchorRect.right,
    zIndex: 9999,
    width: MENU_WIDTH,
    ...(openUp
      ? { bottom: window.innerHeight - anchorRect.top }
      : { top: anchorRect.bottom + 4 }),
  }

  const { status, doc_type } = invoice
  const isRe = doc_type === 'rechnung'
  const isAn = doc_type === 'angebot'
  const isAb = doc_type === 'auftragsbestaetigung'
  const isGs = doc_type === 'gutschrift'

  return createPortal(
    <div ref={menuRef} style={style} className="bg-surface border border-neutral-200 rounded-lg shadow-lg py-1">
      <button onClick={onEdit} className="w-full text-left px-4 py-2 text-sm hover:bg-neutral-50 flex items-center gap-2">
        <Eye size={14} /> {darfAendern ? 'Öffnen / Bearbeiten' : 'Öffnen'}
      </button>
      {darfAendern && (
      <>
      <button onClick={onDuplicate} className="w-full text-left px-4 py-2 text-sm hover:bg-neutral-50 flex items-center gap-2">
        <Copy size={14} /> Duplizieren
      </button>
      <div className="border-t border-neutral-100 my-1" />

      {status === 'entwurf' && !isAn && !isAb && (
        <button onClick={() => onSetStatus('offen')} className="w-full text-left px-4 py-2 text-sm hover:bg-neutral-50 flex items-center gap-2 text-amber-600">
          <Clock size={14} /> Als offen markieren
        </button>
      )}
      {status === 'entwurf' && (
        <button onClick={() => onSetStatus('gesendet')} className="w-full text-left px-4 py-2 text-sm hover:bg-neutral-50 flex items-center gap-2 text-blue-600">
          <Send size={14} /> Als gesendet markieren
        </button>
      )}
      {status === 'gesendet' && isRe && (
        <button onClick={() => onSetStatus('offen')} className="w-full text-left px-4 py-2 text-sm hover:bg-neutral-50 flex items-center gap-2 text-amber-600">
          <Clock size={14} /> Als offen markieren
        </button>
      )}
      {/* Auch bei 'bezahlt' erreichbar — eine falsch erfasste Zahlung muss
          sich zurücknehmen lassen. */}
      {['offen', 'gesendet', 'ueberfaellig', 'teilbezahlt', 'bezahlt'].includes(status) && (isRe || isGs) && (
        <button onClick={onPaid} className="w-full text-left px-4 py-2 text-sm hover:bg-neutral-50 flex items-center gap-2 text-green-600">
          <Wallet size={14} /> Zahlungen…
        </button>
      )}
      {isAn && status === 'gesendet' && (
        <>
          <button onClick={() => onSetStatus('angenommen')} className="w-full text-left px-4 py-2 text-sm hover:bg-neutral-50 flex items-center gap-2 text-green-600">
            <CheckCircle2 size={14} /> Als angenommen markieren
          </button>
          <button onClick={() => onSetStatus('abgelehnt')} className="w-full text-left px-4 py-2 text-sm hover:bg-neutral-50 flex items-center gap-2 text-red-500">
            <XCircle size={14} /> Als abgelehnt markieren
          </button>
        </>
      )}
      {isAn && ['entwurf', 'gesendet', 'angenommen'].includes(status) && (
        <button onClick={onConvertToAb} className="w-full text-left px-4 py-2 text-sm hover:bg-neutral-50 flex items-center gap-2 text-blue-600">
          <RotateCcw size={14} /> → Auftragsbestätigung
        </button>
      )}
      {(isAn || isAb) && ['entwurf', 'gesendet', 'angenommen', 'offen'].includes(status) && (
        <button onClick={onConvertToInvoice} className="w-full text-left px-4 py-2 text-sm hover:bg-neutral-50 flex items-center gap-2 text-primary-600">
          <RotateCcw size={14} /> → Rechnung umwandeln
        </button>
      )}
      {/* Anzahlung nur aus einem Vorbeleg: Dort steht die Auftragssumme,
          auf die sich der Prozentsatz bezieht. */}
      {(isAn || isAb) && ['entwurf', 'gesendet', 'angenommen', 'offen'].includes(status) && (
        <button onClick={onAdvance} className="w-full text-left px-4 py-2 text-sm hover:bg-neutral-50 flex items-center gap-2 text-sky-600">
          <Layers size={14} /> Anzahlung anfordern…
        </button>
      )}
      {/* Die Schlussrechnung setzt einen Vorgang mit gestellten Anzahlungen
          voraus — ohne Strang gibt es nichts abzuziehen. */}
      {invoice.chain_id && invoice.billing_stage !== 'schluss' && status !== 'storniert' && (
        <button onClick={onFinal} className="w-full text-left px-4 py-2 text-sm hover:bg-neutral-50 flex items-center gap-2 text-emerald-600">
          <FileCheck size={14} /> Schlussrechnung erstellen
        </button>
      )}

      {status !== 'storniert' && (
        <>
          <div className="border-t border-neutral-100 my-1" />
          <button onClick={onSend} className="w-full text-left px-4 py-2 text-sm hover:bg-neutral-50 flex items-center gap-2 text-blue-600">
            <Mail size={14} /> Per E-Mail senden
          </button>
        </>
      )}
      </>
      )}

      {darfLoeschen && isRe && !['storniert', 'bezahlt', 'entwurf'].includes(status) && (
        <>
          <div className="border-t border-neutral-100 my-1" />
          <button onClick={onCancel} className="w-full text-left px-4 py-2 text-sm hover:bg-neutral-50 flex items-center gap-2 text-red-500">
            <XCircle size={14} /> Stornieren
          </button>
        </>
      )}
      {darfLoeschen && ['entwurf', 'storniert'].includes(status) && (
        <>
          <div className="border-t border-neutral-100 my-1" />
          <button onClick={onDelete} className="w-full text-left px-4 py-2 text-sm hover:bg-red-50 flex items-center gap-2 text-red-500">
            <XCircle size={14} /> Löschen
          </button>
        </>
      )}
    </div>,
    document.body
  )
}

function CancelDialog({ invoice, onClose, onConfirm }) {
  const [mode, setMode] = useState('with_credit')
  return (
    <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50 sheet-safe">
      <div className="max-h-full overflow-y-auto bg-surface rounded-xl shadow-xl p-6 w-full max-w-md">
        <h2 className="text-base font-semibold mb-1">Rechnung stornieren</h2>
        <p className="text-sm text-neutral-500 mb-4">{invoice.number} — {Number(invoice.total).toLocaleString('de-AT', { minimumFractionDigits: 2 })} €</p>
        <div className="space-y-2 mb-6">
          <label className="flex items-start gap-3 p-3 border rounded-lg cursor-pointer hover:bg-neutral-50">
            <input type="radio" name="mode" value="with_credit" checked={mode === 'with_credit'} onChange={() => setMode('with_credit')} className="mt-0.5" />
            <div><p className="text-sm font-medium">Stornieren + Gutschrift erstellen</p><p className="text-xs text-neutral-500">Buchhalterisch korrekt — automatische Gegenbuchung</p></div>
          </label>
          <label className="flex items-start gap-3 p-3 border rounded-lg cursor-pointer hover:bg-neutral-50">
            <input type="radio" name="mode" value="status_only" checked={mode === 'status_only'} onChange={() => setMode('status_only')} className="mt-0.5" />
            <div><p className="text-sm font-medium">Nur Status ändern</p><p className="text-xs text-neutral-500">Rechnung wird als storniert markiert, keine Gutschrift</p></div>
          </label>
        </div>
        <div className="flex justify-end gap-2">
          <button onClick={onClose} className="px-4 py-2 text-sm border rounded-lg hover:bg-neutral-50">Abbrechen</button>
          <button onClick={() => onConfirm(mode)} className="px-4 py-2 text-sm bg-red-600 text-white rounded-lg hover:bg-red-700">Stornieren</button>
        </div>
      </div>
    </div>
  )
}

const ZAHLARTEN = [
  ['bank', 'Überweisung'], ['bar', 'Bar'], ['karte', 'Karte'],
  ['lastschrift', 'Lastschrift'], ['verrechnung', 'Verrechnung'], ['sonstige', 'Sonstige'],
]

/**
 * Zahlungen eines Belegs erfassen und einsehen.
 *
 * Ersetzt das frühere einmalige „Als bezahlt markieren": Teil- und
 * Ratenzahlungen sind jetzt abbildbar, und eine Fehleingabe lässt sich
 * zurücknehmen.
 */
function PaidDialog({ invoice, onClose, onConfirm, darfLoeschen = true }) {
  const [stand, setStand] = useState(null)
  const [paidAt, setPaidAt] = useState(new Date().toISOString().slice(0, 10))
  const [betrag, setBetrag] = useState('')
  const [zahlart, setZahlart] = useState('bank')
  const [verwendung, setVerwendung] = useState('')
  const [laeuft, setLaeuft] = useState(false)
  const [skonto, setSkonto] = useState(null)

  const laden = useCallback(async () => {
    try {
      const res = await invoiceApi.listPayments(invoice.id)
      setStand(res.data)
      setBetrag(Number(res.data.open_amount).toFixed(2))
    } catch { toast.error('Zahlungen konnten nicht geladen werden') }
  }, [invoice.id])

  useEffect(() => { laden() }, [laden])

  // Skonto-Vorschau hängt am Zahlungsdatum: Ob die Frist gewahrt ist,
  // entscheidet der Tag des Eingangs, nicht der Tag der Erfassung.
  useEffect(() => {
    let abgebrochen = false
    invoiceApi.skontoPreview(invoice.id, paidAt)
      .then(res => { if (!abgebrochen) setSkonto(res.data) })
      .catch(() => { if (!abgebrochen) setSkonto(null) })
    return () => { abgebrochen = true }
  }, [invoice.id, paidAt])

  async function skontoAusbuchen() {
    const rest = Number(stand?.open_amount ?? 0)
    if (!window.confirm(
      `${fmtEuro(rest)} als Skonto ausbuchen?\n\n` +
      `Das mindert das Entgelt und berichtigt die Umsatzsteuer zum ${fmtDate(paidAt)} ` +
      `(§ 16 UStG). Die Rechnung selbst bleibt unverändert.`)) return
    setLaeuft(true)
    try {
      const res = await invoiceApi.grantSkonto(invoice.id, { paid_at: paidAt })
      setStand(res.data)
      setBetrag('0.00')
      toast.success('Skonto ausgebucht')
      onConfirm?.()
    } catch (e) { toast.error(e.response?.data?.detail || 'Skonto konnte nicht ausgebucht werden') }
    finally { setLaeuft(false) }
  }

  async function erfassen() {
    if (!betrag || Number(betrag) === 0) { toast.error('Bitte einen Betrag angeben'); return }
    setLaeuft(true)
    try {
      const res = await invoiceApi.addPayment(invoice.id, {
        paid_at: paidAt, amount: betrag, method: zahlart,
        reference: verwendung || null,
      })
      setStand(res.data)
      setBetrag(Number(res.data.open_amount).toFixed(2))
      setVerwendung('')
      toast.success(res.data.status === 'bezahlt' ? 'Beleg ist beglichen' : 'Zahlung erfasst')
      onConfirm?.()
    } catch (e) { toast.error(e.response?.data?.detail || 'Fehler beim Erfassen') }
    finally { setLaeuft(false) }
  }

  async function zuruecknehmen(id) {
    if (!window.confirm('Diese Zahlung wirklich zurücknehmen?')) return
    try {
      const res = await invoiceApi.deletePayment(id)
      setStand(res.data)
      setBetrag(Number(res.data.open_amount).toFixed(2))
      toast.success('Zahlung zurückgenommen')
      onConfirm?.()
    } catch { toast.error('Fehler') }
  }

  const offen = Number(stand?.open_amount ?? 0)

  return (
    <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50 sheet-safe">
      <div className="max-h-full overflow-y-auto bg-surface rounded-xl shadow-xl p-6 w-full max-w-lg">
        <h2 className="text-base font-semibold mb-1">Zahlungen zu {belegNr(invoice)}</h2>

        {stand && (
          <div className="flex items-center gap-4 text-sm mb-4 pb-3 border-b">
            <span className="text-neutral-500">Gesamt <strong className="text-neutral-800">{fmtEuro(stand.total)}</strong></span>
            <span className="text-neutral-500">Bezahlt <strong className="text-neutral-800">{fmtEuro(stand.paid_total)}</strong></span>
            <span className={offen === 0 ? 'text-green-600' : stand.overpaid ? 'text-amber-600' : 'text-red-600'}>
              {stand.overpaid ? 'Überzahlt ' : 'Offen '}
              <strong>{fmtEuro(Math.abs(offen))}</strong>
            </span>
          </div>
        )}

        {stand?.payments?.length > 0 && (
          <div className="mb-4 divide-y border rounded-lg">
            {stand.payments.map(z => (
              <div key={z.id} className="flex items-center justify-between px-3 py-2 text-sm">
                <div>
                  <span className="font-medium text-neutral-800">{fmtEuro(z.amount)}</span>
                  {z.payment_type === 'skonto' && (
                    <span className="ml-2 px-1.5 py-0.5 rounded text-[11px] bg-amber-100 text-amber-700">Skonto</span>
                  )}
                  <span className="text-neutral-400 ml-2">
                    {fmtDate(z.paid_at)}
                    {z.payment_type !== 'skonto' && z.method &&
                      ' · ' + (ZAHLARTEN.find(a => a[0] === z.method)?.[1] || z.method)}
                    {z.reference && ' · ' + z.reference}
                  </span>
                </div>
                {/* Zurücknehmen ist serverseitig ein DELETE → Löschrecht. */}
                {darfLoeschen && (
                  <button onClick={() => zuruecknehmen(z.id)} title="Zahlung zurücknehmen"
                    className="p-1 text-neutral-400 hover:text-red-500"><Trash2 size={13} /></button>
                )}
              </div>
            ))}
          </div>
        )}

        {/* Skonto: eigener Vorgang, nicht als Zahlung getarnt. Der Hinweis
            nennt die Steuerwirkung, damit klar ist, was hier passiert. */}
        {skonto?.skonto_percent && offen > 0 && (
          <div className={`mb-4 rounded-lg border px-3 py-2.5 text-sm ${
            skonto.in_frist ? 'border-green-200 bg-green-50' : 'border-neutral-200 bg-neutral-50'}`}>
            <div className="flex items-center justify-between gap-3">
              <div>
                <p className="font-medium text-neutral-800">
                  {Number(skonto.skonto_percent)} % Skonto
                  <span className="text-neutral-500 font-normal">
                    {' '}· vereinbart {fmtEuro(skonto.betrag)}
                    {skonto.frist_ende && ` · Frist bis ${fmtDate(skonto.frist_ende)}`}
                  </span>
                </p>
                {skonto.hinweis && <p className="text-xs text-neutral-500 mt-0.5">{skonto.hinweis}</p>}
              </div>
              <button onClick={skontoAusbuchen} disabled={laeuft}
                className="shrink-0 px-3 py-1.5 text-xs border border-neutral-300 rounded-lg bg-surface hover:bg-neutral-50 disabled:opacity-60">
                Rest {fmtEuro(offen)} ausbuchen
              </button>
            </div>
          </div>
        )}

        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="block text-sm font-medium text-neutral-700 mb-1">Zahlungsdatum</label>
            <input type="date" value={paidAt} onChange={e => setPaidAt(e.target.value)}
              className="w-full border border-neutral-200 rounded-lg px-3 py-2 text-sm" />
          </div>
          <div>
            <label className="block text-sm font-medium text-neutral-700 mb-1">Betrag</label>
            <input type="number" step="0.01" value={betrag} onChange={e => setBetrag(e.target.value)}
              className="w-full border border-neutral-200 rounded-lg px-3 py-2 text-sm text-right" />
          </div>
          <div>
            <label className="block text-sm font-medium text-neutral-700 mb-1">Zahlungsart</label>
            <select value={zahlart} onChange={e => setZahlart(e.target.value)}
              className="w-full border border-neutral-200 rounded-lg px-3 py-2 text-sm">
              {ZAHLARTEN.map(([k, l]) => <option key={k} value={k}>{l}</option>)}
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-neutral-700 mb-1">Verwendungszweck</label>
            <input value={verwendung} onChange={e => setVerwendung(e.target.value)} placeholder="optional"
              className="w-full border border-neutral-200 rounded-lg px-3 py-2 text-sm" />
          </div>
        </div>

        <div className="flex justify-end gap-2 mt-5">
          <button onClick={onClose} className="px-4 py-2 text-sm border rounded-lg hover:bg-neutral-50">Schließen</button>
          <button onClick={erfassen} disabled={laeuft}
            className="px-4 py-2 text-sm bg-green-600 text-white rounded-lg hover:bg-green-700 disabled:opacity-60">
            Zahlung erfassen
          </button>
        </div>
      </div>
    </div>
  )
}

/**
 * Anzahlung anfordern.
 *
 * Prozentsatz ODER Betrag — nie beides. Der umgerechnete Betrag steht sofort
 * daneben, damit niemand blind auf einen Prozentsatz klickt: Was der Kunde
 * bekommt, ist der Betrag.
 */
function AdvanceDialog({ invoice, onClose, onConfirm }) {
  const [modus, setModus] = useState('percent')
  const [prozent, setProzent] = useState('30')
  const [betrag, setBetrag] = useState('')
  const [text, setText] = useState('')
  const [faellig, setFaellig] = useState('')

  const grundlage = Number(invoice.subtotal ?? invoice.total ?? 0)
  const vorschau = modus === 'percent'
    ? (grundlage * (Number(prozent) || 0)) / 100
    : (Number(betrag) || 0)
  const zuViel = grundlage > 0 && vorschau > grundlage
  const gueltig = vorschau > 0 && !zuViel

  const senden = () => onConfirm({
    percent: modus === 'percent' ? Number(prozent) : null,
    amount:  modus === 'amount'  ? Number(betrag)  : null,
    description: text || null,
    due_date: faellig || null,
  })

  return (
    <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50 sheet-safe">
      <div className="max-h-full overflow-y-auto bg-surface rounded-xl shadow-xl p-6 w-full max-w-md">
        <h2 className="text-base font-semibold mb-1">Anzahlung anfordern</h2>
        <p className="text-sm text-neutral-500 mb-4">
          {belegNr(invoice)} — Auftragssumme netto {fmtEuro(grundlage)}
        </p>

        <div className="flex gap-1 bg-neutral-100 p-1 rounded-lg mb-4 w-fit">
          {[['percent', 'Prozentsatz'], ['amount', 'Fester Betrag']].map(([k, label]) => (
            <button key={k} onClick={() => setModus(k)}
              className={`px-3 py-1.5 text-sm rounded-md ${modus === k ? 'bg-surface shadow-sm font-medium' : 'text-neutral-600'}`}>
              {label}
            </button>
          ))}
        </div>

        {modus === 'percent' ? (
          <div className="mb-4">
            <label className="block text-sm text-neutral-600 mb-1">Anteil der Auftragssumme</label>
            <div className="flex items-center gap-2">
              <input type="number" min="0" max="100" step="1" value={prozent}
                onChange={e => setProzent(e.target.value)}
                className="w-28 px-3 py-2 border rounded-lg" />
              <span className="text-neutral-500">%</span>
              <span className="ml-auto text-sm font-medium text-neutral-800">= {fmtEuro(vorschau)} netto</span>
            </div>
          </div>
        ) : (
          <div className="mb-4">
            <label className="block text-sm text-neutral-600 mb-1">Nettobetrag</label>
            <input type="number" min="0" step="0.01" value={betrag}
              onChange={e => setBetrag(e.target.value)}
              className="w-full px-3 py-2 border rounded-lg" placeholder="0,00" />
          </div>
        )}

        <div className="mb-4">
          <label className="block text-sm text-neutral-600 mb-1">Positionstext (optional)</label>
          <input value={text} onChange={e => setText(e.target.value)}
            className="w-full px-3 py-2 border rounded-lg"
            placeholder={modus === 'percent'
              ? `Anzahlung ${prozent || 0} % auf ${belegNr(invoice)}`
              : `Anzahlung auf ${belegNr(invoice)}`} />
        </div>

        <div className="mb-5">
          <label className="block text-sm text-neutral-600 mb-1">Zahlungsziel (optional)</label>
          <input type="date" value={faellig} onChange={e => setFaellig(e.target.value)}
            className="w-full px-3 py-2 border rounded-lg" />
        </div>

        {zuViel && (
          <p className="mb-4 text-sm text-red-600">
            Die Anzahlung übersteigt die Auftragssumme.
          </p>
        )}
        <p className="mb-5 text-xs text-neutral-500">
          Es entsteht ein Entwurf. Die Umsatzsteuer wird bereits mit dieser
          Rechnung fällig und später in der Schlussrechnung wieder abgezogen.
        </p>

        <div className="flex justify-end gap-2">
          <button onClick={onClose} className="px-4 py-2 text-sm text-neutral-600 hover:bg-neutral-100 rounded-lg">
            Abbrechen
          </button>
          <button onClick={senden} disabled={!gueltig}
            className="px-4 py-2 text-sm bg-primary-600 text-white rounded-lg hover:bg-primary-700 disabled:opacity-40">
            Anzahlungsrechnung erstellen
          </button>
        </div>
      </div>
    </div>
  )
}


function DuplicateDialog({ invoice, onClose, onConfirm }) {
  const [opts, setOpts] = useState({ positions: true, texts: true, contact: true, attachments: false })
  const toggle = k => setOpts(o => ({ ...o, [k]: !o[k] }))
  const rows = [
    { key: 'positions',   label: 'Positionen',                desc: 'Alle Positionszeilen übernehmen' },
    { key: 'texts',       label: 'Einleitungs-/Schlusstext',  desc: 'Einleitung, Schlusstext und Notizen' },
    { key: 'contact',     label: 'Kontakt & Referenz',        desc: 'Empfänger, Projekt, Titel und Referenz' },
    { key: 'attachments', label: 'Anhänge',                   desc: 'Datei-Anhänge des Belegs mitkopieren' },
  ]
  return (
    <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50 sheet-safe">
      <div className="max-h-full overflow-y-auto bg-surface rounded-xl shadow-xl p-6 w-full max-w-md">
        <h2 className="text-base font-semibold mb-1">Beleg duplizieren</h2>
        <p className="text-sm text-neutral-500 mb-4">{invoice.number} — es entsteht ein neuer Entwurf mit eigener Nummer.</p>
        <div className="space-y-2 mb-6">
          {rows.map(r => (
            <label key={r.key} className="flex items-start gap-3 p-3 border rounded-lg cursor-pointer hover:bg-neutral-50">
              <input type="checkbox" checked={opts[r.key]} onChange={() => toggle(r.key)} className="mt-0.5 w-4 h-4 rounded" />
              <div><p className="text-sm font-medium">{r.label}</p><p className="text-xs text-neutral-500">{r.desc}</p></div>
            </label>
          ))}
        </div>
        <div className="flex justify-end gap-2">
          <button onClick={onClose} className="px-4 py-2 text-sm border rounded-lg hover:bg-neutral-50">Abbrechen</button>
          <button onClick={() => onConfirm(opts)} className="px-4 py-2 text-sm bg-primary-600 text-white rounded-lg hover:bg-primary-700 flex items-center gap-1.5">
            <Copy size={15} /> Duplizieren
          </button>
        </div>
      </div>
    </div>
  )
}

function DatacenterPicker({ onSelect, onClose }) {
  const [items, setItems] = useState([])
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')
  const [selected, setSelected] = useState([])

  useEffect(() => {
    datacenterApi.listAll().then(r => {
      setItems(r.data?.attachments || [])
    }).catch(() => {}).finally(() => setLoading(false))
  }, [])

  const filtered = items.filter(it =>
    (it.filename || it.name || '').toLowerCase().includes(search.toLowerCase())
  )

  function toggle(id) {
    setSelected(s => s.includes(id) ? s.filter(x => x !== id) : [...s, id])
  }

  function handleConfirm() {
    const chosen = items.filter(it => selected.includes(it.id))
    onSelect(chosen)
    onClose()
  }

  return (
    <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-[60] sheet-safe">
      <div className="max-h-full overflow-y-auto bg-surface rounded-xl shadow-xl p-5 w-full max-w-md flex flex-col" style={{maxHeight:'80vh'}}>
        <div className="flex items-center justify-between mb-3">
          <h3 className="font-semibold text-sm flex items-center gap-2">
            <HardDrive size={15} className="text-blue-500" /> Datacenter
          </h3>
          <button aria-label="Schließen" onClick={onClose}><XIcon size={16} /></button>
        </div>
        <input
          className="border rounded-lg px-3 py-1.5 text-sm mb-3 outline-none focus:ring-2 focus:ring-blue-300"
          placeholder="Suchen…"
          value={search}
          onChange={e => setSearch(e.target.value)}
        />
        <div className="flex-1 overflow-y-auto divide-y border rounded-lg mb-3">
          {loading && <div className="p-4 text-center text-sm text-neutral-400">Lädt…</div>}
          {!loading && filtered.length === 0 && <div className="p-4 text-center text-sm text-neutral-400">Keine Dateien gefunden</div>}
          {filtered.map(it => (
            <label key={it.id} className="flex items-center gap-2 px-3 py-2 hover:bg-neutral-50 cursor-pointer text-sm">
              <input type="checkbox" checked={selected.includes(it.id)} onChange={() => toggle(it.id)} className="rounded" />
              <span className="truncate">{it.filename || it.name || it.id}</span>
              {it.file_size && <span className="ml-auto text-xs text-neutral-400 shrink-0">{(it.file_size/1024).toFixed(0)} KB</span>}
            </label>
          ))}
        </div>
        <div className="flex justify-end gap-2">
          <button onClick={onClose} className="px-3 py-1.5 text-sm border rounded-lg hover:bg-neutral-50">Abbrechen</button>
          <button onClick={handleConfirm} disabled={selected.length === 0}
            className="px-3 py-1.5 text-sm bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50">
            {selected.length > 0 ? `${selected.length} hinzufügen` : 'Auswählen'}
          </button>
        </div>
      </div>
    </div>
  )
}

function SendDialog({ invoices, onClose, onSent }) {
  const [sending, setSending] = useState(false)
  const [results, setResults] = useState(null)
  const [error, setError] = useState(null)
  const [attachments, setAttachments] = useState([])
  const [showDcPicker, setShowDcPicker] = useState(false)
  const [ccEmail, setCcEmail] = useState('')
  const [contactEmail, setContactEmail] = useState('')
  const [emailSubject, setEmailSubject] = useState('')
  const [emailBody, setEmailBody] = useState('')
  const isBulk = invoices.length > 1
  const single = invoices[0]

  // Kontakt-E-Mail + Vorlage laden (nur Einzelversand)
  useEffect(() => {
    if (isBulk || !single?.contact_id) return
    masterdataApi.getRecord('kontakte', single.contact_id)
      .then(r => setContactEmail(r.data?.data?.email || ''))
      .catch(() => {})
  }, [single?.contact_id, isBulk])

  useEffect(() => {
    const dt = isBulk ? null : single?.doc_type
    if (!dt) return
    invoiceApi.getEmailTemplate(dt)
      .then(r => {
        setEmailSubject(r.data.subject || '')
        setEmailBody(r.data.body_html || '')
      })
      .catch(() => {})
  }, [single?.doc_type, isBulk])

  function buildExtraAttachments() {
    return attachments.map(a => {
      if (a.source === 'datacenter') return { type: 'datacenter', id: a.id, filename: a.filename }
      return { type: 'local', filename: a.filename, content_base64: a.content_base64 }
    })
  }

  function handleLocalFile(e) {
    const files = Array.from(e.target.files)
    files.forEach(file => {
      const reader = new FileReader()
      reader.onload = ev => {
        const b64 = ev.target.result.split(',')[1]
        setAttachments(s => [...s, { source: 'local', filename: file.name, content_base64: b64, _key: Math.random() }])
      }
      reader.readAsDataURL(file)
    })
    e.target.value = ''
  }

  function removeAttachment(key) {
    setAttachments(s => s.filter(a => a._key !== key))
  }

  async function handleSend() {
    setSending(true)
    setError(null)
    const extra = buildExtraAttachments()
    try {
      if (isBulk) {
        const res = await invoiceApi.bulkSendEmail(invoices.map(i => i.id))
        setResults(res.data.results)
        const ok = res.data.results.filter(r => r.ok).length
        toast.success(`${ok} von ${invoices.length} Belegen versendet`)
        const statusMap = {}
        res.data.results.forEach(r => { statusMap[r.id] = r.ok ? 'ok' : 'error' })
      } else {
        await invoiceApi.sendEmail(single.id, null, extra, ccEmail, emailSubject, emailBody)
        toast.success(`${single.number} versendet`)
        onSent([single.id], 'ok', true)
        return
      }
    } catch (e) {
      const msg = e.response?.data?.detail || 'Fehler beim Versenden'
      setError(msg)
      onSent(invoices.map(i => i.id), 'error', false)
    } finally { setSending(false) }
  }

  return (
    <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50 sheet-safe">
      {showDcPicker && (
        <DatacenterPicker
          onClose={() => setShowDcPicker(false)}
          onSelect={chosen => {
            const newItems = chosen.map(it => ({
              source: 'datacenter', id: it.id,
              filename: it.filename || it.name || it.id,
              _key: Math.random()
            }))
            setAttachments(s => {
              const existingIds = s.filter(a => a.source === 'datacenter').map(a => a.id)
              return [...s, ...newItems.filter(n => !existingIds.includes(n.id))]
            })
          }}
        />
      )}
      <div className="bg-surface rounded-xl shadow-xl p-6 w-full max-w-lg">
        <h2 className="text-base font-semibold mb-1 flex items-center gap-2">
          <Mail size={16} className="text-blue-600" />
          {isBulk ? `${invoices.length} Belege per E-Mail senden` : `${single.number} per E-Mail senden`}
        </h2>

        {/* Empfänger-Info (nur Einzelversand) */}
        {!isBulk && (
          <div className="mb-4 bg-neutral-50 border rounded-lg px-4 py-3 text-sm space-y-2">
            <div className="flex items-center gap-2">
              <span className="text-neutral-400 w-16 shrink-0 text-xs">Kontakt</span>
              <span className="font-medium text-neutral-800">{single.contact_name || '—'}</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-neutral-400 w-16 shrink-0 text-xs">An</span>
              <span className="text-neutral-700">{contactEmail || <span className="italic text-neutral-400">Keine E-Mail hinterlegt</span>}</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-neutral-400 w-16 shrink-0 text-xs">CC</span>
              <input
                type="email"
                value={ccEmail}
                onChange={e => setCcEmail(e.target.value)}
                placeholder="CC-Adresse (optional)"
                className="flex-1 border border-neutral-200 rounded-lg px-2 py-1 text-sm focus:outline-none focus:ring-2 focus:ring-blue-300"
              />
            </div>
          </div>
        )}

        {/* Betreff */}
        {!isBulk && (
          <div className="mb-3">
            <label className="block text-xs font-medium text-neutral-500 mb-1">Betreff</label>
            <input
              value={emailSubject}
              onChange={e => setEmailSubject(e.target.value)}
              className="w-full border border-neutral-200 rounded-lg px-3 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-blue-300"
              placeholder="Betreff"
            />
          </div>
        )}

        {/* E-Mail-Text */}
        {!isBulk && (
          <div className="mb-3">
            <label className="block text-xs font-medium text-neutral-500 mb-1">E-Mail-Text</label>
            <RichTextEditor value={emailBody} onChange={setEmailBody} minHeight="140px" />
          </div>
        )}

        {/* Anhänge */}
        {attachments.length > 0 && (
          <div className="mb-3 space-y-1">
            {attachments.map(a => (
              <div key={a._key} className="flex items-center gap-2 text-xs bg-neutral-50 border rounded-lg px-2 py-1">
                <Paperclip size={11} className="text-neutral-400 shrink-0" />
                <span className="truncate flex-1">{a.filename}</span>
                <span className="text-neutral-400 shrink-0">{a.source === 'datacenter' ? 'DC' : 'Lokal'}</span>
                <button onClick={() => removeAttachment(a._key)} className="text-neutral-400 hover:text-red-500">
                  <XIcon size={13} />
                </button>
              </div>
            ))}
          </div>
        )}

        {/* Anhang hinzufügen Button */}
        <div className="flex gap-2 mb-4">
          <button
            onClick={() => setShowDcPicker(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs border rounded-lg hover:bg-neutral-50 text-neutral-600"
          >
            <HardDrive size={13} /> Datacenter
          </button>
          <label className="flex items-center gap-1.5 px-3 py-1.5 text-xs border rounded-lg hover:bg-neutral-50 text-neutral-600 cursor-pointer">
            <Upload size={13} /> Lokale Datei
            <input type="file" className="hidden" multiple onChange={handleLocalFile} />
          </label>
        </div>

        {error && (
          <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-lg text-sm text-red-700 whitespace-pre-wrap">
            <strong>Fehler:</strong> {error}
          </div>
        )}
        {!results ? (
          <>
            <div className="bg-neutral-50 rounded-lg p-3 mb-4 max-h-40 overflow-y-auto divide-y">
              {invoices.map(inv => (
                <div key={inv.id} className="py-2 flex items-center justify-between text-sm">
                  <span className="font-medium text-neutral-700">{belegNr(inv)}</span>
                  <span className="text-neutral-500 text-xs truncate max-w-[200px]">{inv.title || '—'}</span>
                </div>
              ))}
            </div>
            <div className="flex justify-end gap-2">
              <button onClick={onClose} className="px-4 py-2 text-sm border rounded-lg hover:bg-neutral-50">Abbrechen</button>
              <button onClick={handleSend} disabled={sending}
                className="flex items-center gap-2 px-4 py-2 text-sm bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-60">
                {sending ? <RefreshCw size={14} className="animate-spin" /> : <Mail size={14} />}
                {sending ? 'Wird gesendet…' : 'Jetzt senden'}
              </button>
            </div>
          </>
        ) : (
          <>
            <div className="space-y-2 mb-4 max-h-48 overflow-y-auto">
              {results.map(r => (
                <div key={r.id} className={`flex items-center gap-2 text-sm p-2 rounded ${r.ok ? 'bg-green-50' : 'bg-red-50'}`}>
                  {r.ok ? <CheckCircle2 size={14} className="text-green-600 shrink-0" /> : <XCircle size={14} className="text-red-500 shrink-0" />}
                  <span className="font-medium">{r.number}</span>
                  {r.ok ? <span className="text-neutral-500 text-xs">→ {r.to}</span> : <span className="text-red-500 text-xs">{r.error}</span>}
                </div>
              ))}
            </div>
            <div className="flex justify-end">
              <button onClick={() => {
                const okIds = results.filter(r => r.ok).map(r => r.id)
                const errIds = results.filter(r => !r.ok).map(r => r.id)
                if (okIds.length) onSent(okIds, 'ok', false)
                if (errIds.length) onSent(errIds, 'error', false)
                onSent([], 'ok', true)
              }} className="px-4 py-2 text-sm bg-primary-600 text-white rounded-lg hover:bg-primary-700">Schließen</button>
            </div>
          </>
        )}
      </div>
    </div>
  )
}
