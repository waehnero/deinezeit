import { useState, useEffect, useCallback } from 'react'
import PageHeader from '../components/PageHeader'
import Fab from '../components/Fab'
import { useNavigate, useLocation } from 'react-router'
import { zeiterfassungApi, usersApi, datacenterApi } from '../services/api'
import toast from 'react-hot-toast'
import {
  Play, Square, Plus, Trash2, Search, ChevronLeft, ChevronRight,
  Clock, Loader2, X, Settings2, Timer, Euro, FileText, Mic, Sparkles, Upload
} from 'lucide-react'
import { useAuth } from '../contexts/AuthContext'
import AttachmentQuickBar from '../components/AttachmentQuickBar'
import VoiceEntryDialog from '../components/VoiceEntryDialog'
import ZeitenImport from '../components/ZeitenImport'
import ZeitprojektSuche from '../components/ZeitprojektSuche'
import TimeSuggestInput from '../components/TimeSuggestInput'
import ProjektzeitModal from '../components/ProjektzeitModal'
import StatusMenu, { ENTRY_STATUS } from '../components/ProjektzeitStatus'
import {
  fmtMinutes, fmtElapsed, fmtTime, fmtDate, nowIso, isoToDateLocal, isoToTimeLocal,
  localToIso, isoToLocalDateStr, nowTimeLocal,
} from '../utils/zeit'


// ── Laufender Timer (Karte im Screenshot-Stil) ────────────────────────────────
function RunningTimerCard({ entry, onStop, onStopAt, onPause, onSwitch, onDelete, onUpdate }) {
  const [elapsed, setElapsed] = useState(() => fmtElapsed(entry.started_at))
  const [note, setNote] = useState(entry.note || '')
  const [billable, setBillable] = useState(entry.billable)
  const [project, setProject] = useState({
    projectId: entry.project_id,
    projectName: entry.project_name || '',
    contactName: entry.contact_name || '',
  })
  const [pause, setPause] = useState(entry.pause_minutes || 0)
  // Startzeit manuell anpassbar (z.B. wenn der Start verpasst wurde)
  const [startTime, setStartTime] = useState(isoToTimeLocal(entry.started_at))
  // Endzeit: läuft mit („Jetzt"), bis der Benutzer sie manuell setzt →
  // dann wird zur Bestätigung „Stopp um HH:MM" angeboten
  const [endTime, setEndTime] = useState(nowTimeLocal())
  const [endDirty, setEndDirty] = useState(false)

  // Sekunden-Ticker (Elapsed + laufende Endzeit)
  useEffect(() => {
    const id = setInterval(() => {
      setElapsed(fmtElapsed(entry.started_at))
      setEndTime(t => endDirty ? t : nowTimeLocal())
    }, 1000)
    return () => clearInterval(id)
  }, [entry.started_at, endDirty])

  // Felder live speichern (Debounce) — inkl. geänderter Startzeit
  useEffect(() => {
    const t = setTimeout(() => {
      onUpdate({ note, billable, project, pause, startTime })
    }, 800)
    return () => clearTimeout(t)
  }, [note, billable, project, pause, startTime])

  return (
    <div className={`bg-surface rounded-2xl border-2 overflow-hidden mb-6 ${billable ? 'border-green-400' : 'border-orange-400'}`}>
      {/* Farbiger Akzent-Streifen oben */}
      <div className={`h-1 ${billable ? 'bg-gradient-to-r from-green-400 to-green-500' : 'bg-gradient-to-r from-orange-400 to-orange-500'}`} />

      <div className="p-5">
        <div className="flex flex-col sm:flex-row gap-4 sm:gap-6">
          {/* Stoppuhr-Icon */}
          <div className="hidden sm:block flex-shrink-0 pt-1">
            <div className="w-9 h-9 rounded-xl bg-green-50 flex items-center justify-center">
              <Timer size={18} className="text-green-600" />
            </div>
          </div>

          {/* Linke Spalte: Zeitprojekt + Notiz */}
          <div className="flex-1 min-w-0 grid grid-cols-1 gap-3">
            <div>
              <label className="block text-xs font-medium text-gray-500 mb-1">Zeitprojekt</label>
              <ZeitprojektSuche value={project} onChange={setProject} />
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-500 mb-1">Notiz</label>
              <textarea
                value={note}
                onChange={(e) => setNote(e.target.value)}
                rows={2}
                placeholder="Was machst du gerade?"
                className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-primary-500 resize-none"
              />
            </div>
          </div>

          {/* Rechte Spalte: Startzeit, Endzeit (beides anpassbar), Pause, Verrechenbar */}
          <div className="w-full sm:w-48 sm:flex-shrink-0 grid grid-cols-2 sm:grid-cols-1 gap-3">
            <div>
              <label className="block text-xs font-medium text-gray-500 mb-1">Startzeit</label>
              <TimeSuggestInput
                value={startTime}
                onChange={setStartTime}
                title="Startzeit manuell anpassen"
                suggestions={[{ label: 'Jetzt', time: nowTimeLocal() }]}
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-500 mb-1">Endzeit</label>
              <TimeSuggestInput
                value={endTime}
                onChange={(t) => { setEndTime(t); setEndDirty(true) }}
                title="Endzeit setzen — stoppt den Timer zur gewählten Zeit"
                suggestions={[{ label: 'Jetzt', time: nowTimeLocal() }]}
              />
              {endDirty && (
                <div className="flex items-center gap-1.5 mt-1.5">
                  <button type="button"
                    onClick={() => onStopAt(endTime, { note, billable, project, pause })}
                    className="flex-1 px-2 py-1 text-xs font-medium text-white bg-gray-700 hover:bg-gray-800 rounded-lg transition flex items-center justify-center gap-1">
                    <Square size={9} fill="white" /> Stopp um {endTime}
                  </button>
                  <button aria-label="Endzeit-Änderung verwerfen" type="button" title="Endzeit-Änderung verwerfen"
                    onClick={() => { setEndDirty(false); setEndTime(nowTimeLocal()) }}
                    className="p-1 text-gray-400 hover:text-gray-600 rounded-lg transition">
                    <X size={13} />
                  </button>
                </div>
              )}
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-500 mb-1">Pause</label>
              <div className="flex items-center gap-2">
                <input type="number" value={pause} onChange={(e) => setPause(Number(e.target.value))} min={0}
                  className="w-16 px-2 py-2 border border-gray-300 rounded-lg text-sm text-center focus:outline-none focus:ring-2 focus:ring-primary-500" />
                <span className="text-xs text-gray-400">min</span>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <input type="checkbox" id="run-billable" checked={billable} onChange={(e) => setBillable(e.target.checked)}
                className="w-4 h-4 rounded accent-primary-600" />
              <label htmlFor="run-billable" className="text-sm text-gray-700 cursor-pointer">Verrechenbar</label>
            </div>
          </div>
        </div>

        {/* Schnellzugriff: Anhänge */}
        <div className="mt-4 pt-4 border-t border-gray-100">
          <AttachmentQuickBar entityType="zeiterfassung" entityId={entry.id} />
        </div>

        {/* Action-Bar */}
        <div className="flex items-center mt-4 pt-4 border-t border-gray-100">
          {/* Löschen */}
          <button onClick={onDelete}
            className="px-3 py-1.5 text-sm text-gray-400 hover:text-red-500 hover:bg-red-50 rounded-lg transition border border-gray-200">
            Löschen
          </button>

          {/* Elapsed */}
          <div className="flex items-center gap-2 mx-auto">
            <div className="w-3 h-3 bg-red-500 rounded-full animate-pulse" />
            <span className="text-xl font-bold text-gray-800 tabular-nums">{elapsed}</span>
          </div>

          {/* Pause / Wechseln / Stop */}
          <div className="flex items-center gap-2">
            <button onClick={onPause}
              className="px-3 py-1.5 text-sm font-medium text-gray-600 border border-gray-300 rounded-lg hover:bg-gray-50 transition">
              Pause
            </button>
            <button onClick={onSwitch}
              className="px-3 py-1.5 text-sm font-medium text-white bg-primary-600 hover:bg-primary-700 rounded-lg transition">
              Wechseln
            </button>
            <button onClick={() => onStop({ note, billable, project, pause })}
              className="px-3 py-1.5 text-sm font-medium text-white bg-gray-700 hover:bg-gray-800 rounded-lg transition flex items-center gap-1.5">
              <Square size={12} fill="white" />
              Stop
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}

// ── Start-Formular (kein laufender Timer) ─────────────────────────────────────
function StartTimerCard({ onStart, lastEndTime }) {
  const [project, setProject] = useState({ projectId: null, projectName: '', contactName: '' })
  const [note, setNote] = useState('')
  const [billable, setBillable] = useState(true)
  const [starting, setStarting] = useState(false)
  // Startzeit: läuft mit („Jetzt"), bis der Benutzer sie manuell ändert
  const [startTime, setStartTime] = useState(nowTimeLocal())
  const [startDirty, setStartDirty] = useState(false)

  useEffect(() => {
    if (startDirty) return
    const id = setInterval(() => setStartTime(nowTimeLocal()), 10000)
    return () => clearInterval(id)
  }, [startDirty])

  const startedAtIso = () => localToIso(isoToLocalDateStr(), startTime)

  const handleStart = async () => {
    setStarting(true)
    try {
      await onStart({ project, note, billable, startedAt: startedAtIso() })
      setNote('')
      setProject({ projectId: null, projectName: '', contactName: '' })
      setStartDirty(false)
      setStartTime(nowTimeLocal())
    } finally {
      setStarting(false)
    }
  }

  // Für Anhänge ohne laufenden Timer: Zeitprojekt ist Pflicht, dann sofort starten.
  // Optional werden Dateien mitgegeben (Upload-Button): Diese werden NACH dem
  // Start in der stabilen Elternseite hochgeladen, damit das Re-Render (Timer
  // startet, Karte wird ausgetauscht) den Upload nicht abbricht.
  const ensureEntity = async (files = null) => {
    if (!project.projectId) {
      toast.error('Bitte zuerst ein Zeitprojekt wählen')
      return files ? false : null
    }
    try {
      const created = await onStart({ project, note, billable, startedAt: startedAtIso() }, files)
      return files ? true : (created?.id || null)
    } catch {
      return files ? false : null
    }
  }

  return (
    <div className="bg-surface rounded-2xl border border-gray-200 overflow-hidden mb-6">
      <div className="h-1 bg-gray-100" />
      <div className="p-5">
        <div className="flex flex-col sm:flex-row gap-4 sm:gap-6">
          <div className="hidden sm:block flex-shrink-0 pt-1">
            <div className="w-9 h-9 rounded-xl bg-gray-50 flex items-center justify-center">
              <Timer size={18} className="text-gray-400" />
            </div>
          </div>

          <div className="flex-1 min-w-0 grid grid-cols-1 gap-3">
            <div>
              <label className="block text-xs font-medium text-gray-500 mb-1">Zeitprojekt</label>
              <ZeitprojektSuche value={project} onChange={setProject} />
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-500 mb-1">Notiz</label>
              <input
                type="text"
                value={note}
                onChange={(e) => setNote(e.target.value)}
                placeholder="Was machst du gerade?"
                onKeyDown={(e) => e.key === 'Enter' && handleStart()}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-primary-500"
              />
            </div>
          </div>

          <div className="w-full sm:w-48 sm:flex-shrink-0 flex flex-col gap-3 justify-between">
            <div>
              <label className="block text-xs font-medium text-gray-500 mb-1">Startzeit</label>
              <TimeSuggestInput
                value={startTime}
                onChange={(t) => { setStartTime(t); setStartDirty(true) }}
                title="Startzeit manuell anpassen (z.B. wenn der Start verpasst wurde)"
                suggestions={[
                  { label: 'Letzte Endzeit', time: lastEndTime },
                  { label: 'Jetzt', time: nowTimeLocal() },
                ]}
              />
            </div>
            <div className="flex items-center gap-2">
              <input type="checkbox" id="start-billable" checked={billable} onChange={(e) => setBillable(e.target.checked)}
                className="w-4 h-4 rounded accent-primary-600" />
              <label htmlFor="start-billable" className="text-sm text-gray-700 cursor-pointer">Verrechenbar</label>
            </div>
            <button onClick={handleStart} disabled={starting}
              className="w-full py-2 bg-primary-600 hover:bg-primary-700 disabled:bg-primary-300 text-white font-medium rounded-lg transition flex items-center justify-center gap-2">
              {starting ? <Loader2 size={14} className="animate-spin" /> : <Play size={14} fill="white" />}
              Start
            </button>
          </div>
        </div>

        {/* Schnellzugriff: Anhänge */}
        <div className="mt-4 pt-4 border-t border-gray-100">
          <AttachmentQuickBar entityType="zeiterfassung" entityId={null} onEnsureEntity={ensureEntity} />
        </div>
      </div>
    </div>
  )
}

// ── Ring-Diagramm ─────────────────────────────────────────────────────────────
// Zeigt zwei Bögen: grün = verrechenbar, orange = nicht verrechenbar
function RingChart({ label, minutes, billableMinutes, targetMinutes }) {
  const r = 36, cx = 44, cy = 44, circ = 2 * Math.PI * r

  const nonBillable = Math.max(0, minutes - billableMinutes)
  const billablePct    = targetMinutes > 0 ? Math.min(1, billableMinutes / targetMinutes) : 0
  const nonBillablePct = targetMinutes > 0 ? Math.min(1 - billablePct, nonBillable / targetMinutes) : 0

  const billableLen    = billablePct * circ
  const nonBillableLen = nonBillablePct * circ
  // Oranger Bogen beginnt dort wo der grüne aufhört
  const orangeRotation = -90 + billablePct * 360

  return (
    <div className="flex flex-col items-center gap-1">
      <span className="text-xs text-gray-400 font-medium uppercase tracking-wide">{label}</span>
      <div className="relative">
        <svg width={88} height={88}>
          {/* Hintergrund-Ring (Ziel) */}
          <circle cx={cx} cy={cy} r={r} fill="none" stroke="#f3f4f6" strokeWidth={7} />

          {/* Oranger Bogen — nicht verrechenbar (beginnt nach dem grünen) */}
          {nonBillableLen > 0 && (
            <circle cx={cx} cy={cy} r={r} fill="none"
              stroke="#f97316" strokeWidth={7}
              strokeDasharray={`${nonBillableLen} ${circ - nonBillableLen}`}
              strokeLinecap="round"
              transform={`rotate(${orangeRotation} ${cx} ${cy})`} />
          )}

          {/* Grüner Bogen — verrechenbar (beginnt oben) */}
          {billableLen > 0 && (
            <circle cx={cx} cy={cy} r={r} fill="none"
              stroke="#16a34a" strokeWidth={7}
              strokeDasharray={`${billableLen} ${circ - billableLen}`}
              strokeLinecap="round"
              transform={`rotate(-90 ${cx} ${cy})`} />
          )}
        </svg>
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <span className="text-base font-bold text-gray-800">{fmtMinutes(minutes)}</span>
          <span className="text-[10px] text-gray-400">{fmtMinutes(targetMinutes)}</span>
        </div>
      </div>
    </div>
  )
}

// ── Nachtragen / Bearbeiten Modal ─────────────────────────────────────────────
// `initial`: optionale Vorbefüllung (z.B. KI-Vorschlag aus dem Sprach-Nachtragen)

// ── Zeiteintrag Zeile ─────────────────────────────────────────────────────────

function EntryRow({ entry, onEdit, onDelete, onRepeat, onSetStatus,
                    isAdmin, currentUserId, selected, onToggleSelect }) {
  const [confirmDelete, setConfirmDelete] = useState(false)
  const sameDay = entry.ended_at
    ? isoToDateLocal(entry.started_at) === isoToDateLocal(entry.ended_at) : true
  const mutable = (entry.status || 'veraenderbar') === 'veraenderbar'

  return (
    <tr className={`hover:bg-gray-50 transition cursor-pointer group ${selected ? 'bg-primary-50/40' : ''}`}
      onClick={() => onEdit(entry)}>
      <td className="py-3 pl-0 pr-0 w-1">
        <div className={`w-1 h-full min-h-[48px] rounded-sm ${entry.billable ? 'bg-green-400' : 'bg-orange-400'}`} />
      </td>
      <td className="px-3 py-3 w-8" onClick={(e) => e.stopPropagation()}>
        <input type="checkbox" checked={selected} onChange={() => onToggleSelect(entry.id)}
          className="rounded border-gray-300 text-primary-600 focus:ring-primary-500 cursor-pointer" />
      </td>
      <td className="px-4 py-3">
        <div className="text-sm font-medium text-gray-800">{entry.project_name || '—'}</div>
        {entry.contact_name && <div className="text-xs text-gray-400">{entry.contact_name}</div>}
        {entry.task_title && <div className="text-xs text-primary-600">↳ {entry.task_title}</div>}
      </td>
      <td className="px-4 py-3 whitespace-nowrap">
        <div className="text-sm text-gray-700">
          {fmtTime(entry.started_at)} → {entry.ended_at
            ? fmtTime(entry.ended_at)
            : <span className="text-green-600 font-medium">läuft…</span>}
        </div>
        <div className="text-xs text-gray-400">
          {fmtDate(entry.started_at)}
          {!sameDay && entry.ended_at && <> → {fmtDate(entry.ended_at)}</>}
        </div>
      </td>
      <td className="px-4 py-3 text-sm text-gray-500 text-center">{entry.pause_minutes || 0}</td>
      <td className="px-4 py-3 text-sm font-medium text-gray-800 text-center">
        {entry.is_running ? <RunningMin startedAt={entry.started_at} /> : fmtMinutes(entry.duration_minutes)}
      </td>
      <td className="px-4 py-3 text-sm text-gray-600 max-w-xs">
        <span className="line-clamp-2">{entry.note || '—'}</span>
      </td>
      <td className="px-4 py-3" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center gap-1 justify-end">
          {/* Aktionen fix sichtbar (kein Hover-Verhalten — wichtig für Touch-Geräte) */}
          <div className="flex items-center gap-1">
            <button onClick={() => onRepeat(entry)} title="Erneut starten"
              className="p-1.5 text-gray-400 hover:text-primary-600 hover:bg-primary-50 rounded-lg transition">
              <Play size={13} />
            </button>
            <span title={entry.billable ? 'Verrechenbar' : 'Nicht verrechenbar'}
              className={`p-1.5 rounded-lg ${entry.billable ? 'text-green-500' : 'text-gray-300'}`}>
              <Euro size={13} />
            </span>
            {mutable && (
              <button
                onClick={() => { if (confirmDelete) onDelete(entry); else setConfirmDelete(true) }}
                onBlur={() => setTimeout(() => setConfirmDelete(false), 200)}
                className={`p-1.5 rounded-lg transition ${confirmDelete ? 'bg-red-100 text-red-600' : 'text-gray-400 hover:text-red-500 hover:bg-red-50'}`}>
                <Trash2 size={13} />
              </button>
            )}
          </div>
          {/* Status-Schloss: immer sichtbar */}
          <StatusMenu entry={entry} isAdmin={isAdmin}
            currentUserId={currentUserId} onSetStatus={onSetStatus} />
        </div>
      </td>
    </tr>
  )
}

function RunningMin({ startedAt }) {
  const [min, setMin] = useState(() => Math.floor((Date.now() - new Date(startedAt)) / 60000))
  useEffect(() => {
    const id = setInterval(() => setMin(Math.floor((Date.now() - new Date(startedAt)) / 60000)), 10000)
    return () => clearInterval(id)
  }, [startedAt])
  return <span className="text-green-600 font-medium">{fmtMinutes(min)}</span>
}

// ── Hauptseite ────────────────────────────────────────────────────────────────
export default function ZeiterfassungPage() {
  const navigate = useNavigate()
  const { currentUser, isAdmin, hasRecht } = useAuth()
  // Alles, was einen Zeiteintrag entstehen lässt, setzt Schreibrecht voraus:
  // Timer starten, per Sprache nachtragen, von Hand nachtragen.
  // NICHT dazu gehören die Berichte (reine Auswertung, eigener Menüpunkt)
  // und die Custom-Felder (eigene Admin-Route).
  const darfErfassen = hasRecht('zeiterfassung', 'schreiben')
  const [selectedIds, setSelectedIds] = useState(new Set())
  const [running, setRunning] = useState(null)
  const [stats, setStats] = useState(null)
  const [entries, setEntries] = useState([])
  const [total, setTotal] = useState(0)
  const [loading, setLoading] = useState(true)
  const [page, setPage] = useState(1)
  const PAGE_SIZE = 50
  const [search, setSearch] = useState('')
  const [filterUserId, setFilterUserId] = useState('')
  const [users, setUsers] = useState([])
  const [modalEntry, setModalEntry] = useState(undefined)
  const [modalInitial, setModalInitial] = useState(null)  // KI-Vorbefüllung fürs Nachtragen
  const [voiceOpen, setVoiceOpen] = useState(false)
  const [importOpen, setImportOpen] = useState(false)

  // KI-Vorschlag aus der Sprachaufnahme → Nachtragen-Dialog vorbefüllt öffnen.
  // Datum/Uhrzeit werden normalisiert, damit die Eingabefelder (date/time)
  // sie sicher übernehmen — egal in welchem Format die KI antwortet.
  const handleVoiceResult = (v) => {
    setVoiceOpen(false)
    const today = isoToLocalDateStr()
    const normDate = (s) => {
      if (!s) return null
      let m = String(s).match(/^(\d{4})-(\d{1,2})-(\d{1,2})/)          // 2026-07-14
      if (m) return `${m[1]}-${m[2].padStart(2, '0')}-${m[3].padStart(2, '0')}`
      m = String(s).match(/^(\d{1,2})\.(\d{1,2})\.(\d{2,4})/)          // 14.07.2026 / 14.7.26
      if (m) {
        const y = m[3].length === 2 ? `20${m[3]}` : m[3]
        return `${y}-${m[2].padStart(2, '0')}-${m[1].padStart(2, '0')}`
      }
      return null
    }
    const normTime = (s) => {
      const m = String(s || '').match(/(\d{1,2}):(\d{2})/)             // 17:30(:00)
      return m ? `${m[1].padStart(2, '0')}:${m[2]}` : ''
    }
    setModalInitial({
      project: {
        projectId: v.project_id || null,
        projectName: v.project_name || '',
        contactName: v.contact_name || '',
      },
      startDate: normDate(v.date) || today,
      endDate: normDate(v.end_date) || normDate(v.date) || today,
      startTime: normTime(v.start_time),
      endTime: normTime(v.end_time),
      pause: Number(v.pause_minutes) || 0,
      note: v.note || '',
      billable: v.billable ?? true,
      warnings: v.warnings || [],
    })
    setModalEntry(null)
  }

  const loadAll = useCallback(async () => {
    try {
      const [runRes, statsRes, entriesRes] = await Promise.all([
        zeiterfassungApi.getRunning(),
        zeiterfassungApi.getStats(filterUserId || undefined),
        zeiterfassungApi.listEntries({ page, page_size: PAGE_SIZE, search: search || undefined, user_id: filterUserId || undefined }),
      ])
      setRunning(runRes.data)
      setStats(statsRes.data)
      setEntries(entriesRes.data.items)
      setTotal(entriesRes.data.total)
      setSelectedIds(new Set())   // Auswahl bei Neuladen zurücksetzen
    } catch { toast.error('Fehler beim Laden') }
    finally { setLoading(false) }
  }, [page, search, filterUserId])

  const toggleSelect = (id) => {
    setSelectedIds(prev => {
      const next = new Set(prev)
      next.has(id) ? next.delete(id) : next.add(id)
      return next
    })
  }

  const toggleSelectAll = () => {
    setSelectedIds(prev =>
      prev.size === entries.length ? new Set() : new Set(entries.map(e => e.id))
    )
  }

  const handleSetStatus = async (entry, status) => {
    try {
      await zeiterfassungApi.setEntryStatus(entry.id, status)
      toast.success(`Status auf „${ENTRY_STATUS[status]?.label || status}“ gesetzt`)
      loadAll()
    } catch (err) {
      const detail = err?.response?.data?.detail
      toast.error(typeof detail === 'string' ? detail : 'Statuswechsel fehlgeschlagen', { duration: 6000 })
    }
  }

  const handleBatchStatus = async (status) => {
    try {
      const res = await zeiterfassungApi.setEntriesStatusBatch([...selectedIds], status)
      const { changed, skipped, message } = res.data
      if (skipped?.length) toast(message, { icon: '⚠️', duration: 6000 })
      else toast.success(message)
      loadAll()
    } catch (err) {
      const detail = err?.response?.data?.detail
      toast.error(typeof detail === 'string' ? detail : 'Statuswechsel fehlgeschlagen')
    }
  }

  useEffect(() => { loadAll() }, [loadAll])
  useEffect(() => { usersApi.list().then(r => setUsers(r.data)).catch(() => {}) }, [])

  // Vom Dashboard-Widget per Sprach-KI hierher navigiert? → Dialog vorbefüllt öffnen
  const location = useLocation()
  useEffect(() => {
    if (location.state?.kiVorschlag) {
      handleVoiceResult(location.state.kiVorschlag)
      navigate(location.pathname, { replace: true, state: null })
    }
  }, [])  // bewusst nur beim ersten Rendern

  const handleStart = async ({ project, note, billable, startedAt }, files = null) => {
    try {
      const res = await zeiterfassungApi.startTimer({
        project_id: project.projectId || null,
        project_name: project.projectName || null,
        contact_id: null,
        contact_name: project.contactName || null,
        started_at: startedAt || nowIso(),
        note: note || null,
        billable,
        data: {},
      })
      setRunning(res.data)
      toast.success('Timer gestartet')

      // Optional: Dateien, die beim Start mitgegeben wurden, jetzt hochladen.
      // Läuft in der stabilen Seite -> kein Abbruch durch Re-Render.
      if (files && files.length && res.data?.id) {
        try {
          for (const file of Array.from(files)) {
            await datacenterApi.upload('zeiterfassung', res.data.id, file)
          }
          toast.success(files.length > 1 ? 'Dateien hochgeladen' : 'Datei hochgeladen')
        } catch {
          toast.error('Datei konnte nicht hochgeladen werden')
        }
      }

      loadAll()
      return res.data
    } catch (err) {
      toast.error(err.response?.data?.detail || 'Fehler beim Starten')
      throw err
    }
  }

  const handleStop = async ({ note, billable, project, pause }, endedAtIso = null) => {
    if (!running) return
    const endedAt = endedAtIso || nowIso()
    if (new Date(endedAt) <= new Date(running.started_at)) {
      toast.error('Endzeit muss nach der Startzeit liegen')
      return
    }
    try {
      // Felder erst aktualisieren, dann stoppen
      await zeiterfassungApi.updateEntry(running.id, {
        note: note || null,
        billable,
        project_id: project?.projectId || running.project_id,
        project_name: project?.projectName || running.project_name,
        contact_name: project?.contactName || running.contact_name,
        pause_minutes: Number(pause) || 0,
      })
      await zeiterfassungApi.stopTimer(running.id, { ended_at: endedAt, pause_minutes: Number(pause) || 0 })
      setRunning(null)
      toast.success('Timer gestoppt')
      loadAll()
    } catch (err) { toast.error('Fehler beim Stoppen') }
  }

  // Stoppen zu einer manuell gewählten Endzeit (heutiges Datum + Uhrzeit)
  const handleStopAt = async (timeStr, fields) => {
    if (!running || !timeStr) return
    await handleStop(fields, localToIso(isoToLocalDateStr(), timeStr))
  }

  const handlePause = async () => {
    if (!running) return
    try {
      await zeiterfassungApi.stopTimer(running.id, { ended_at: nowIso(), pause_minutes: 0 })
      setRunning(null)
      toast.success('Timer pausiert')
      loadAll()
    } catch { toast.error('Fehler') }
  }

  const handleSwitch = async () => {
    // Aktuellen Timer stoppen, dann neuen Start-Formular zeigen
    if (running) {
      try {
        await zeiterfassungApi.stopTimer(running.id, { ended_at: nowIso(), pause_minutes: 0 })
      } catch {}
    }
    setRunning(null)
    loadAll()
  }

  const handleDelete = async (entry) => {
    if (!entry) return
    try {
      if (entry.id === running?.id) setRunning(null)
      await zeiterfassungApi.deleteEntry(entry.id)
      toast.success('Zeiteintrag gelöscht')
      loadAll()
    } catch (err) {
      // 403 = fremder Eintrag, 409 = bereits abgerechnet — Meldung vom Backend zeigen
      const detail = err?.response?.data?.detail
      toast.error(typeof detail === 'string' ? detail : 'Löschen fehlgeschlagen', { duration: 6000 })
    }
  }

  const handleUpdate = async ({ note, billable, project, pause, startTime }) => {
    if (!running) return
    try {
      const payload = {
        note: note || null, billable,
        project_id: project?.projectId || null,
        project_name: project?.projectName || null,
        contact_name: project?.contactName || null,
        pause_minutes: Number(pause) || 0,
      }
      // Manuell angepasste Startzeit übernehmen (Datum des ursprünglichen Starts)
      if (startTime && startTime !== isoToTimeLocal(running.started_at)) {
        const neu = localToIso(isoToLocalDateStr(running.started_at), startTime)
        if (neu && new Date(neu) <= new Date()) payload.started_at = neu
      }
      await zeiterfassungApi.updateEntry(running.id, payload)
      // Lokalen Timer-Stand nachziehen, damit die laufende Anzeige stimmt
      if (payload.started_at) {
        setRunning(r => r ? { ...r, started_at: payload.started_at } : r)
      }
    } catch {}
  }

  const handleRepeat = async (entry) => {
    try {
      const res = await zeiterfassungApi.startTimer({
        project_id: entry.project_id, project_name: entry.project_name,
        contact_id: entry.contact_id, contact_name: entry.contact_name,
        task_id: entry.task_id || null,
        started_at: nowIso(), note: entry.note, billable: entry.billable, data: {},
      })
      setRunning(res.data)
      toast.success('Timer erneut gestartet')
      loadAll()
    } catch { toast.error('Fehler beim Starten') }
  }

  const totalPages = Math.ceil(total / PAGE_SIZE)

  return (
    <div className="">
      {/* Header */}
      <PageHeader icon={Clock} title="Zeiterfassung" subtitle="Projektzeiten erfassen und auswerten">
        <div className="flex items-center gap-2">
          {darfErfassen && (
            <button onClick={() => setVoiceOpen(true)} title="Projektzeit per Sprache nachtragen (KI)"
              className="relative flex items-center gap-1.5 px-2.5 sm:px-4 py-2.5 bg-primary-600 hover:bg-primary-700 text-white rounded-xl text-sm font-medium transition">
              <Mic size={16} />
              <Sparkles size={12} className="absolute top-1 right-1 sm:static sm:ml-0" />
              <span className="hidden lg:inline">Sprach-Eintrag</span>
            </button>
          )}
          <button onClick={() => navigate('/zeiterfassung/felder')} title="Custom-Felder"
            className="p-2.5 border border-gray-300 rounded-xl text-gray-500 hover:bg-gray-50 transition">
            <Settings2 size={16} />
          </button>
          {/* Die Berichte sind ein eigener Menüpunkt geworden (01.09.2026):
              Ein Dialog kann nur ein PDF ausgeben; die Auswertungen brauchen
              Platz für Filter, Summen und Trefferliste. Der Knopf bleibt als
              gewohnter Einstieg, führt aber jetzt auf die Seite. */}
          <button onClick={() => navigate('/zeiterfassung/berichte/projektzeiten')} title="Berichte und Auswertungen"
            className="flex items-center gap-2 px-2.5 sm:px-4 py-2.5 border border-gray-300 rounded-xl text-sm font-medium text-gray-700 hover:bg-gray-50 transition">
            <FileText size={16} />
            <span className="hidden sm:inline">Berichte</span>
          </button>
          {darfErfassen && (
            <button onClick={() => setImportOpen(true)} title="Projektzeiten aus einer Datei importieren (CSV, Excel, JSON, Kalender, PDF)"
              aria-label="Projektzeiten importieren"
              className="flex items-center gap-2 px-2.5 sm:px-4 py-2.5 border border-gray-300 rounded-xl text-sm font-medium text-gray-700 hover:bg-gray-50 transition">
              <Upload size={16} />
              <span className="hidden lg:inline">Import</span>
            </button>
          )}
          {darfErfassen && (
            <button onClick={() => setModalEntry(null)} title="Projektzeit nachtragen"
              className="hidden sm:flex items-center gap-2 px-2.5 sm:px-4 py-2.5 border border-gray-300 rounded-xl text-sm font-medium text-gray-700 hover:bg-gray-50 transition">
              <Plus size={16} />
              <span className="hidden sm:inline">Projektzeit nachtragen</span>
            </button>
          )}
        </div>
      </PageHeader>

      {/* Primäraktion am Handy: einheitlicher runder FAB unten rechts */}
      {darfErfassen && <Fab onClick={() => setModalEntry(null)} title="Projektzeit nachtragen" />}

      {/* Timer-Bereich */}
      {running ? (
        <RunningTimerCard
          entry={running}
          onStop={handleStop}
          onStopAt={handleStopAt}
          onPause={handlePause}
          onSwitch={handleSwitch}
          onDelete={() => handleDelete(running)}
          onUpdate={handleUpdate}
        />
      ) : darfErfassen ? (
        <StartTimerCard onStart={handleStart}
          lastEndTime={(() => {
            const last = entries.find(e => e.ended_at)
            return last ? isoToTimeLocal(last.ended_at) : null
          })()} />
      ) : null}

      {/* Statistik-Ringe */}
      {stats && (
        <div className="flex justify-around bg-surface rounded-2xl border border-gray-200 p-5 mb-6">
          <RingChart label="Heute" minutes={stats.today_minutes} billableMinutes={stats.today_billable_minutes ?? stats.today_minutes} targetMinutes={stats.today_target_minutes} />
          <RingChart label="Woche" minutes={stats.week_minutes} billableMinutes={stats.week_billable_minutes ?? stats.week_minutes} targetMinutes={stats.week_target_minutes} />
          <RingChart label="Monat" minutes={stats.month_minutes} billableMinutes={stats.month_billable_minutes ?? stats.month_minutes} targetMinutes={stats.month_target_minutes} />
        </div>
      )}

      {/* Filter */}
      <div className="flex gap-3 mb-4">
        <div className="relative flex-1">
          <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
          <input type="text" value={search} onChange={(e) => { setSearch(e.target.value); setPage(1) }}
            placeholder="In Einträgen suchen…"
            className="w-full pl-9 pr-4 py-2.5 border border-gray-300 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-primary-500 bg-surface" />
        </div>
        <select value={filterUserId} onChange={(e) => { setFilterUserId(e.target.value); setPage(1) }}
          className="px-4 py-2.5 border border-gray-300 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-primary-500 bg-surface">
          <option value="">Alle Benutzer</option>
          {users.map(u => <option key={u.id} value={u.id}>{u.full_name}</option>)}
        </select>
      </div>

      {/* Batch-Statusleiste (bei Auswahl) */}
      {selectedIds.size > 0 && (
        <div className="flex flex-wrap items-center gap-2 mb-3 bg-primary-50 border border-primary-200 rounded-xl px-4 py-2.5">
          <span className="text-sm font-medium text-primary-700">
            {selectedIds.size} ausgewählt
          </span>
          <span className="text-xs text-gray-400 mr-1">Status setzen:</span>
          {(isAdmin ? Object.keys(ENTRY_STATUS) : ['freigegeben']).map(s => {
            const cfg = ENTRY_STATUS[s]
            const Icon = cfg.icon
            return (
              <button key={s} onClick={() => handleBatchStatus(s)}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-medium border border-transparent transition ${cfg.badge} hover:brightness-95`}>
                <Icon size={12} /> {cfg.label}
              </button>
            )
          })}
          <button onClick={() => setSelectedIds(new Set())}
            className="ml-auto p-1.5 text-gray-400 hover:text-gray-600 rounded-lg" title="Auswahl aufheben">
            <X size={14} />
          </button>
        </div>
      )}

      {/* Tabelle */}
      <div className="bg-surface rounded-2xl border border-gray-200 overflow-hidden">
        {loading ? (
          <div className="flex items-center justify-center h-40">
            <Loader2 size={28} className="animate-spin text-primary-400" />
          </div>
        ) : entries.length === 0 ? (
          <div className="text-center py-16 text-gray-400">
            <Clock size={40} className="mx-auto mb-3 text-gray-200" />
            <p className="font-medium">{search ? 'Keine Einträge gefunden' : 'Noch keine Zeiteinträge'}</p>
            {!search && darfErfassen && (
              <button onClick={() => setModalEntry(null)} className="mt-3 text-primary-600 hover:underline text-sm">
                Ersten Eintrag nachtragen
              </button>
            )}
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-gray-100 bg-gray-50">
                  <th className="w-1 p-0" />
                  <th className="px-3 py-3 w-8">
                    <input type="checkbox"
                      checked={entries.length > 0 && selectedIds.size === entries.length}
                      onChange={toggleSelectAll}
                      className="rounded border-gray-300 text-primary-600 focus:ring-primary-500 cursor-pointer"
                      title="Alle auf dieser Seite auswählen" />
                  </th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase tracking-wide">Projekt</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase tracking-wide">Zeit</th>
                  <th className="px-4 py-3 text-center text-xs font-semibold text-gray-500 uppercase tracking-wide">Pause</th>
                  <th className="px-4 py-3 text-center text-xs font-semibold text-gray-500 uppercase tracking-wide">Dauer</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase tracking-wide">Notiz</th>
                  <th className="px-4 py-3 w-24"></th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-50">
                {entries.map(entry => (
                  <EntryRow key={entry.id} entry={entry}
                    onEdit={(e) => setModalEntry(e)}
                    onDelete={handleDelete}
                    onRepeat={handleRepeat}
                    onSetStatus={handleSetStatus}
                    isAdmin={isAdmin}
                    currentUserId={currentUser?.id}
                    selected={selectedIds.has(entry.id)}
                    onToggleSelect={toggleSelect}
                  />
                ))}
              </tbody>
            </table>
          </div>
        )}
        {totalPages > 1 && (
          <div className="flex items-center justify-between px-4 py-3 border-t border-gray-100">
            <span className="text-sm text-gray-500">
              {(page - 1) * PAGE_SIZE + 1}–{Math.min(page * PAGE_SIZE, total)} von {total}
            </span>
            <div className="flex gap-2">
              <button onClick={() => setPage(p => p - 1)} disabled={page === 1}
                className="p-2 rounded-lg border border-gray-200 text-gray-500 disabled:opacity-40 hover:bg-gray-50 transition">
                <ChevronLeft size={16} />
              </button>
              <button onClick={() => setPage(p => p + 1)} disabled={page === totalPages}
                className="p-2 rounded-lg border border-gray-200 text-gray-500 disabled:opacity-40 hover:bg-gray-50 transition">
                <ChevronRight size={16} />
              </button>
            </div>
          </div>
        )}
      </div>

      {modalEntry !== undefined && (
        <ProjektzeitModal entry={modalEntry} initial={modalInitial}
          onClose={() => { setModalEntry(undefined); setModalInitial(null) }}
          onSaved={() => { setModalEntry(undefined); setModalInitial(null); loadAll() }} />
      )}

      {voiceOpen && (
        <VoiceEntryDialog onClose={() => setVoiceOpen(false)} onResult={handleVoiceResult} />
      )}

      {importOpen && (
        <ZeitenImport
          onClose={() => setImportOpen(false)}
          onImported={(anzahl) => {
            setImportOpen(false)
            toast.success(`${anzahl} Projektzeiten importiert`)
            loadAll()
          }} />
      )}

    </div>
  )
}
