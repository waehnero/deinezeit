import React, { Suspense } from 'react'
import ReactDOM from 'react-dom/client'
import { BrowserRouter, Routes, Route, Navigate } from 'react-router'
import { Toaster } from 'react-hot-toast'
import { Loader2 } from 'lucide-react'
import './i18n'
import './index.css'
import { initPrefs } from './utils/anzeige'
import { lazySeite } from './utils/lazySeite'

import { SettingsProvider } from './contexts/SettingsContext'
import { AuthProvider, useAuth } from './contexts/AuthContext'
import LoginPage from './pages/LoginPage'
import SetupPage from './pages/SetupPage'
import ForgotPasswordPage from './pages/ForgotPasswordPage'
import ResetPasswordPage from './pages/ResetPasswordPage'
// Seiten hinter der Anmeldung werden erst beim Aufruf geladen (K-26b, siehe utils/lazySeite.js).
const DashboardPage              = lazySeite(() => import('./pages/DashboardPage'))
const MasterDataOverview         = lazySeite(() => import('./pages/MasterDataOverview'))
const MasterDataDetail           = lazySeite(() => import('./pages/MasterDataDetail'))
const ProfilePage                = lazySeite(() => import('./pages/ProfilePage'))
const UserManagementPage         = lazySeite(() => import('./pages/UserManagementPage'))
const GruppenPage                = lazySeite(() => import('./pages/GruppenPage'))
const ZeiterfassungPage          = lazySeite(() => import('./pages/ZeiterfassungPage'))
const ZeiterfassungFelder        = lazySeite(() => import('./pages/ZeiterfassungFelder'))
const ZeitprojektePage           = lazySeite(() => import('./pages/ZeitprojektePage'))
const BerichtProjektzeitenPage   = lazySeite(() => import('./pages/BerichtProjektzeitenPage'))
const BerichtAuswertungPage      = lazySeite(() => import('./pages/BerichtAuswertungPage'))
const SettingsPage               = lazySeite(() => import('./pages/SettingsPage'))
const DatacenterPage             = lazySeite(() => import('./pages/DatacenterPage'))
const InvoicePage                = lazySeite(() => import('./pages/InvoicePage'))
const InvoiceFormPage            = lazySeite(() => import('./pages/InvoiceFormPage'))
const InvoiceBookPage            = lazySeite(() => import('./pages/InvoiceBookPage'))
const OpenItemsPage              = lazySeite(() => import('./pages/OpenItemsPage'))
const MonatsabschlussPage        = lazySeite(() => import('./pages/MonatsabschlussPage'))
const MahnlaufPage               = lazySeite(() => import('./pages/MahnlaufPage'))
const AuswertungenPage           = lazySeite(() => import('./pages/AuswertungenPage'))
const BuchhaltungPage            = lazySeite(() => import('./pages/BuchhaltungPage'))
const KontenplanPage             = lazySeite(() => import('./pages/KontenplanPage'))
const ArtikelgruppenPage         = lazySeite(() => import('./pages/ArtikelgruppenPage'))
const EingangsrechnungenPage     = lazySeite(() => import('./pages/EingangsrechnungenPage'))
const ProjektplanPage            = lazySeite(() => import('./pages/ProjektplanPage'))
const ProjektplanDetailPage      = lazySeite(() => import('./pages/ProjektplanDetailPage'))
const ProjekteEinstellungen      = lazySeite(() => import('./pages/ProjekteEinstellungen'))
const AufgabenPage               = lazySeite(() => import('./pages/AufgabenPage'))
const PosteckePage               = lazySeite(() => import('./pages/PosteckePage'))
import Layout, { homeRoute } from './components/Layout'
import ErrorBoundary from './components/ErrorBoundary'

const AuthSpinner = () => (
  <div className="flex items-center justify-center h-64">
    <Loader2 size={28} className="animate-spin text-primary-400" />
  </div>
)

/**
 * Zugang nur für angemeldete Benutzer.
 *
 * Vorher wurde geprüft, ob ein Token in localStorage liegt. Das geht nicht
 * mehr — der Access-Token lebt im Arbeitsspeicher und ist nach jedem Neuladen
 * weg, während die Sitzung im httpOnly-Cookie weiterbesteht. Ohne das Warten
 * auf `loadingAuth` würde jeder Seiten-Neuaufbau (F5, PWA-Start, Öffnen eines
 * Lesezeichens) fälschlich auf die Anmeldemaske führen, obwohl der Benutzer
 * angemeldet ist.
 */
function ProtectedRoute({ children }) {
  const { istAngemeldet, loadingAuth } = useAuth()
  if (loadingAuth) return <AuthSpinner />
  return istAngemeldet ? children : <Navigate to="/login" replace />
}

/** Nur für Admins — zeigt Ladeindikator bis Auth geklärt, leitet sonst zur Startseite */
function AdminRoute({ children }) {
  const { isAdmin, loadingAuth, hasModule } = useAuth()
  if (loadingAuth) return <AuthSpinner />
  return isAdmin ? children : <Navigate to={homeRoute(hasModule)} replace />
}

/** Nur mit freigeschaltetem Modul — leitet sonst zur Startseite des Benutzers */
function ModuleRoute({ module, children }) {
  const { loadingAuth, hasModule } = useAuth()
  if (loadingAuth) return <AuthSpinner />
  return hasModule(module) ? children : <Navigate to={homeRoute(hasModule)} replace />
}

/** Startseite: Dashboard, sonst erstes freigeschaltetes Modul */
function HomeRedirect() {
  const { loadingAuth, hasModule } = useAuth()
  if (loadingAuth) return <AuthSpinner />
  return <Navigate to={homeRoute(hasModule)} replace />
}

function App() {
  return (
    <BrowserRouter>
      <SettingsProvider>
        <AuthProvider>
          {/* Safe-Area-Abstand: am iPhone erscheinen Toasts sonst unter Notch/Kamera */}
          <Toaster position="top-right" toastOptions={{ duration: 4000 }}
            containerStyle={{ top: 'calc(env(safe-area-inset-top, 0px) + 16px)' }} />
          {/* Render-Fehler einer Seite zeigen eine Meldung statt einer weißen
              Seite (Audit UX-001); Anbieter darüber bleiben unberührt. */}
          <ErrorBoundary>
          <Routes>
            <Route path="/setup" element={<SetupPage />} />
            <Route path="/login" element={<LoginPage />} />
            <Route path="/forgot-password" element={<ForgotPasswordPage />} />
            {/* Ziel des Links aus der E-Mail. Der Pfad steht auch im Backend
                (api/auth.py, password_forgot) — beide müssen zusammenpassen. */}
            <Route path="/passwort-neu" element={<ResetPasswordPage />} />
            <Route
              path="/*"
              element={
                <ProtectedRoute>
                  <Layout>
                    {/* Ladeanzeige, während die Datei einer Seite nachgeladen wird (K-26b) */}
                    <Suspense fallback={<AuthSpinner />}>
                    <Routes>
                      <Route path="/dashboard"            element={<ModuleRoute module="dashboard"><DashboardPage /></ModuleRoute>} />
                      <Route path="/masterdata"           element={<ModuleRoute module="stammdaten"><MasterDataOverview /></ModuleRoute>} />
                      {/* MUSS vor /masterdata/:slug stehen — sonst fängt der
                          Platzhalter „artikelgruppen" ab und sucht einen
                          Stammdaten-Typ, den es nicht gibt. */}
                      <Route path="/masterdata/artikelgruppen" element={<ModuleRoute module="stammdaten"><ArtikelgruppenPage /></ModuleRoute>} />
                      {/* Zeitprojekte hießen früher „projekte" (bis Migration
                          0038) bzw. „projektzeiten" (bis 0059) und lagen in
                          den Stammdaten. Beide Pfade stecken in Lesezeichen
                          und in PWA-Verknüpfungen — sie führen jetzt an die
                          neue Stelle statt in einen leeren Stammdaten-Typ.
                          MUSS vor /masterdata/:slug stehen. */}
                      <Route path="/masterdata/zeitprojekte"  element={<Navigate to="/zeiterfassung/zeitprojekte" replace />} />
                      <Route path="/masterdata/projektzeiten" element={<Navigate to="/zeiterfassung/zeitprojekte" replace />} />
                      <Route path="/masterdata/projekte"      element={<Navigate to="/zeiterfassung/zeitprojekte" replace />} />
                      <Route path="/masterdata/:slug"     element={<ModuleRoute module="stammdaten"><MasterDataDetail /></ModuleRoute>} />
                      <Route path="/profile"              element={<ProfilePage />} />
                      <Route path="/users"                element={<UserManagementPage />} />
                      {/* Rechtegruppen: nur Admin — wer Rechte verwaltet, kann sich selbst alles zuteilen */}
                      <Route path="/users/gruppen"        element={<AdminRoute><GruppenPage /></AdminRoute>} />
                      <Route path="/zeiterfassung"        element={<ModuleRoute module="zeiterfassung"><ZeiterfassungPage /></ModuleRoute>} />
                      {/* Zeitprojekte: aus den Stammdaten ins Zeiterfassungs-
                          Modul gezogen (01.09.2026). Die Seite zeigt weiterhin
                          den Stammdaten-Baukasten, hängt aber am Modul
                          Zeiterfassung — dort wird auch gebucht. */}
                      <Route path="/zeiterfassung/zeitprojekte" element={<ModuleRoute module="zeiterfassung"><ZeitprojektePage /></ModuleRoute>} />
                      {/* Berichte: früher ein Dialog auf der Erfassungsseite */}
                      <Route path="/zeiterfassung/berichte"                element={<Navigate to="/zeiterfassung/berichte/projektzeiten" replace />} />
                      <Route path="/zeiterfassung/berichte/projektzeiten"  element={<ModuleRoute module="zeiterfassung"><BerichtProjektzeitenPage /></ModuleRoute>} />
                      <Route path="/zeiterfassung/berichte/benutzer"       element={<ModuleRoute module="zeiterfassung"><BerichtAuswertungPage gruppierung="benutzer" /></ModuleRoute>} />
                      <Route path="/zeiterfassung/berichte/zeitprojekte"   element={<ModuleRoute module="zeiterfassung"><BerichtAuswertungPage gruppierung="zeitprojekt" /></ModuleRoute>} />
                      <Route path="/aufgaben"             element={<ModuleRoute module="aufgaben"><AufgabenPage /></ModuleRoute>} />
                      <Route path="/postecke"             element={<ModuleRoute module="postecke"><PosteckePage /></ModuleRoute>} />
                      <Route path="/projekte"             element={<ModuleRoute module="projekte"><ProjektplanPage /></ModuleRoute>} />
                      <Route path="/projekte/einstellungen" element={<AdminRoute><ProjekteEinstellungen /></AdminRoute>} />
                      <Route path="/projekte/:id"         element={<ModuleRoute module="projekte"><ProjektplanDetailPage /></ModuleRoute>} />
                      <Route path="/datacenter"           element={<ModuleRoute module="datacenter"><DatacenterPage /></ModuleRoute>} />
                      {/* Rechnungsmodul */}
                      <Route path="/invoices"            element={<ModuleRoute module="verkauf"><InvoicePage /></ModuleRoute>} />
                      <Route path="/invoices/new"        element={<ModuleRoute module="verkauf"><InvoiceFormPage /></ModuleRoute>} />
                      {/* Die Auswertungen sind in den Bereich Buchhaltung
                          gezogen. Die alten Pfade bleiben als Weiterleitung
                          bestehen — sie stecken in Lesezeichen und in
                          PWA-Verknüpfungen auf dem Startbildschirm. */}
                      <Route path="/invoices/book"       element={<Navigate to="/buchhaltung/verkaufsbuch" replace />} />
                      <Route path="/invoices/open-items" element={<Navigate to="/buchhaltung/offene-posten" replace />} />
                      <Route path="/invoices/abschluss"  element={<Navigate to="/buchhaltung/abschluss" replace />} />
                      <Route path="/invoices/mahnlauf"   element={<Navigate to="/buchhaltung/mahnlauf" replace />} />

                      {/* Bereich Buchhaltung */}
                      <Route path="/buchhaltung"                element={<ModuleRoute module="buchhaltung"><BuchhaltungPage /></ModuleRoute>} />
                      <Route path="/buchhaltung/offene-posten"   element={<ModuleRoute module="buchhaltung"><OpenItemsPage /></ModuleRoute>} />
                      <Route path="/buchhaltung/mahnlauf"        element={<ModuleRoute module="buchhaltung"><MahnlaufPage /></ModuleRoute>} />
                      <Route path="/buchhaltung/auswertungen"   element={<ModuleRoute module="buchhaltung"><AuswertungenPage /></ModuleRoute>} />
                      <Route path="/buchhaltung/verkaufsbuch"    element={<ModuleRoute module="buchhaltung"><InvoiceBookPage /></ModuleRoute>} />
                      <Route path="/buchhaltung/abschluss"       element={<ModuleRoute module="buchhaltung"><MonatsabschlussPage /></ModuleRoute>} />
                      <Route path="/buchhaltung/konten"          element={<ModuleRoute module="buchhaltung"><KontenplanPage /></ModuleRoute>} />
                      <Route path="/buchhaltung/eingangsrechnungen" element={<ModuleRoute module="buchhaltung"><EingangsrechnungenPage /></ModuleRoute>} />
                      <Route path="/invoices/:id"        element={<ModuleRoute module="verkauf"><InvoiceFormPage /></ModuleRoute>} />
                      <Route path="/invoices/:id/edit"   element={<ModuleRoute module="verkauf"><InvoiceFormPage /></ModuleRoute>} />
                      {/* Feldverwaltung & Einstellungen: nur Admin */}
                      <Route path="/zeiterfassung/felder" element={<AdminRoute><ZeiterfassungFelder /></AdminRoute>} />
                      <Route path="/settings"             element={<AdminRoute><SettingsPage /></AdminRoute>} />
                      <Route path="*"                     element={<HomeRedirect />} />
                    </Routes>
                    </Suspense>
                  </Layout>
                </ProtectedRoute>
              }
            />
            <Route path="/" element={<Navigate to="/dashboard" replace />} />
            {/* Hinweis: /dashboard leitet über ModuleRoute ggf. weiter zur
                Startseite des Benutzers (erstes freigeschaltetes Modul) */}
          </Routes>
          </ErrorBoundary>
        </AuthProvider>
      </SettingsProvider>
    </BrowserRouter>
  )
}

// Anzeige-Präferenzen (Dunkelmodus, Barrierefreiheit) vor dem ersten Render anwenden
initPrefs()

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
)
