# Changelog

## [2.1.1] – 2026-10-14 – Schnellere Verbindung

### Aktualisierungen
- Die Anwendung nutzt jetzt HTTP/2: Der Browser lädt alle Teile einer Seite gleichzeitig über eine Verbindung. Seiten öffnen sich dadurch spürbar flotter, besonders am Handy im mobilen Netz.

---

## [2.1.0] – 2026-09-18 – Zeiten aus anderen Programmen übernehmen

### Neu
- Zeiterfassung: Neuer Knopf „Import“. Projektzeiten aus anderen Programmen lassen sich aus CSV, Excel, JSON (z.B. Toggl, Clockify) und Kalenderdateien (.ics) übernehmen. Du ordnest die Spalten zu, siehst einen Prüfbericht mit Stundensumme und entscheidest dann erst über den Import.
- Stundenzettel als PDF — auch gescannt — liest die KI in eine Tabelle. Vor dem Senden wirst du gefragt, weil die Datei dafür an den KI-Anbieter geht. Die gelesene Tabelle kannst du prüfen, als CSV herunterladen und korrigieren.

### Aktualisierungen
- Beim Import wird nichts erraten: Zeilen ohne Beginn und Ende, unklare Datumsangaben oder unbekannte Zeitprojekte werden mit Begründung aufgelistet. Eine Datei zweimal einzuspielen verdoppelt keine Stunden.
- Administratoren können Zeiten für andere Personen importieren — über eine Spalte mit Name oder E-Mail oder für eine Person je Datei. Alle anderen importieren nur für sich selbst.

---

## [2.0.5] – 2026-09-11 – Nachvollziehbare Logs

### Aktualisierungen
- Jede Anfrage bekommt eine Kennung, die in allen Logzeilen des Servers und in der Antwort (X-Request-ID) steht. Damit lassen sich Fehlermeldungen einer bestimmten Aktion zuordnen — auch wenn mehrere Personen gleichzeitig arbeiten.
- Fehlerketten im Serverlog sind vollständig (Ursache bleibt erhalten); scheiterndes Aufräumen alter Backups und fehlgeschlagenes Löschen im Cloud-Speicher werden protokolliert statt verschluckt.
- Installationsanleitung: Hinweis, wie sich das Installationsskript vor dem Ausführen prüfen lässt.

---

## [2.0.4] – 2026-09-09 – Schneller starten

### Aktualisierungen
- Die Anwendung lädt beim Anmelden nur noch, was du gerade brauchst — jede Seite holt sich ihre Daten erst beim Aufruf. Der erste Start ist damit deutlich kleiner (rund 270 statt 1.770 KB).
- Anmeldung, Profil, Benutzer- und Feldverwaltung: Eingabefelder sind für Passwort-Manager und Bildschirmleser sauber benannt; Schließen- und Symbol-Schaltflächen haben eine Beschriftung.
- Beim Anlegen eines Angebots heißt die Überschrift jetzt „Neues Angebot“, beim Lieferschein „Neuer Lieferschein“.

---

## [2.0.3] – 2026-09-09 – Ordnung im Werkzeugkasten

### Aktualisierungen
- Die Hilfsskripte für die lokale Entwicklung unter Windows liegen jetzt gesammelt im Ordner scripts/windows. Für den laufenden Betrieb und die Backups ändert sich nichts.

---

## [2.0.2] – 2026-09-08 – Aufräumen im Verkaufsmodul

### Aktualisierungen
- Der Programmcode des Verkaufsmoduls (Belege, Zahlungen, Mahnwesen, Buchhaltung, Versand) ist intern neu geordnet. Für dich ändert sich nichts — alle Funktionen und Adressen bleiben gleich.

---

## [2.0.1] – 2026-09-08 – Technik-Update im Hintergrund

### Aktualisierungen
- Die Bausteine der Oberfläche wurden auf den aktuellen Stand gebracht (Seitenwechsel, Texteditor, Build-Werkzeug). Es gibt keine bekannten Sicherheitslücken mehr in den verwendeten Paketen.
- Texteditor: Fett, Kursiv, Unterstrichen, Ausrichtung und Listen funktionieren wie bisher.

---

## [2.0.0] – 2026-09-04 – Release 2.0 – Software-Audit abgeschlossen

### Neu
- DeineZeit 2.0: Ergebnis eines vollständigen Sicherheits- und Qualitäts-Audits (02.–04.09.2026). Alle 45 Befunde wurden bewertet, 37 behoben, die übrigen sind bewusst dokumentiert — kein offener Punkt betrifft Sicherheit oder Datenintegrität.

### Aktualisierungen
- Sicherheit: Sitzungsübernahme über hochgeladene SVG-Dateien geschlossen, Konfigurations-Geheimnisse liegen verschlüsselt in der Datenbank, Content-Security-Policy aktiv, Erstinstallation nur mit Einrichtungs-Token, Web-Framework auf aktuellem Stand.
- Datensicherheit: Backups überleben den Deploy und enthalten jetzt auch den Dateispeicher (Beleg-PDFs, Anhänge); Wiederherstellungsanleitung liegt bei. Benutzer mit gebuchten Zeiten können nicht mehr gelöscht werden.
- Betrieb: Der Server hat keinen Zugriff mehr auf Docker — Aktualisierungen kommen ausschließlich über den geprüften Deploy nach grünen Tests. Mehrere Arbeitsprozesse sind möglich, ohne dass Hintergrundjobs doppelt laufen.
- Stabilität: PDF-Erzeugung, Mailversand und Berichte halten den Server nicht mehr für alle anderen an. Belegnummern sind auch bei gleichzeitigem Ausstellen eindeutig. Kalenderdaten rechnen in Ortszeit.
- Qualität: 961 automatische Backend-Tests (vorher 873) und erstmals Frontend-Tests; Datenbankschema und Migrationen werden laufend auf Übereinstimmung geprüft.
- Behoben: Teilaufgaben im Projektplan ließen sich nicht anlegen (Fehler 500); Zeiteinträge können jetzt einer Projektplan-Aufgabe zugeordnet werden.

---

## [1.12.84] – 2026-09-04 – Audit Bündel H

### Neu
- Zeiteinträge können einer Projektplan-Aufgabe zugeordnet werden (Auswahl beim Nachtragen)

### Aktualisierungen
- Projektplan: gebuchte Zeiten je Aufgabe werden angezeigt; Aufgaben mit Zeiten sind vor dem Löschen geschützt

---

## [1.12.82] – 2026-09-04 – Audit Bündel G

### Aktualisierungen
- In-App-Update entfernt: Aktualisierungen kommen jetzt ausschließlich über den geprüften Deploy nach grünen Tests
- Sicherheit: Das Backend hat keinen Zugriff mehr auf Docker; die Content-Security-Policy ist aktiv
- Projektplan: Teilaufgaben ließen sich nicht anlegen (Fehler 500) — behoben
- Betrieb: Hintergrundjobs laufen auch mit mehreren Arbeitsprozessen nur einmal; MinIO-Version fest gepinnt

---

## [1.12.81] – 2026-09-04 – Audit Bündel F

### Aktualisierungen
- Ein Anzeigefehler in der Oberfläche führt nicht mehr zur weißen Seite, sondern zu einer Meldung mit Neuladen-Knopf
- Downloads mit Umlauten im Dateinamen kommen in allen Browsern richtig an
- Technische Fehlerdetails werden nicht mehr an den Browser durchgereicht, sondern im Serverlog festgehalten
- Backup-Ping der Windows-Skripte ist abgesichert; Installationsskript übergibt das Admin-Passwort sicher
- Dokumentation berichtigt (Status, Anleitung lokal); Sprachwahl ausgeblendet, da nur Deutsch gepflegt ist

---

## [1.12.80] – 2026-09-03 – Audit Bündel D und E

### Aktualisierungen
- Backup enthält jetzt auch den Dateispeicher (Beleg-PDFs, Anhänge, Fotos) samt Inhaltsverzeichnis; neue Wiederherstellungsanleitung
- Deploy läuft erst nach erfolgreicher Prüfung und bricht ab, wenn der Server danach nicht antwortet
- Web-Framework (FastAPI/Starlette) und PDF-Erzeugung (WeasyPrint) auf aktuellen Stand gebracht
- Erstinstallation nur noch mit Einrichtungs-Token aus der Installation
- Kalenderdaten, Berichte und Fälligkeiten rechnen in Ortszeit (Europe/Vienna) statt UTC
- Excel-Import auf eine gepflegte Bibliothek umgestellt (nur noch .xlsx)
- Content-Security-Policy im Beobachtungsmodus eingeführt

---

## [1.12.79] – 2026-09-03 – Audit Bündel C

### Aktualisierungen
- Belegnummern sind auch dann eindeutig, wenn zwei Personen gleichzeitig ausstellen
- PDF-Erzeugung, Mailversand und lange Berichte halten den Server nicht mehr für alle anderen Benutzer an
- Versions- und Änderungsabfrage nur noch angemeldet und zwischengespeichert

---

## [1.12.78] – 2026-09-03 – Audit Bündel B

### Aktualisierungen
- Benutzer mit Zeiteinträgen oder Stammdaten können nicht mehr gelöscht werden — stattdessen deaktivieren (vorher gingen die Zeiten verloren)
- Datenbankschema und Migrationen abgeglichen; ein Test wacht ab jetzt über die Übereinstimmung

---

## [1.12.77] – 2026-09-03 – Audit Bündel A

### Aktualisierungen
- Sicherheitslücke geschlossen: Hochgeladene SVG-Dateien werden nicht mehr im Browser ausgeführt
- Konfigurations-Geheimnisse (SMTP, Cloud, KI) liegen verschlüsselt in der Datenbank
- Ohne Anmeldung sind nur noch Logo und Farben sichtbar, keine Konfiguration
- XML- und PDF-Download im Belegformular funktionieren wieder
- Testreihe in der Pipeline von über einer Stunde auf wenige Minuten beschleunigt

---

## [1.12.76] – 2026-09-02 – Zeiterfassung zeitprojekte

### Aktualisierungen
- (Release-Notes ergänzen)

---

## [1.12.75] – 2026-09-01 – Zeitprojekte und Berichte in der Zeiterfassung

### Neu
- Die Zeitprojekte sind von den Stammdaten in das Menü der Zeiterfassung gewandert — dort, wo die Zeiten darauf gebucht werden. Alte Lesezeichen werden automatisch weitergeleitet.
- Neuer Menüpunkt „Berichte“ mit drei Auswertungen: Projektzeiten (Liste mit Filtern, Rundung und PDF-Druck), Benutzer-Auswertung und Zeitprojekt-Auswertung inklusive Stand der Stundenkonten.
- In den Auswertungen führt ein Klick auf eine Zeile direkt zu den einzelnen Zeiteinträgen dahinter.
- Zeiteinträge lassen sich direkt im Bericht „Projektzeiten“ bearbeiten, löschen und im Status ändern — ohne Umweg über die Erfassungsliste.
- Der Projektzeitbericht hat ein neues Aussehen: Kennzahlen im Kopf, Balken je Zeile, saubere Seitenumbrüche — und die Vorschau zeigt endlich das Blatt statt einer fensterbreiten Tabelle.

### Aktualisierungen
- Der Bericht zeigt die Trefferliste jetzt vor dem Druck an — man sieht, was im PDF landet, bevor man es erzeugt.
- Wer nur die eigenen Zeiten sehen darf, bekommt auch in Bericht und Auswertung nur die eigenen Einträge.
- Einheitliche Begriffe im ganzen Modul: „Zeitprojekt“ ist der Stammsatz, „Projektzeit“ der einzelne Zeiteintrag.
- Zeitraumfilter rechnen jetzt in Ortszeit: Ein Eintrag kurz nach Mitternacht erschien bisher im Vormonat.

---

## [1.12.74] – 2026-08-31 – Steuerfall matrix

### Aktualisierungen
- (Release-Notes ergänzen)

---

## [1.12.73] – 2026-08-31 – Aufwandskonto am Lieferanten

### Neu
- Am Kontakt lässt sich ein Standard-Aufwandskonto hinterlegen; neue Eingangsrechnungen übernehmen es automatisch.

### Aktualisierungen
- Das Aufwandskonto in der Eingangsrechnung wird jetzt aus dem Kontenplan gewählt statt von Hand getippt.

---

## [1.12.72] – 2026-08-30 – Artikelstamm mit Gruppen und automatischer Nummer

### Neu
- Artikelgruppen mit eigenem Nummernkreis: Artikelnummern werden automatisch vergeben (z.B. DL-0001).
- Erlös- und Aufwandskonto lassen sich je Artikelgruppe hinterlegen und gelten für alle Artikel der Gruppe.
- Artikelstamm um Einheit, USt-Satz, Einkaufsdaten, Lagerangaben und ein Artikelbild erweitert.
- Auswahllisten von Feldern — etwa die Mengeneinheiten — lassen sich jetzt jederzeit bearbeiten.

### Aktualisierungen
- Beim Einfügen eines Artikels in einen Beleg werden Konto, Steuersatz und Einheit automatisch übernommen.
- Fehler behoben: Beim Umbenennen eines Auswahlfeldes ging dessen Auswahlliste verloren.

---

## [1.12.71] – 2026-08-29 – Pipeline schneller

### Aktualisierungen
- (Release-Notes ergänzen)

---

## [1.12.70] – 2026-08-29 – Schnellere Auslieferung von Updates

### Aktualisierungen
- Interne Verbesserung: Aktualisierungen werden schneller eingespielt und geprüft.

---

## [1.12.69] – 2026-08-28 – Ssl automatik

### Aktualisierungen
- (Release-Notes ergänzen)

---

## [1.12.68] – 2026-08-27 – Ssl automatik

### Aktualisierungen
- (Release-Notes ergänzen)

---

## [1.12.67] – 2026-08-21 – System lasttest sitzungen

### Aktualisierungen
- (Release-Notes ergänzen)

---

## [1.12.66] – 2026-08-20 – Angemeldete Benutzer sehen und abmelden

### Neu
- Unter Einstellungen → System zeigt eine neue Übersicht alle angemeldeten Geräte mit Name, Adresse und letzter Aktivität. Vergessene Anmeldungen fallen sofort auf und lassen sich einzeln oder für einen Benutzer gesammelt beenden.

### Aktualisierungen
- Neuer Reiter „Lasttest“ mit einer Schritt-für-Schritt-Anleitung, wie sich die Belastbarkeit der eigenen Installation messen lässt — getrennt für Server und lokale Umgebung.

---

## [1.12.65] – 2026-08-20 – Lasttest

### Aktualisierungen
- (Release-Notes ergänzen)

---

## [1.12.64] – 2026-08-19 – Stammdaten aus Excel und CSV importieren

### Neu
- Der Import-Assistent liest jetzt auch Excel-Dateien, prüft die Datei vor dem Schreiben und zeigt jede beanstandete Zeile mit Grund an. Über ein Abgleichsfeld (z.B. Kundennummer) werden vorhandene Datensätze aktualisiert statt ein zweites Mal angelegt.

### Aktualisierungen
- Datum und Zahlen werden in der gewohnten Schreibweise verstanden (31.12.2026, 1.234,56). Beim Aktualisieren bleiben Felder, die in der Datei fehlen, unverändert erhalten.

---

## [1.12.63] – 2026-08-18 – Rechte wirken jetzt in der ganzen Oberfläche

### Neu
- Knöpfe zum Anlegen, Ändern und Löschen erscheinen nur noch dort, wo die Gruppe des Benutzers das Recht dazu vorsieht — in Stammdaten, Postecke, Datacenter, Verkauf und Eingangsrechnungen.

### Aktualisierungen
- Ansehen bleibt überall möglich: Belege, Dateien und Datensätze lassen sich weiterhin öffnen, herunterladen und drucken, auch ohne Änderungsrecht.

---

## [1.12.62] – 2026-08-18 – Rechte oberflaeche

### Aktualisierungen
- (Release-Notes ergänzen)

---

## [1.12.61] – 2026-08-18 – Rechtegruppen in der Oberfläche

### Neu
- Neue Gruppenverwaltung: Rechte je Modul getrennt nach Ansehen, Ändern und Löschen vergeben
- Umfang je Gruppe einstellbar — Mitarbeiter sehen wahlweise nur ihre eigenen Einträge

### Aktualisierungen
- Benutzer bekommen ihre Rechte jetzt über Gruppen statt über einzelne Modul-Häkchen
- Schaltflächen zum Anlegen erscheinen nur noch, wenn das Recht dazu vorhanden ist

---

## [1.12.60] – 2026-08-17 – Sicherheit anmeldung

### Aktualisierungen
- (Release-Notes ergänzen)

---

## [1.12.59] – 2026-08-16 – Datacenter spalten

### Aktualisierungen
- (Release-Notes ergänzen)

---

## [1.12.58] – 2026-08-16 – Dashboard neue widgets

### Aktualisierungen
- (Release-Notes ergänzen)

---

## [1.12.57] – 2026-08-16 – Dashboard: schnellerer Aufbau und korrekte Finanzzahlen

### Aktualisierungen
- Dashboard: lädt spürbar schneller — die Kennzahlen kommen jetzt mit einem einzigen Datenabruf statt mit über einem Dutzend.
- Dashboard: die Finanz-Kachel wies bei den Beträgen immer 0,00 € aus und zeigt nun die tatsächlichen Summen. „Offen" umfasst zusätzlich gesendete und teilbezahlte Rechnungen, ausgewiesen wird der noch offene Restbetrag.

---

## [1.12.56] – 2026-08-15 – Dashboard: eigene Ansichten und frei wählbare Bausteine

### Neu
- Dashboard: Bausteine gezielt hinzufügen und entfernen, Kacheln umbenennen, mehrere Ansichten anlegen und umschalten.

### Aktualisierungen
- Dashboard: bestehende Anordnungen werden automatisch übernommen; jede Ansicht lässt sich auf die Standardbelegung zurücksetzen.

---

## [1.12.55] – 2026-08-12 – Postecke foto drehung

### Aktualisierungen
- (Release-Notes ergänzen)

---

## [1.12.54] – 2026-08-12 – Postecke ki diagnose

### Aktualisierungen
- (Release-Notes ergänzen)

---

## [1.12.53] – 2026-08-12 – Postecke: Medien bleiben nach Speicherwechsel auffindbar

### Aktualisierungen
- Postecke: Fotos und Videos merken sich jetzt, in welchem Dateispeicher sie abgelegt wurden. Nach einem Wechsel des Speichers bleiben auch ältere Medien in Vorschau, Download und beim Veröffentlichen erreichbar — und werden beim Löschen restlos entfernt.

---

## [1.12.52] – 2026-08-11 – E rechnung facturx

### Aktualisierungen
- (Release-Notes ergänzen)

---

## [1.12.51] – 2026-08-11 – Auswertungen im Verkauf

### Neu
- Neue Seite „Auswertungen“ unter Buchhaltung: Umsatz je Monat mit Vorjahresvergleich, Rangliste der Kunden mit Anteil am Gesamtumsatz, Rangliste der Artikel und die Angebotsquote
- Bei den Artikeln steht über der Liste, wie viel Umsatz sich keinem Artikel zuordnen ließ — frei geschriebene Positionen tauchen dort nicht auf, und das soll man wissen, bevor man die Rangliste liest

### Aktualisierungen
- Alle Beträge sind netto und zählen im Monat des Belegdatums — dieselbe Abgrenzung wie Verkaufsbuch und Umsatzsteuer, damit beide Ansichten dieselbe Zahl nennen

---

## [1.12.50] – 2026-08-10 – E-Rechnung (ZUGFeRD / Factur-X)

### Neu
- Rechnungen und Gutschriften können die Rechnungsdaten als E-Rechnung ins PDF eingebettet mitführen (ZUGFeRD 2.5 / Factur-X, Profil EN 16931). Für den Empfänger sieht der Beleg unverändert aus; wer die Daten verarbeiten kann, spart das Abtippen
- Neuer Abschnitt „E-Rechnung“ am ausgestellten Beleg: zeigt, ob der Beleg vollständig ist, benennt fehlende Angaben und stellt das XML zum Herunterladen bereit
- Einzuschalten in den Belegeinstellungen unter Verkauf — ab Werk ausgeschaltet

### Aktualisierungen
- Mengeneinheiten werden für die E-Rechnung in genormte Codes übersetzt. Unbekannte Einheiten werden gemeldet statt geraten, damit aus Stunden nicht still Stück werden
- Behoben: Wird ein Beleg direkt nach dem Anlegen per E-Mail verschickt, kam er beim Empfänger bisher mit dem Wasserzeichen „ENTWURF“ an — erst beim zweiten Versand war es weg. Der Beleg wird jetzt ausgestellt, bevor das PDF entsteht. Fehlt dabei eine Pflichtangabe, wird das vorher gemeldet, statt die E-Mail hinausgehen zu lassen und danach einen Fehler zu zeigen

---

## [1.12.49] – 2026-08-09 – Anzahlung, Teil- und Schlussrechnung

### Neu
- Rechnungen können jetzt als Anzahlung, Teilrechnung oder Schlussrechnung geführt werden. Aus einem Angebot lässt sich mit einem Klick eine Anzahlung über einen Prozentsatz oder einen festen Betrag anfordern
- Die Schlussrechnung weist die Gesamtleistung aus und zieht alle bereits gestellten Anzahlungen und Teilrechnungen wieder ab — je Steuersatz getrennt, wie es die Umsatzsteuer verlangt
- Neuer Abschnitt „Abrechnungsvorgang“ am Beleg: zeigt alle Rechnungen eines Bauvorhabens, was davon offen ist und was in der Schlussrechnung abgezogen wird

### Aktualisierungen
- Beim Umwandeln eines Angebots reisen Positionsbilder und das Erlöskonto der Position jetzt mit — bisher gingen beide verloren

---

## [1.12.48] – 2026-08-09 – Angebote mit Bindefrist

### Neu
- Angebote haben jetzt eine Bindefrist: Das Feld „Gültig bis“ wird beim Anlegen automatisch gefüllt (Vorgabe 30 Tage, in den Belegeinstellungen änderbar) und steht auf dem ausgedruckten Angebot
- Abgelaufene Angebote sind in der Liste als solche erkennbar. Wer sie trotzdem in einen Auftrag oder eine Rechnung umwandelt, wird einmal gefragt — gehindert wird niemand

### Aktualisierungen
- Wird eine Position mit Bild entfernt, verschwindet die Bilddatei jetzt mit ihr, statt im Speicher liegenzubleiben
- Jede Datei merkt sich, in welchem Speicher sie liegt. Nach einem Wechsel zwischen MinIO und OneDrive bleiben ältere Positionsbilder und Rechnungsoriginale weiter abrufbar

---

## [1.12.47] – 2026-08-09 – Wiederkehrende Belege vollstaendig

### Neu
- Wiederkehrende Rechnungen können jetzt auch nur erinnern (Aufgabe statt Beleg) oder den Beleg ausstellen und gleich verschicken — die Auswahl steht im Belegformular unter „Am Stichtag"

---

## [1.12.46] – 2026-08-08 – Eingangsrechnungen und Vorsteuer

### Neu
- Eingangsrechnungen: Lieferantenrechnungen erfassen, das Original hinterlegen, Zahlungen führen und die offenen Posten der Kreditoren sehen
- Die Umsatzsteuer-Auswertung enthält jetzt die Vorsteuer — Reverse Charge und innergemeinschaftlicher Erwerb erscheinen mit Steuerschuld *und* Vorsteuerabzug

### Aktualisierungen
- Das Übergabepaket an die Steuerberatung enthält ein zweites Buchungsjournal für die Eingangsseite

---

## [1.12.45] – 2026-08-06 – Buchhaltung als eigener Bereich

### Neu
- Eigener Menüpunkt „Buchhaltung" mit Übersichtsseite: offen gesamt, davon überfällig und wie viele Belege gerade mahnbar sind — dazu der Zugang zu allen Auswertungen

### Aktualisierungen
- Offene Posten, Mahnlauf, Verkaufsbuch, Monatsabschluss und Kontenplan sind vom Verkauf in den Bereich Buchhaltung gezogen; die bisherigen Adressen leiten weiter
- Der Kontenplan liegt nicht mehr in den Einstellungen: Wer das Recht „Buchhaltung" hat, sieht ihn — ändern darf ihn weiterhin nur ein Administrator

---

## [1.12.44] – 2026-08-06 – Mahnwesen: Zugriff auf die Buchhaltung beschränkt

### Aktualisierungen
- Mahnlauf und Mahnungen setzen jetzt das Zusatzrecht „Buchhaltung" voraus — sie zeigen dieselben offenen Beträge wie die Offene-Posten-Liste, die schon bisher dieses Recht verlangt

---

## [1.12.43] – 2026-08-04 – Verkauf: Mahnwesen und Skonto

### Neu
- Mahnwesen: Mahnlauf mit Vorschau, vierstufige Mahnungen mit Frist, Gebühr und Verzugszinsen, Sammelmahnung je Kunde, Mahnsperre und Mahnhistorie am Beleg
- Skonto je Beleg: Zahlungsbedingung auf dem Beleg, Ausbuchen des Restbetrags mit anteiliger Umsatzsteuer-Berichtigung im Monat der Zahlung

### Aktualisierungen
- Umsatzsteuer-Auswertung: Eine Rabattzeile wurde mangels Steuersatz als Reverse-Charge-Umsatz gezählt statt als Minderung der besteuerten Grundlage

---

## [1.12.42] – 2026-08-03 – Verkauf: Gliederung, Rabatte und Bilder in Belegen

### Neu
- Belege lassen sich gliedern: Überschrift eröffnet eine Gruppe, Freitext erläutert, Zwischensumme fasst die Gruppe zusammen
- Rabattzeile auf eine Gruppe — als fester Betrag oder in Prozent; bei gemischten Steuersätzen wird der Rabatt anteilig verteilt
- Bild je Position: nach dem Hochladen eine von drei Druckgrößen wählen (3, 6 oder 10 cm); erscheint in Vorschau und PDF
- Positionen lassen sich mit Pfeiltasten umsortieren

### Aktualisierungen
- Der MwSt.-Modus „Ein Satz für alle" wirkt jetzt tatsächlich — er war bisher wählbar, ohne etwas zu bewirken
- Fehlt bei Belegen über 10.000 Euro die UID des Empfängers, wird das am Beleg und im Monatsabschluss vermerkt
- Das Verkaufsbuch liefert bei einem Fehler keine HTML-Datei mehr unter dem Namen einer PDF-Datei
- Beim Massenversand bleiben bereits verschickte Belege erhalten, auch wenn ein späterer Versand scheitert
- Die Abschlusszeile der Positionstabelle heißt „Nettosumme" statt „Zwischensumme" — der Begriff ist jetzt den Gruppensummen vorbehalten

---

## [1.12.41] – 2026-08-03 – Verkauf: Monatsabschluss und Übergabe an die Buchhaltung

### Neu
- Monatsabschluss: Monat prüfen, abschließen und damit gegen nachträgliche Änderungen sperren — offene Entwürfe verhindern den Abschluss
- Übergabepaket als ZIP mit Buchungsjournal, Belegjournal, Umsatzsteuer-Aufstellung, offenen Posten und jedem Beleg als PDF, samt Prüfsumme je Datei
- Übergabe-Historie je Monat: wer wann welches Paket erstellt hat, mit Prüfsumme als Nachweis

### Aktualisierungen
- Ein abgeschlossener Monat lässt sich nur von einem Admin und nur mit Begründung wieder öffnen; der Abschluss bleibt dabei dokumentiert
- Zahlungseingänge bleiben auch in abgeschlossenen Monaten erfassbar — sie ändern nichts am Belegjournal
- Das Paket weist aus, dass es die Verkaufsseite abdeckt: Eingangsrechnungen und Vorsteuer sind gesondert beizubringen

---

## [1.12.40] – 2026-08-03 – Verkauf: Umsatzsteuer-Auswertung und Erlöskonto je Position

### Neu
- Umsatzsteuer-Auswertung im Verkaufsbuch — Bemessungsgrundlage und Steuer je Kennzahl des Formulars U30, dazu ein Ausdruck zum Übertragen ins Finanzamts-Portal
- Erlöskonto je Belegposition: wird vom Artikel übernommen und bleibt änderbar — der Buchhaltungs-Export trennt die Umsätze damit nach Erlösarten
- Steuerland in den Firmendaten; bestimmt Steuersätze und Aufbau der Umsatzsteuer-Auswertung

### Aktualisierungen
- Die Auswertung weist ausdrücklich aus, dass sie nur die Umsatzseite enthält — Vorsteuer und innergemeinschaftliche Erwerbe erfasst DeineZeit nicht und sind vor der Abgabe zu ergänzen
- UVA-Kennzahl je Steuersatz pflegbar, vorbelegt mit 022 (20 %), 029 (10 %) und 006 (13 %)
- Das Verkaufsbuch lädt beim Öffnen, statt auf einen Knopfdruck zu warten

---

## [1.12.39] – 2026-08-02 – Verkauf: Zahlungen, offene Posten und Modulrecht Buchhaltung

### Neu
- Zahlungen je Beleg erfassen — Teil- und Ratenzahlungen mit Zahlungsart und Verwendungszweck; eine falsch erfasste Zahlung lässt sich zurücknehmen
- Neue Übersicht „Offene Posten" mit Fälligkeitsstaffel und Summierung je Kunde
- Neues Modulrecht „Buchhaltung" — schaltet Verkaufsbuch, offene Posten und den Buchhaltungs-Export frei
- Fällige, noch nicht beglichene Rechnungen werden automatisch als überfällig gekennzeichnet

### Aktualisierungen
- Neuer Belegstatus „Teilbezahlt" — eine angezahlte Rechnung gilt nicht mehr einfach als offen
- „Als bezahlt markieren" wird ebenfalls als Zahlung erfasst und ist damit nachvollziehbar
- Überzahlungen werden angenommen und ausgewiesen statt abgelehnt
- Jede Zahlung und jeder Fälligkeitswechsel steht im Änderungsprotokoll des Belegs

---

## [1.12.38] – 2026-08-01 – Verkauf: Leistungsdatum, Steuersätze und Rundung

### Neu
- Liefer-/Leistungsdatum am Beleg, wahlweise als Zeitraum — Pflichtangabe beim Ausstellen von Rechnungen und Gutschriften (§ 11 UStG)
- Steuersätze sind in den Verkaufseinstellungen pflegbar: Prozentsatz, Bezeichnung und USt-Code für die Buchhaltung — der ermäßigte Satz von 13 % ist damit erfassbar

### Aktualisierungen
- Die Umsatzsteuer wird je Steuersatz gerundet statt je Position — Netto plus Steuer ergibt auf jedem Beleg exakt die Gesamtsumme
- Textzeilen ohne Betrag erzeugen auf dem Beleg keine irrtümliche Reverse-Charge-Zeile mehr
- Ein nicht gepflegter Steuersatz wird im Buchhaltungs-Export nicht mehr stillschweigend als Normalsatz gebucht
- Gutschriften, Umwandlungen und Serienrechnungen übernehmen den Leistungszeitraum des Ursprungsbelegs

---

## [1.12.37] – 2026-08-01 – Verkauf: Belegsperre, Nummernkreis und Änderungsprotokoll

### Neu
- Ausgestellte Belege sind inhaltlich gesperrt — Positionen, Beträge, Empfänger und gedruckte Texte bleiben unverändert; Korrekturen laufen über Storno und Neuausstellung
- Änderungsprotokoll je Beleg: wer wann was geändert hat, direkt am Beleg einsehbar
- Belegnummern werden erst beim Ausstellen vergeben — ein verworfener Entwurf hinterlässt keine Lücke mehr im Nummernkreis

### Aktualisierungen
- Die PDF-Archivierung ins Datacenter ist ab Werk für jeden ausgestellten Beleg aktiv, nicht mehr nur beim E-Mail-Versand
- Jeder Archivierungsversuch wird am Beleg vermerkt — mit Ablageort bei Erfolg und mit Grund bei Fehlschlag
- Der Zählerstand eines Nummernkreises lässt sich nur noch erhöhen, nie zurücksetzen
- Ausgestellte und stornierte Belege können nicht mehr gelöscht werden (Aufbewahrungspflicht)
- Angebote und Entwürfe lassen sich nicht mehr versehentlich als bezahlt markieren
- Die Projektzuordnung eines Belegs geht beim Speichern nicht mehr verloren

---

## [1.12.36] – 2026-08-01 – Verkauf: Buchhaltung und Zeitabrechnung

### Neu
- Freigegebene Stunden lassen sich wieder in Belege übernehmen und werden dabei automatisch als abgerechnet markiert
- Nach dem Storno eines Belegs stehen die darauf abgerechneten Stunden erneut zur Verrechnung bereit

### Aktualisierungen
- Der Buchhaltungs-Export (BMD) funktioniert wieder und enthält jetzt auch Gutschriften
- Gutschriften werden korrekt als Umsatzminderung übergeben statt als Umsatz
- Der ermäßigte Steuersatz 13 % erhält einen eigenen Steuercode statt bisher 20 %
- Das Verkaufsbuch zeigt den Kundennamen an
- Die in den Einstellungen gewählte PDF-Vorlage wird bei neuen Belegen tatsächlich verwendet

---

## [1.12.35] – 2026-07-27 – Postecke: Instagram-Direktveröffentlichung

### Neu
- Instagram direkt veröffentlichen und planen — Einzel-Foto, Foto-Serie (Carousel) und Reels (Video); Konto im Profil verbinden und testen.

### Aktualisierungen
- Einrichtungshilfe und Anleitung für die Instagram-Anbindung (Professionell-Konto, Konto-ID + Access-Token).

---

## [1.12.34] – 2026-07-26 – Postecke: Video-Beiträge & Einrichtungshilfe je Kanal

### Neu
- Video-Beiträge (MP4/MOV bis 200 MB) inkl. automatischer Veröffentlichung auf Facebook-Seiten; pro Beitrag Fotos oder ein Video.

### Aktualisierungen
- Neuer Infokasten im Profil-Formular erklärt je Kanal die Einrichtung (Facebook-Seite, Instagram, assistierte Kanäle).
- Beiträge werden beim Speichern automatisch im Datacenter abgelegt (Ordner „Postecke" bzw. beim verknüpften Kontakt): Fotos oder Video plus der Text als Datei.
- Video-Vorschau im Editor zeigt jetzt ein Standbild (erstes Bild) — funktioniert für jedes Format, auch iPhone-Videos.
- Profilanlage: Button „Prompt-Generator kopieren" liefert einen fertigen Prompt, um aus eigenen Beispiel-Posts einen persönlichen Stil-Prompt zu erstellen.

---

## [1.12.33] – 2026-07-22 – OneDrive-Anbindung für Datei-Speicher & Backup

### Neu
- Datei-Speicher wahlweise in Microsoft OneDrive/SharePoint (Graph API) – persönliches OneDrive (über Benutzer) oder SharePoint-Site
- Automatisches tägliches Server-Backup der Datenbank nach OneDrive inkl. Aufbewahrung, plus manueller Sofort-Upload
- Speicher-Konsolidierung: alle Dateien per Klick auf den aktiven Speicher umziehen
- Cloud-Ordner werden nach Kundennamen benannt statt interner IDs; Bestandsdateien per Klick umstellbar

### Aktualisierungen
- OneDrive-Verbindungstest korrigiert (kein Fehler 500 mehr) mit klaren Meldungen bei fehlenden Zugangsdaten
- Jede Datei merkt sich ihren Speicherort – Mischbetrieb MinIO/OneDrive und Provider-Wechsel ohne Datenverlust
- OneDrive-Upload-Pfad korrigiert (Sonderzeichen, versehentliche Windows-Backslashes)

---

## [1.12.32] – 2026-07-22 – Einrichtungsassistent für die Erstinstallation

### Neu
- Neue Installationen sind sofort startklar: Ein geführter Assistent legt beim ersten Start den Administrator und die Firmendaten (inkl. Logo) an – ganz ohne Kommandozeile.

### Aktualisierungen
- Firmendaten werden automatisch als Briefkopf hinterlegt und der Firmenname in die Einstellungen übernommen.
- Kontakte-Register aufgeräumt (Standard/Finanz inkl. Zahlungsziel); das Modul „Zeitprojekte“ hat jetzt eine direkte Kontakt-Verknüpfung.

---

## [1.12.31] – 2026-07-20 – Postecke: Facebook-Seiten direkt angebunden

### Neu
- Postecke: Facebook-Seiten sind jetzt direkt angebunden — „Jetzt veröffentlichen" postet Text, Hashtags und Fotos ohne Umweg direkt auf die Seite
- Postecke: Geplante Posts auf angebundenen Kanälen werden zur eingestellten Zeit vollautomatisch veröffentlicht; Fehler werden am Post angezeigt und automatisch erneut versucht
- Postecke: Zugangsdaten (Seiten-ID + Token) werden verschlüsselt je Profil gespeichert, mit „Verbindung testen"-Knopf — Einrichtungsanleitung liegt bei (FACEBOOK-SEITE-ANBINDEN.md)

---

## [1.12.30] – 2026-07-20 – Postecke: Profil-Parameter für Fotos & neue Kanäle

### Neu
- Postecke: Je Profil sind jetzt Bildformat (z. B. 1:1 Quadrat, 4:5, 16:9, 9:16 Story) und ein Foto-Filter (Brillant, Warm, Kühl, Kontrast+, Schwarz-Weiß) hinterlegbar — beim Teilen und Herunterladen werden alle Fotos automatisch so ausgespielt, die Originale bleiben erhalten
- Postecke: Neue Kanäle für Profile — TikTok, YouTube, WhatsApp (Status/Kanal), X (Twitter), Threads, Google Unternehmensprofil und Pinterest

---

## [1.12.29] – 2026-07-20 – iPhone-Anzeige stabilisiert

### Aktualisierungen
- Kein ungewolltes Hineinzoomen mehr bei Eingabefeldern am iPhone und iPad — die Ansicht bleibt stabil im Geräterahmen

---

## [1.12.28] – 2026-07-15 – Zeiterfassung: Sprach-Eintrag per KI & flexible Zeiten

### Neu
- Projektzeit per Sprache nachtragen: neuer Aufnahme-Knopf in der Zeiterfassung — die Ansage wird per KI ausgewertet und der Nachtragen-Dialog automatisch vorbefüllt
- Start- und Endzeit im Timer-Bereich jederzeit manuell anpassbar, mit Vorschlägen wie letzter Endzeit oder aktueller Uhrzeit

### Aktualisierungen
- Aktions-Symbole in der Eintragsliste sind jetzt bei jedem Eintrag dauerhaft sichtbar (auch auf Touch-Geräten)

---

## [1.12.27] – 2026-07-12 – Layout-Redesign: Handy-Optimierung & Barrierefreiheit

### Neue Funktionen
- Menüleiste unten am Handy mit den wichtigsten Modulen und rundem Plus-Knopf für „Neu anlegen"
- Schnellsuche mit Cmd/Strg+K über Module, Stammdaten und Aktionen
- Dunkelmodus und Barrierefreiheit pro Benutzer (Hell/Dunkel/Automatisch, hoher Kontrast, größere Schrift, weniger Animation)

### Aktualisierungen
- Dialogfenster verdecken am Handy die Menüleiste nicht mehr und sind durchscrollbar
- Stammdaten-Listen erscheinen am Handy als Karten

---

## [1.12.26] – 2026-07-12 – Layout-Redesign: Designvorlagen & Whitelabel

### Neue Funktionen
- 8 Designvorlagen mit Live-Vorschau (Einstellungen → Design)
- Eigene Markenfarbe färbt die gesamte App (Whitelabel)
- Stammdaten-Typen direkt im Menü aufklappbar

### Aktualisierungen
- Einheitlicher Seitenaufbau in allen Modulen (Symbol, Titel, Aktionen an fester Position)
- Feinanpassung für Text-, Hintergrund- und Flächenfarben

---

## [1.12.25] – 2026-07-12 – Layout-Redesign: Fundament

### Aktualisierungen
- Technisches Fundament für das neue Design (Design-Tokens) — Optik unverändert

---

## [1.12.24] – 2026-07-12 – Modulrechte pro Benutzer

### Neu
- Der Admin kann jetzt pro Benutzer festlegen, welche Module er verwenden darf (Benutzerverwaltung → Bearbeiten) — z.B. nur Zeiterfassung für Erfassungs-Mitarbeiter
- Menü und Dashboard zeigen nur noch die freigeschalteten Module; die Startseite ist das erste erlaubte Modul

### Aktualisierungen
- Bestehende Benutzer behalten automatisch alle Module — es ändert sich nichts, bis der Admin Module abschaltet
- Stammdaten bleiben für alle lesbar (Auswahlfelder), Bearbeiten erfordert das Stammdaten-Modul; Datei-Anhänge an Datensätzen funktionieren weiterhin in allen Modulen

---

## [1.12.23] – 2026-07-11 – Sichere Löschregeln & Archivierung

### Neu
- Stammdaten können jetzt archiviert und wiederhergestellt werden (Archiv-Ansicht) — verknüpfte Daten bleiben nachvollziehbar erhalten
- Neue Verwendungs-Prüfung: Vor dem Löschen zeigt das System, wo ein Datensatz überall verwendet wird
- Zeiterfassung: Neuer Abrechnungs-Status je Eintrag (Veränderbar → Gesperrt → Freigegeben → Abgerechnet) mit Schloss-Symbol, einzeln oder per Mehrfachauswahl umstellbar — auch manuell abgerechnete Zeiten sind damit geschützt

### Aktualisierungen
- Stammdaten mit Verknüpfungen (Zeiten, Belege, Projekte, Dateien) sind vor versehentlichem Löschen geschützt; endgültiges Löschen nur noch durch Admins
- Bereits abgerechnete Zeiteinträge können nicht mehr geändert oder gelöscht werden; Zeiteinträge anderer Benutzer sind schreibgeschützt
- Projekte und Aufgaben mit gebuchten Zeiten können nicht mehr gelöscht werden — stattdessen archivieren
- Stundenkonten werden beim Löschen einer Projektzeit nicht mehr mitgelöscht
- Aufgaben: Entfernen fragt jetzt nach (Archivieren oder endgültig löschen); Aufgaben mit verknüpftem Zeiteintrag sind unlöschbar, löschen dürfen nur Ersteller, Zugewiesener oder Admin
- Datacenter: Löschen fragt jetzt immer nach; Dateien, die mit einem Verkaufsbeleg verknüpft sind (z.B. Verträge wiederkehrender Rechnungen), können nur über das Verkaufsmodul entfernt werden; automatisch archivierte Belege löscht nur der Admin

---

## [1.12.22] – 2026-07-11 – Fehlerbehebungen Postecke & Mobil

### Aktualisierungen
- Postecke: Foto-Upload zuverlässig auch mit großen iPhone-Fotos (Fotos werden einzeln übertragen, Server-Limit erhöht, klare Fehlermeldung je Foto)
- Postecke: KI-Vorschläge mit vielen Fotos brechen nicht mehr durch Server-Timeout ab
- Einstellungen: Neues Logo/Favicon erscheint nach dem Hochladen sofort (kein veraltetes Bild aus dem Browser-Cache mehr)
- iPhone: Hinweismeldungen erscheinen nicht mehr unter der Notch; Unter-Tabs in den Einstellungen laufen nicht mehr über den Bildschirmrand

---

## [1.12.21] – 2026-07-10 – Neues Modul: Postecke – Social-Media-Posts mit KI vorbereiten

### Neu
- Postecke: Fotos hochladen, kurz beschreiben (auch per Diktat) – die KI erstellt Posttext, Hashtags, Ort und Gefühl im Stil des gewählten Kontos
- Postecke: Profile je Social-Media-Konto (Facebook, Instagram, LinkedIn u. a.) mit eigenen Stil-Vorgaben für die KI
- Postecke: Assistiertes Posten – am iPhone/iPad mit Fotos direkt über das Teilen-Menü, der Text liegt in der Zwischenablage
- Postecke: Redaktionsplan mit drei Ansichten – Liste, Kanban-Board (Status per Drag & Drop) und Monatskalender, dazu Volltextsuche über alle Posts
- Postecke: Posts können einem Kontakt zugeordnet und archiviert werden – das Archiv landet samt Text und Fotos im Datacenter beim Kontakt im Ordner „Postsarchiv" (ohne Kontakt global), inklusive Wiederherstellung

### Aktualisierungen
- KI-Anbindung zentralisiert: Postecke und Mail-Importer nutzen dieselben KI-Einstellungen, jetzt mit Foto-Erkennung
- Datacenter: Textdateien (z. B. das Postsarchiv) werden in der Vorschau jetzt lesbar angezeigt; die Vorschau respektiert am iPhone den Bildschirmrand und lässt sich immer schließen

---

## [1.12.20] – 2026-07-08 – Verkauf: Duplizieren, wiederkehrende Rechnungen, erweiterte Suche & Beleg-Archiv

### Neu
- Belege duplizieren: Über das Kontextmenü lässt sich jeder Beleg als neuer Entwurf duplizieren – im Dialog wählbar, welche Teile übernommen werden (Positionen, Texte, Kontakt/Referenz, Anhänge).
- Wiederkehrende Rechnungen: Rechnungen als Serie mit Intervall und Laufzeit anlegen; fällige Rechnungen entstehen automatisch als Entwurf und sind farblich markiert.
- Erweiterte Suche im Verkauf: Belege lassen sich jetzt auch nach Kontakt, Artikel und Projekt durchsuchen.
- Automatisches Beleg-Archiv: Bei frei wählbaren Ereignissen wird ein PDF des Belegs automatisch im Datacenter unter dem Kunden – je Belegart in eigenem Unterordner – abgelegt.

### Aktualisierungen
- Verträge zu wiederkehrenden Rechnungen: mehrere Verträge je Beleg möglich, im Datacenter unter dem Kunden im Ordner „Verträge“ mit Belegnummer, direkt im Formular öffnen und entfernen.
- Wiederkehrende Vorlagen erscheinen nun auch in der Gesamtliste (violett markiert).

---

## [1.12.19] – 2026-07-08 – Aussagekräftigere Release-Notes

### Aktualisierungen
- Die Änderungsliste auf der Anmeldeseite zeigt jetzt aussagekräftigere Release-Notes

---

## [1.12.18] – 2026-07-08 – Zeiterfassung & Verkauf

### Neu
- Zeiterfassung um ein Stundenkonto erweitert

### Aktualisierungen
- Das Beleg-Modul heißt in der Oberfläche jetzt durchgängig „Verkauf"

---

## [1.12.17] – 2026-07-06 – Datenschutz

### Neu
- DSGVO-konforme Datenlöschung unter Einstellungen → Datenschutz

---

## [1.12.16] – 2026-07-06 – Automatische Versionierung

### Aktualisierungen
- Versionsnummer und Änderungsliste werden automatisch aktuell gehalten

---

## [1.12.15] – 2026-07-02 – Projekte-Menü & stabileres Deployment

### Aktualisierungen
- Projekte: Aktionsmenü (drei Punkte) wird wieder korrekt angezeigt und nicht mehr doppelt dargestellt
- Automatisches Server-Deployment robuster (Frontend-Update und nginx zuverlässiger)

---

## [1.12.14] – 2026-06-26 – Zeiterfassung Datei-Upload repariert

### Aktualisierungen
- Race-Condition beim Datei-Upload in der Zeiterfassung behoben

---

## [1.12.13] – 2026-06-25 – Kompaktere Sidebar für mehr Platz

### Neu
- Sidebar lässt sich einklappen und zeigt nur noch Symbole an

---

## [1.12.12] – 2026-06-25 – Benutzer-Verwaltung überarbeitet

### Aktualisierungen
- Benutzer-Verwaltung in die Einstellungen integriert und separater Menüpunkt entfernt

---

## [1.12.11] – 2026-06-25 – Datacenter-Reorganisation mit Vererbung

### Neu
- Dateien werden jetzt nach Modul und Kontakt organisiert
- Vererbungsmechanismus für Dateistrukturen implementiert
- Automatisches Backfill von Bestandsdaten

---

## [1.12.10] – 2026-06-25 – Bugfix Zeiteintrag-Dialog

### Aktualisierungen
- Dialog zum Bearbeiten von Zeiteinträgen wurde korrigiert.

---

## [1.12.9] – 2026-06-25 – Datei-Upload Stabilität

### Aktualisierungen
- Datei-Upload mit korrekter Multipart-Boundary-Handhabung repariert
- Anhänge-Zähler wird nun zuverlässig aktualisiert

---

## [1.12.8] – 2026-06-21 – Navigation zum Dashboard vereinfacht

### Neu
- Logo oder Firmennamen können zum Dashboard angetippt werden

---

## [1.12.7] – 2026-06-21 – Schnellzugriff für Projekte

### Neu
- Neues Projekte-Widget für schnellen Zugriff

---

## [1.12.6] – 2026-06-21 – iPhone Header Bugfix

### Aktualisierungen
- iPhone Header lokal behoben

---

## [1.12.5] – 2026-06-21 – Board und Projektübersicht erweitert

### Neu
- Neues Board-System für verbesserte Projektorganisation
- Erweiterte Automatisierungsmöglichkeiten für Workflows
- Neue Projektübersicht mit besserer Darstellung
- Neue Typen zur flexibleren Datenverwaltung

### Aktualisierungen
- Abhängigkeiten aktualisiert und optimiert
- Desktop-Ansicht für bessere Usability überarbeitet

---

## [1.12.4] – 2026-06-21 – Stabilitätsverbesserung Projekt-Details

### Aktualisierungen
- Projekt-Detail stürzt nicht mehr bei verschachtelten Aufgaben ab

---

## [1.12.3] – 2026-06-20 – Automatische Versionsverwaltung mit Schutz

### Aktualisierungen
- Automatische Versionserkennung in check.sh implementiert
- Lock-Schutz für Versionsverwaltung hinzugefügt

---

## [1.12.2] – 2026-06-20 – Versionsprüfung und Release-Management

### Neu
- Versionsprüfungstool zur Überprüfung von Versionsnummern
- Automatisierte Versionscheck-Funktion implementiert
- Push-Freigabe basierend auf Versionsstatus

---

## [1.12.1] – 2026-06-20 – Projektplanung und Stabilität

### Neu
- Neues Projektplanungs-Modul für erweiterte Projektverwaltung
- News-Panel auf der Anmeldeseite für aktuelle Informationen

### Aktualisierungen
- Vite PWA Plugin als Abhängigkeit hinzugefügt
- Docker-Compose-Konfiguration mit Volumes und Networks erweitert
- Neu-laden-Button in Einstellungen mit visuellen Rückmeldungen verbessert
- config.py vollständig wiederhergestellt
- Kontextmenü Portal-Rendering gegen unerwünschtes Abschneiden optimiert
- Entrypoint-Skript als ausführbar markiert

---

## [1.12.0] - 2026-06-20 - Neues Modul: Projektplanung

### Neu
- **Projektplanungs-Modul** (Menüpunkt „Projekte"): eigenständiges Projekt-Aufzeichnungstool ähnlich MS Project / OpenProject, mobile-first
- Planungsprojekte anlegen, bearbeiten, duplizieren (mit Auswahl, wie viel mitkopiert wird), archivieren und löschen
- Aufgaben & beliebig tief verschachtelbare Teilaufgaben mit Quick-Add zur raschen Erfassung am Handy
- Konfigurierbare Status, Prioritäten, Tags und eigene Aufgaben-Felder (Projekt-Einstellungen)
- Verantwortliche und Kontakte je Projekt und je Aufgabe (Aufgaben erben den Projekt-Kontakt, überschreibbar)
- Anlagen (Dateien/Fotos) an Aufgaben über den bestehenden MinIO-Speicher
- Checklisten an Projekten und Aufgaben: Elemente abhaken, als Aufgabe anlegen, an Benutzer/Kontakt zuweisen inkl. E-Mail-Benachrichtigung
- Gantt-/Zeitschienen-Ansicht: Aufgabenbalken, Meilensteine, Heute-Linie, Abhängigkeiten mit kritischem Pfad, Termine per Drag verschiebbar
- Zeiterfassung: optionale Verknüpfung eines Zeiteintrags mit einer Planungsaufgabe (Ist-/Soll-Stunden)

### Geändert
- Stammdaten „Projekte" in „Projektzeiten" umbenannt
- Projektfarbe wird als Farbkreis in Projektübersicht und -detail angezeigt

### Datenbank
- Migrationen 0016–0019 (Planungsprojekte, Aufgaben, Abhängigkeiten, Meilensteine, konfigurierbare Felder, Checklisten; Kontakt- und Aufgaben-Verknüpfung an Zeiteinträgen)


---

## [1.11.3] - 2026-06-17 - Kontextmenü Portal-Fix


---

## [1.11.1] - 2026-06-17
### GeÃƒÂ¤ndert
- Graph API: Gesendete E-Mails werden jetzt im Outlook-Ordner Ã¢â‚¬Å¾Gesendete Elemente" gespeichert

## [1.10.3] - 2026-06-15
### GeÃƒÂ¤ndert
- Belege-Liste: Header-Buttons, Belegtypen-Tabs und Tabelle fÃƒÂ¼r MobilgerÃƒÂ¤te optimiert (scrollbar, gestapelt, weniger Spalten)
- Beleg bearbeiten: Header-Buttons und Positionszeilen passen sich auf schmalen Bildschirmen an
- Datacenter: OrdnerÃƒÂ¼bersicht ist am Handy als ausklappbares MenÃƒÂ¼ verfÃƒÂ¼gbar, Aktionssymbole immer sichtbar
- Kontakte/Stammdaten: Header-Buttons und Typ-Filter wurden fÃƒÂ¼r MobilgerÃƒÂ¤te responsiv gestaltet

## [1.10.2] - 2026-06-15
### GeÃƒÂ¤ndert
- Berichts-Dialog: Datum-, Gruppierungs- und Filterfelder stapeln sich auf schmalen Bildschirmen statt sich zu ÃƒÂ¼berlappen
- AnhÃƒÂ¤nge-Verwaltung: Aktionssymbole (Ãƒâ€“ffnen, Teilen, LÃƒÂ¶schen) sind am Handy immer sichtbar; Vorschau-Kacheln zeigen auf schmalen Bildschirmen 2 statt 3 Spalten

## [1.10.1] - 2026-06-13
### GeÃƒÂ¤ndert
- Projektzeit-Seite: Buttons "Bericht erstellen" und "Projektzeit nachtragen" zeigen auf schmalen Bildschirmen (Handy) nur noch Icons
- Start-Formular: "Verrechenbar"-Option steht jetzt neben der Startzeit statt darunter, spart Platz auf mobilen GerÃƒÂ¤ten

## [1.10.0] - 2026-06-13
### Neu
- Progressive Web App (PWA) ermÃƒÂ¶glicht die Nutzung von DeineZeit als installierbare App

## [1.9.0] - 2026-06-13
### Neu
- DeineZeit als PWA: Installation ÃƒÂ¼ber "Zum Home-Bildschirm hinzufÃƒÂ¼gen" (eigenes Icon, Vollbildmodus ohne Browserleiste)
- Web App Manifest mit Icons (192px, 512px, maskable, Apple Touch Icon) und Theme-Farbe
- Service Worker (vite-plugin-pwa) fÃƒÂ¼r Caching der App-Shell und grundlegende Offline-Nutzung
### GeÃƒÂ¤ndert
- iOS-Meta-Tags fÃƒÂ¼r Installation ÃƒÂ¼ber Safari ergÃƒÂ¤nzt
- nginx-Konfiguration: Service Worker und Manifest werden nicht mehr langfristig gecacht

## [1.8.5] - 2026-06-13
### GeÃƒÂ¤ndert
- Anhang-Buttons (Cloud-Link, Foto aufnehmen, Hochladen) zeigen auf schmalen Bildschirmen nur noch Icons Ã¢â‚¬â€œ passen jetzt in eine Zeile

## [1.8.4] - 2026-06-13
### GeÃƒÂ¤ndert
- Projektzeit-Hauptseite: Layout der Start- und laufenden Timer-Karte fÃƒÂ¼r MobilgerÃƒÂ¤te (Hoch- und Querformat) ÃƒÂ¼berarbeitet, Spalten stapeln sich statt sich zu ÃƒÂ¼berlappen
- "Projektzeit nachtragen"-Dialog: Formularfelder stapeln sich auf schmalen Bildschirmen statt sich zu ÃƒÂ¼berlappen
- Anhang-Schnellzugriff-Buttons umbrechen jetzt bei wenig Platz

## [1.8.3] - 2026-06-13
### Neu
- Schnellzugriff-Leiste fÃƒÂ¼r AnhÃƒÂ¤nge (Cloud-Link, Foto aufnehmen, Hochladen) direkt auf der Projektzeit-Hauptseite (Start- und laufende Timer-Karte) und im "Projektzeit nachtragen"-Dialog
### GeÃƒÂ¤ndert
- Wird ein Anhang hinzugefÃƒÂ¼gt, bevor der Zeiteintrag gespeichert wurde, wird die Aufgabe automatisch validiert und gespeichert

## [1.8.1] - 2026-06-12
### Neu
- Zeiterfassung-AnhÃƒÂ¤nge: Neuer Button Ã¢â‚¬Å¾Foto aufnehmen" ÃƒÂ¶ffnet direkt die Kamera des GerÃƒÂ¤ts (iPhone/Android/Tablet)
- Bestehender Drag & Drop-Upload-Bereich bleibt fÃƒÂ¼r lokale Dateien erhalten

## [1.8.0] - 2026-06-08
### Neu
- OneDrive-Integration mit Microsoft Graph API (persÃƒÂ¶nliche Konten & SharePoint)

## [1.7.8] - 2026-06-08
### Neu
- OneDrive-Integration: Microsoft OneDrive & SharePoint als Cloudspeicher-Option
- Graph-Anmeldedaten aus E-Mail-Einstellungen kÃƒÂ¶nnen fÃƒÂ¼r OneDrive wiederverwendet werden
- PersÃƒÂ¶nliches OneDrive und SharePoint-Laufwerk konfigurierbar (inkl. Site-ID)

## [1.7.7] Ã¢â‚¬â€œ 2026-06-08 Ã¢â‚¬â€œ Cloudspeicher-Integration abgeschlossen

### Neu
- Cloudspeicher: Nextcloud, SeaDrive und MinIO als Storage-Provider wÃƒÂ¤hlbar
- Speicher-Tab in Einstellungen (Provider-Auswahl, WebDAV-URL, Verbindungstest)
- MSG-Datei (.msg Outlook) Vorschau im Datacenter

### Fixes
- Upload-Fortschrittsanzeige (ProgressEvent Ã¢â€ â€™ korrekter Prozentwert)
- WebDAV-Upload: db=db an storage_service ÃƒÂ¼bergeben (Provider aus DB gelesen)
- storage_backend wird korrekt als Providername (nextcloud/seadrive/minio) gespeichert
- requests-Bibliothek in requirements.txt ergÃƒÂ¤nzt

---

## [1.11.0] Ã¢â‚¬â€œ 2026-06-16 Ã¢â‚¬â€œ Office 365 E-Mail Integration

### Neu
- Office 365 E-Mail-Anbindung ÃƒÂ¼ber Microsoft Graph API

---

## [1.10.4] Ã¢â‚¬â€œ 2026-06-15 Ã¢â‚¬â€œ Mobile-Responsiveness verbessert

### Aktualisierungen
- Mobile-Responsiveness fÃƒÂ¼r Belege, Beleg-Formular, Datacenter und Kontakte optimiert
- Synchronisierungsfehler bei mobilen Ansichten behoben

---

## [1.10.3] Ã¢â‚¬â€œ 2026-06-15 Ã¢â‚¬â€œ Mobile-Optimierungen und Verbesserungen

### Aktualisierungen
- Berichts-Dialog fÃƒÂ¼r mobile GerÃƒÂ¤te optimiert
- AnhÃƒÂ¤nge-Handling verbessert

---

## [1.10.2] Ã¢â‚¬â€œ 2026-06-13 Ã¢â‚¬â€œ Merge-Konflikte aufgelÃƒÂ¶st

### Aktualisierungen
- Merge-Konflikte behoben

---

## [1.10.0] Ã¢â‚¬â€œ 2026-06-13 Ã¢â‚¬â€œ PWA-UnterstÃƒÂ¼tzung fÃƒÂ¼r DeineZeit

### Neu
- Progressive Web App (PWA) ermÃƒÂ¶glicht die Nutzung von DeineZeit als installierbare App

---

## [1.8.5] Ã¢â‚¬â€œ 2026-06-12 Ã¢â‚¬â€œ AnhÃƒÂ¤nge und Mobile-Optimierung

### Neu
- Schnellzugriff auf AnhÃƒÂ¤nge hinzugefÃƒÂ¼gt
- Mobiles Layout fÃƒÂ¼r Projektzeit verbessert

---

## [1.8.2] Ã¢â‚¬â€œ 2026-06-11 Ã¢â‚¬â€œ Behobene Dateien und Dokumentation

### Aktualisierungen
- AttachmentExplorer.jsx vollstÃƒÂ¤ndig repariert
- CHANGELOG.md vollstÃƒÂ¤ndig repariert

---

## [1.8.2] Ã¢â‚¬â€œ 2026-06-11 Ã¢â‚¬â€œ Changelog-Reparatur

### Aktualisierungen
- Changelog-Datei vollstÃƒÂ¤ndig repariert und wiederhergestellt

---

## [1.8.2] Ã¢â‚¬â€œ 2026-06-11 Ã¢â‚¬â€œ Foto-Upload fÃƒÂ¼r Zeiterfassung

### Neu
- Fotos direkt per Kamera bei Zeiterfassung-AnhÃƒÂ¤ngen aufnehmen

---

## [1.8.0] Ã¢â‚¬â€œ 2026-06-08 Ã¢â‚¬â€œ OneDrive-Integration

### Neu
- OneDrive-Integration mit Microsoft Graph API
- UnterstÃƒÂ¼tzung fÃƒÂ¼r persÃƒÂ¶nliche OneDrive-Konten
- UnterstÃƒÂ¼tzung fÃƒÂ¼r SharePoint-Dateien

---


## [1.7.5] Ã¢â‚¬â€œ 2026-06-08 Ã¢â‚¬â€œ Cloudspeicher-Integration

### Neu
- Cloudspeicher-Integration: Nextcloud und SeaDrive als Alternative zu MinIO
- WebDAV-Provider (storage_service.py) mit automatischer Ordnererstellung via MKCOL
- Speicher-Tab in den Einstellungen (Provider-Auswahl, WebDAV-Felder, Verbindungstest)
- Backend-Endpunkte: POST /settings/storage/test + POST /settings/storage/apply
- TTL-Cache (30 s) fÃƒÂ¼r Storage-Provider mit invalidate_provider_cache()
- extract-msg==0.55.0 fÃƒÂ¼r MSG-Outlook-Datei-Vorschau

---

## [1.7.6] Ã¢â‚¬â€œ 2026-06-08 Ã¢â‚¬â€œ WebDAV-Upload Fehlerbehebung

### Aktualisierungen
- WebDAV-Upload funktioniert wieder korrekt nach Datenbankverbindungs-Fix

---

## [1.7.6] Ã¢â‚¬â€œ 2026-06-08 Ã¢â‚¬â€œ Upload-Fortschritt Optimierung

### Aktualisierungen
- Upload-Fortschritt wird nun korrekt aus ProgressEvent berechnet (Fehler in bestimmten Browsern behoben)

---

## [1.7.6] Ã¢â‚¬â€œ 2026-06-08 Ã¢â‚¬â€œ Speicher-Backend Optimierung

### Aktualisierungen
- Storage-Backend speichert Providernamen direkt (Nextcloud/Seadrive/Minio)

---

## [1.7.6] Ã¢â‚¬â€œ 2026-06-08 Ã¢â‚¬â€œ WebDAV-SpeicherunterstÃƒÂ¼tzung hinzugefÃƒÂ¼gt

### Aktualisierungen
- WebDAV-Felder in den Einstellungen integriert

---

## [1.7.6] Ã¢â‚¬â€œ 2026-06-08 Ã¢â‚¬â€œ WebDAV-Integration stabilisiert

### Aktualisierungen
- requests-Bibliothek in WebDAV-Provider integriert

---

## [1.8.0] Ã¢â‚¬â€œ 2026-06-08 Ã¢â‚¬â€œ Cloudspeicher-Integration und StabilitÃƒÂ¤t

### Neu
- Cloudspeicher-Integration fÃƒÂ¼r Nextcloud, SeaDrive und WebDAV
- Neuer Speicher-Tab in den Einstellungen

### Aktualisierungen
- Fehlerhafte package.json repariert

---


## [1.7.3] - 2026-06-08 - Einstellungen umstrukturiert

### Neu
- Einstellungen: Design als Unter-Tab unter Allgemein
- Einstellungen: Backup & E-Mail als Unter-Tabs unter System
- Einstellungen: E-Mail-Vorlagen als Unter-Tab unter Parameter

---

## [1.7.4] Ã¢â‚¬â€œ 2026-06-08 Ã¢â‚¬â€œ StabilitÃƒÂ¤t und Wiederherstellung

### Aktualisierungen
- API und Datacenter-Seite wiederhergestellt

---

## [1.7.4] Ã¢â‚¬â€œ 2026-06-08 Ã¢â‚¬â€œ Datacenter-Seite neu aufgebaut

### Aktualisierungen
- DatacenterPage vollstÃƒÂ¤ndig rekonstruiert mit verbesserter StabilitÃƒÂ¤t
- EML/MSG-Datei-Vorschau hinzugefÃƒÂ¼gt

---

## [1.7.4] Ã¢â‚¬â€œ 2026-06-08 Ã¢â‚¬â€œ MSG-Vorschau und EML-Optimierung

### Neu
- MSG-Vorschau im Datacenter hinzugefÃƒÂ¼gt

### Aktualisierungen
- EML-Verarbeitung bei application/octet-stream-Dateien korrigiert

---

## [1.7.4] Ã¢â‚¬â€œ 2026-06-08 Ã¢â‚¬â€œ E-Mail-Vorschau verbessert

### Aktualisierungen
- E-Mail-Vorschau funktioniert nun auch bei application/octet-stream Dateitypen.

---

## [1.7.4] Ã¢â‚¬â€œ 2026-06-08 Ã¢â‚¬â€œ UTF-8 Encoding Verbesserungen

### Aktualisierungen
- UTF-8 Encoding in bump-version.ps1 korrigiert
- Update-Prozess in system.py optimiert

---

## [1.7.4] Ã¢â‚¬â€œ 2026-06-08 Ã¢â‚¬â€œ Dokumentation und Datacenter-Updates

---

## [1.7.4] Ã¢â‚¬â€œ 2026-06-08 Ã¢â‚¬â€œ Datacenter-Vorschau optimiert

### Neu
- Datacenter: EML-Vorschau direkt im Browser (E-Mail-Dateien)

### Aktualisierungen
- Datacenter: Vorschau-Route repariert (GIF und andere Formate wurden nicht geladen)

---

## [1.7.2] - 2026-06-07 - VersionsprÃƒÂ¼fung robuster + nginx Healthcheck

### Aktualisierungen
- VersionsprÃƒÂ¼fung: GitHub-Fallback via git wenn raw.githubusercontent.com nicht erreichbar
- SettingsPage: zeigt Warnung wenn GitHub-PrÃƒÂ¼fung fehlschlÃƒÂ¤gt
- nginx Healthcheck: wartet auf Backend-Bereitschaft vor Start
- nginx IP-AuflÃƒÂ¶sung: Container-IPs dynamisch alle 10s neu aufgelÃƒÂ¶st
- docker-compose.yml: certbot_conf Volume und Networks ergÃƒÂ¤nzt

---

## [1.7.1] - 2026-06-07 - Datacenter Freigaben-Verwaltung

### Neu
- Datacenter: Freigaben-Ansicht zeigt alle aktiven Share-Links
- Freigaben verlÃƒÂ¤ngerbar ohne Token-Ãƒâ€žnderung (1/7/30/90 Tage oder unbegrenzt)
- Freigaben einzeln widerrufbar direkt aus der ÃƒÅ“bersicht

### Fixes
- Share-Link Route-Reihenfolge fix (war: "Not authenticated" im privaten Browserfenster)

---

## [1.7.0] - 2026-06-07 - E-Mail-Vorlagen System


### Neu
- TipTap Rich-Text Editor fuer E-Mail-Vorlagen
- Vorlagen pro Belegart editierbar
- CC-Feld im Versand-Dialog

### Aktualisierungen
- Versionsanzeige-Logik korrigiert
- bump-version.ps1 git-add repariert

---

## [1.7.1] Ã¢â‚¬â€œ 2026-06-07 Ã¢â‚¬â€œ Share-Link Route-Optimierung

### Aktualisierungen
- Share-Link Route wurde vor der generischen Entity-Route verschoben, um Routing-Konflikte zu beheben.

---
hangelog Ã¢â‚¬â€œ DeineZeit

Alle Ãƒâ€žnderungen werden hier dokumentiert.
Format: [Version] Ã¢â‚¬â€œ Datum Ã¢â‚¬â€œ Was hat sich geÃƒÂ¤ndert

---

## [1.6.8] Ã¢â‚¬â€œ 2026-06-07 Ã¢â‚¬â€œ Versionsanzeige-Korrektur

### Aktualisierungen
- Versionsanzeige zeigt korrekt die installierte Version an, auch wenn der GitHub-Cache veraltet ist

---

## [1.6.7] Ã¢â‚¬â€œ 2026-06-06 Ã¢â‚¬â€œ StabilitÃƒÂ¤t und Mail-Verwaltung

### Aktualisierungen
- Mail-Icon in Rechnungsstatus bleibt nach Seitenwechsel erhalten
- API und AbhÃƒÂ¤ngigkeiten wiederhergestellt, CC-Feld hinzugefÃƒÂ¼gt

---

## [1.6.6] Ã¢â‚¬â€œ 2026-06-06 Ã¢â‚¬â€œ E-Mail-Kommunikation erweitert

### Neu
- E-Mail-Dialog mit Kontaktinfo, EmpfÃƒÂ¤nger-Mail und CC-Feld hinzugefÃƒÂ¼gt

---

## [1.6.5] Ã¢â‚¬â€œ 2026-06-06 Ã¢â‚¬â€œ Kontaktname in Belegliste korrigiert

### Aktualisierungen
- Kontaktnamen werden in der Belegliste nun korrekt angezeigt

---

## [1.6.4] Ã¢â‚¬â€œ 2026-06-06 Ã¢â‚¬â€œ Kontaktsuche Bugfix

### Aktualisierungen
- ContactSearch zeigt Kontaktnamen nach asynchronem Laden korrekt an

---

## [1.6.3] Ã¢â‚¬â€œ 2026-06-06 Ã¢â‚¬â€œ Kontaktanzeige in Belegen

### Aktualisierungen
- Kontakt wird nun in der Belegliste angezeigt
- Kontaktfeld im Formular repariert

---

## [1.6.2] Ã¢â‚¬â€œ 2026-06-06 Ã¢â‚¬â€œ DatacenterPicker API-KompatibilitÃƒÂ¤t

### Aktualisierungen
- DatacenterPicker verarbeitet API-Antworten korrekt, wenn AnhÃƒÂ¤nge als leeres Objekt statt Array zurÃƒÂ¼ckgegeben werden

---

## [1.6.1] Ã¢â‚¬â€œ 2026-06-06 Ã¢â‚¬â€œ AnhÃƒÂ¤nge-Feature korrigiert

### Aktualisierungen
- InvoicePage: AnhÃƒÂ¤nge-Feature korrekt integriert ohne Duplikate

---

## [1.9.0] Ã¢â‚¬â€œ 2026-06-07 Ã¢â‚¬â€œ E-Mail-Vorlagen System

### Neu
- E-Mail-Vorlagen pro Belegart (Rechnung, Angebot, AB, Gutschrift, Lieferschein)
- Neuer Tab Ã¢â‚¬Å¾E-Mail-Vorlagen" in Einstellungen mit Rich-Text-Editor (TipTap)
- Platzhalter: {nummer}, {kontakt}, {firma}, {betrag}, {datum}, {faellig}, {belegart}
- Versand-Dialog: Betreff und E-Mail-Text vor dem Senden editierbar
- Betreff und Body werden aus der Vorlage vorausgefÃƒÂ¼llt

---

## [1.8.0] Ã¢â‚¬â€œ 2026-06-07 Ã¢â‚¬â€œ E-Mail-Dialog: Kontaktinfo & CC-EmpfÃƒÂ¤nger

### Neu
- E-Mail-Versand-Dialog zeigt Kontaktname und EmpfÃƒÂ¤nger-E-Mail an
- CC-Adresse kann optional eingetragen werden
- Backend: CC-UnterstÃƒÂ¼tzung fÃƒÂ¼r SMTP und Microsoft Graph API

---

## [1.7.0] Ã¢â‚¬â€œ 2026-06-06 Ã¢â‚¬â€œ Kontakt in Belegliste & Formular

### Neu
- Belegliste: Spalte "Titel / Kontakt" in zwei getrennte Spalten "Titel" und "Kontakt" aufgeteilt
- Belegliste: Kontaktname wird jetzt korrekt aus Stammdaten geladen und angezeigt
- Beleg-Formular: Kontaktfeld zeigt beim Bearbeiten wieder den gespeicherten Kontakt an

---

## [1.6.0] Ã¢â‚¬â€œ 2026-06-06 Ã¢â‚¬â€œ E-Mail-AnhÃƒÂ¤nge & Datacenter-Browser

### Neu
- AnhÃƒÂ¤nge beim E-Mail-Versand hinzufÃƒÂ¼gen
- Datacenter-Browser fÃƒÂ¼r Dateiauswahl nutzen
- Lokale Dateien als E-Mail-AnhÃƒÂ¤nge hochladen

---

## [1.5.0] Ã¢â‚¬â€œ 2026-06-06 Ã¢â‚¬â€œ Mail-Icons (grÃƒÂ¼n/orange) nach Versand + Status immer auf gesendet setzen

### Neu
- Mail-Icons (grÃƒÂ¼n/orange) nach Versand + Status immer auf gesendet setzen

---

## [1.4.5] Ã¢â‚¬â€œ 2026-06-06 Ã¢â‚¬â€œ E-Mail-Versand und Abrechnung

### Aktualisierungen
- PDF-Kontext korrekt geladen
- Unbilled Time Entries vollstÃƒÂ¤ndig implementiert
- E-Mail-Versand repariert

---

## [1.4.4] Ã¢â‚¬â€œ 2026-06-06 Ã¢â‚¬â€œ E-Mail-Fehlerbehandlung verbessert

### Aktualisierungen
- Fehlermeldungen beim E-Mail-Versand werden nun dauerhaft im Dialog angezeigt.

---

## [1.4.3] Ã¢â‚¬â€œ 2026-06-06 Ã¢â‚¬â€œ E-Mail-Versand repariert

### Aktualisierungen
- E-Mail-Versand und Rechnungsgenerierung wiederhergestellt

---

## [1.4.2] Ã¢â‚¬â€œ 2026-06-06 Ã¢â‚¬â€œ Nginx-StabilitÃƒÂ¤t und Docker-Verbesserungen

### Aktualisierungen
- Healthcheck und dynamische DNS-AuflÃƒÂ¶sung fÃƒÂ¼r Nginx optimiert
- Docker-Compose-Konfiguration vervollstÃƒÂ¤ndigt

---

## [1.4.1] Ã¢â‚¬â€œ 2026-06-06 Ã¢â‚¬â€œ nginx Healthcheck-Fix

### Behoben
- nginx wartet beim Start auf Backend-Healthcheck (`/api/health`) bevor es Anfragen weiterleitet
- nginx lÃƒÂ¶st Container-IPs dynamisch alle 10 Sekunden neu auf (Docker DNS-Resolver `127.0.0.11`) Ã¢â‚¬â€ kein manueller Neustart nach Backend-Recreate nÃƒÂ¶tig
- docker-compose.yml: fehlende Named Volumes (`certbot_conf`) und Networks-Sektion ergÃƒÂ¤nzt

---

## [1.4.0] Ã¢â‚¬â€œ 2026-06-06 Ã¢â‚¬â€œ E-Mail-Integration und StabilitÃƒÂ¤t

### Neu
- Office 365 E-Mail-Integration via Microsoft Graph API

### Aktualisierungen
- WeiÃƒÅ¸er Bildschirm im Changelog-Panel der Anmeldeseite behoben
- Update-Watchdog und HTTPS Health-Check optimiert
- Belegbuch-Endpoints implementiert (Listenansicht, CSV- und PDF-Export)
- Backup-Watcher mit Administratorrechten ausgefÃƒÂ¼hrt
- Quellcode-Verwaltung fÃƒÂ¼r zuverlÃƒÂ¤ssige Docker-basierte Updates verbessert

---

## [1.3.13] Ã¢â‚¬â€œ 2026-06-06 Ã¢â‚¬â€œ Update-Mechanismus Test

### Neu
- Update-Mechanismus End-to-End erfolgreich getestet

---

## [1.3.12] Ã¢â‚¬â€œ 2026-06-06 Ã¢â‚¬â€œ WeiÃƒÅ¸er Bildschirm nach Update behoben

### Behoben
- Absturz auf der Anmeldeseite wenn ein Changelog-Eintrag weder "features" noch "updates" enthÃƒÂ¤lt (optional chaining)
- changelog.js v1.3.11: "changes" in "updates" umbenannt damit Eintrag im Updates-Tab erscheint

---

## [1.3.11] Ã¢â‚¬â€œ 2026-06-06 Ã¢â‚¬â€œ Update-Prozess StabilitÃƒÂ¤tsverbesserungen

### Behoben
- Update-Status bleibt nicht mehr dauerhaft auf "updating" wenn kein neuer Commit vorhanden (Watchdog nach 5 Min)
- Health-Check im Update-Script nutzt jetzt HTTPS statt HTTP (verhindert Rollback-Schleife)
- nginx.conf-Verzeichnis-Bug wird beim Update automatisch korrigiert
- update.sh, nginx-Konfiguration und docker-compose.yml in git aufgenommen (gehen nicht mehr verloren)

---

## [1.3.10] Ã¢â‚¬â€œ 2026-06-05 Ã¢â‚¬â€œ Lokale Instanzerkennung und StabilitÃƒÂ¤tsverbesserungen

### Neu
- Lokale Instanzerkennung implementiert

### Aktualisierungen
- Update-Tab zeigt git pull Anleitung statt Button
- Changelog-Konflikte gelÃƒÂ¶st
- Changelog mit fehlenden Versionen 1.2.1Ã¢â‚¬â€œ1.3.8 synchronisiert

---

## [1.3.9] Ã¢â‚¬â€œ 2026-06-05 Ã¢â‚¬â€œ Lokale Instanz erkennung

### Aktualisierungen
- Lokale Entwicklungsinstanz wird automatisch erkannt Ã¢â‚¬â€ Update-Button zeigt stattdessen Anleitung fÃƒÂ¼r git pull
- Backend blockiert Update-Start in lokalem Modus mit klarer Fehlermeldung

---

## [1.3.8] Ã¢â‚¬â€œ 2026-06-05 Ã¢â‚¬â€œ Frontend-Integration

### Aktualisierungen
- Gesamtes Frontend in Versionskontrolle integriert

---

## [1.3.7] Ã¢â‚¬â€œ 2026-06-05 Ã¢â‚¬â€œ Backend-Infrastruktur aktualisiert

### Aktualisierungen
- Backend-App-Verzeichnis in Versionskontrolle integriert

---

## [1.3.6] Ã¢â‚¬â€œ 2026-06-05 Ã¢â‚¬â€œ KonfigurationsstabilitÃƒÂ¤t verbessert

### Aktualisierungen
- ConfigParser-Interpolation in alembic.ini entfernt

---

## [1.3.5] Ã¢â‚¬â€œ 2026-06-05 Ã¢â‚¬â€œ Datenbankmigrationen hinzugefÃƒÂ¼gt

### Aktualisierungen
- Alembic-Migrationen zur Versionskontrolle hinzugefÃƒÂ¼gt

---

## [1.3.4] Ã¢â‚¬â€œ 2026-06-05 Ã¢â‚¬â€œ Backend-Infrastruktur erweitert

### Aktualisierungen
- Backend-Grunddateien fÃƒÂ¼r Docker-Containerisierung hinzugefÃƒÂ¼gt

---

## [1.3.3] Ã¢â‚¬â€œ 2026-06-05 Ã¢â‚¬â€œ Docker-Compose Integration

### Aktualisierungen
- Docker-Compose Dateien zum Repository hinzugefÃƒÂ¼gt

---

## [1.3.2] Ã¢â‚¬â€œ 2026-06-05 Ã¢â‚¬â€œ Versions-Anzeige korrigiert

### Aktualisierungen
- Versions-Anzeige liest nun aus CHANGELOG.md statt aus package.json oder config.py

---

## [1.3.1] Ã¢â‚¬â€œ 2026-06-05 Ã¢â‚¬â€œ Rechnungs-Widget Darstellung optimiert

### Aktualisierungen
- Rechnungs-Widget wird nun auch bei bestehender Dashboard-Konfiguration korrekt angezeigt.

---

## [1.3.0] Ã¢â‚¬â€œ 2026-06-05 Ã¢â‚¬â€œ Dashboard und Einstellungen ÃƒÂ¼berarbeitet

### Neu
- Rechnungs-Widget im Dashboard hinzugefÃƒÂ¼gt
- Automatischer Versions-Bump via GitHub Actions
- E-Mail als Unter-Tab unter System verschoben
- Backup als Unter-Tab unter System integriert
- Design als Unter-Tab unter Allgemein eingebaut

### Aktualisierungen
- auto_version.py robustheit bei fehlenden Dateien verbessert
- Version aus CHANGELOG.md ausgelesen
- Arbeitsverzeichnis auf Repo-Root gesetzt
- Git-Log-Parsing stabilisiert
- Git-Config vor Script initialisiert

---

## [1.2.1] Ã¢â‚¬â€œ 2026-06-05 Ã¢â‚¬â€œ Dashboard: Rechnungs-Widget

### Neu
- Dashboard-Widget Ã¢â‚¬Å¾Rechnungen": zeigt offene, ÃƒÂ¼berfÃƒÂ¤llige und diesen Monat bezahlte Rechnungen mit Anzahl und Brutto-Summe
- Widget ist standardmÃƒÂ¤ÃƒÅ¸ig im Dashboard enthalten, verschiebbar und in der GrÃƒÂ¶ÃƒÅ¸e anpassbar

---

## [1.2.0] Ã¢â‚¬â€œ 2026-06-05 Ã¢â‚¬â€œ AuftragsbestÃƒÂ¤tigung & Rechnungsmodul-Erweiterungen

### Neu
- AuftragsbestÃƒÂ¤tigung (AB) als neuer Dokumenttyp mit eigenem Nummernkreis (AB-2026-001, Ã¢â‚¬Â¦)
- E-Mail-Versand direkt aus dem Rechnungsmodul Ã¢â‚¬â€ einzeln oder als Bulk-Versand fÃƒÂ¼r mehrere Belege
- Statusworkflow mit kontextabhÃƒÂ¤ngigem AktionsmenÃƒÂ¼: Entwurf Ã¢â€ â€™ Offen Ã¢â€ â€™ Bezahlt, Angenommen / Abgelehnt, Storniert
- Angebote kÃƒÂ¶nnen nach Annahme direkt in eine AuftragsbestÃƒÂ¤tigung oder Rechnung umgewandelt werden

### Aktualisierungen
- Parameter-Tab in den Einstellungen: PrÃƒÂ¤fixe und Nummernformate pro Dokumenttyp frei konfigurierbar
- Dokumenttyp-Bezeichnungen kÃƒÂ¶nnen umbenannt werden

---

## [1.1.0] Ã¢â‚¬â€œ 2026-06-04 Ã¢â‚¬â€œ Buchhaltungsmodul

### Neu
- Kontenplan nach EKR (Einheitskontenrahmen) vorbefÃƒÂ¼llt und durchsuchbar
- BMD-Export fÃƒÂ¼r die steuerliche ÃƒÅ“bergabe an den Steuerberater
- Debitor- und Kreditornummern direkt bei Kontakten hinterlegbar
- ErlÃƒÂ¶skonto pro Artikel festlegbar Ã¢â‚¬â€ wird automatisch auf Rechnungspositionen ÃƒÂ¼bernommen
- Konto pro Rechnungsposition individuell ÃƒÂ¼berschreibbar
- Kontakte: neuer Finanz-Tab mit IBAN, BIC und Bankname (Migration 0012/0013)

---

## [1.0.0] Ã¢â‚¬â€œ 2026-06-03 Ã¢â‚¬â€œ Rechnungsmodul

### Neu
- Rechnungen, Angebote, Gutschriften und Lieferscheine erstellen
- Automatische Nummerierung pro Dokumenttyp (RE-2026-001, AN-2026-001, Ã¢â‚¬Â¦)
- Stornierung mit automatischer Gutschrift oder nur StatusÃƒÂ¤nderung
- Angebote kÃƒÂ¶nnen direkt in Rechnungen umgewandelt werden
- ZeiteintrÃƒÂ¤ge aus der Zeiterfassung direkt auf Rechnung ÃƒÂ¼bernehmen
- Positionen aus Artikel-Stammdaten oder als Freitext
- MwSt.: pro Position wÃƒÂ¤hlbar, ein Satz, oder Kleinunternehmerregelung
- PDF-Export mit 5 wÃƒÂ¤hlbaren Vorlagen (Klassisch, Modern, Kompakt, Elegant, Farbenfroh)
- Rechnungsbuch filterbar nach Monat/Quartal/Jahr und/oder Kunde Ã¢â‚¬â€ als PDF oder CSV
- Zahlungsstatus: offen, bezahlt, ÃƒÂ¼berfÃƒÂ¤llig, storniert
- Wiederkehrende Rechnungsvorlagen (wÃƒÂ¶chentlich, monatlich, quartalsweise, jÃƒÂ¤hrlich)
- Bankverbindung aus den App-Einstellungen automatisch auf jedem Dokument

---

## [0.9.5] Ã¢â‚¬â€œ 2026-06-03 Ã¢â‚¬â€œ Dashboard konfigurierbar

### Neu
- Dashboard-Bausteine per Drag & Drop frei anordnen
- Breite der Bausteine stufenweise anpassen (Ã‚Â¼ / Ã‚Â½ / Vollbreite)
- Layout wird im Browser gespeichert und beim nÃƒÂ¤chsten Besuch wiederhergestellt
- Neues Zeiterfassung-Widget auf dem Dashboard mit Heute/Woche/Monat-ÃƒÅ“bersicht

---

## [0.9.4] Ã¢â‚¬â€œ 2026-06-03 Ã¢â‚¬â€œ Update-Prozess robuster

### Aktualisierungen
- Backend fÃƒÂ¼hrt Alembic-Migrationen jetzt automatisch beim Start aus Ã¢â‚¬â€ zukÃƒÂ¼nftige Updates brauchen kein manuelles `alembic upgrade head` mehr
- Migrations-Fehler beim Start verhindern nun das Hochkommen des Backends Ã¢â€ â€™ Health-Check schlÃƒÂ¤gt fehl Ã¢â€ â€™ automatischer Rollback greift korrekt
- Rollback im Update-Skript stellt jetzt auch die gesicherten Docker-Images wieder her, nicht nur den Git-Commit

---

## [0.9.3] Ã¢â‚¬â€œ 2026-06-02 Ã¢â‚¬â€œ Stammdaten vereinheitlicht

### Aktualisierungen
- Stammdaten-Typen vereinheitlicht: Kunden und Lieferanten zusammengefÃƒÂ¼hrt zu Ã¢â‚¬Å¾Kontakte" mit Typ-Feld (Kunde / Lieferant / Interessent)
- Neuer Stammdaten-Typ Ã¢â‚¬Å¾Artikel" fÃƒÂ¼r Produkte und Dienstleistungen (Bezeichnung, Artikelnummer, Preis, Beschreibung)
- Bestehende Kunden- und Lieferanten-DatensÃƒÂ¤tze werden bei Migration automatisch nach Kontakte ÃƒÂ¼bernommen
- Alembic-Migration 0010 stellt einheitlichen Stand bei Neu- und Bestandsinstallationen sicher

---

## [0.1.0] Ã¢â‚¬â€œ 2026-05-21 Ã¢â‚¬â€œ Grundfundament

### Neu
- Projektstruktur mit Backend (Python/FastAPI), Frontend (React) und Datenbank (PostgreSQL)
- Docker Compose Setup fÃƒÂ¼r einfaches Deployment
- Benutzerverwaltung mit Rollen (Admin / Mitarbeiter)
- Sicheres Login-System:
  - Passwort-Login mit verschlÃƒÂ¼sselter Speicherung
  - Zwei-Faktor-Authentifizierung (TOTP / Google Authenticator)
  - Face ID / Fingerabdruck Login via WebAuthn/Passkeys
- JWT-Token-basierte Authentifizierung mit automatischer Erneuerung
- Mehrsprachigkeit: Deutsch und Englisch (sprachabhÃƒÂ¤ngig pro Benutzer)
- Responsives Design (Mobile-First fÃƒÂ¼r Handy, Tablet und Desktop)
- Datenbank-Migrationen via Alembic (sichere Schema-Updates)
- nginx Reverse Proxy mit HTTPS / Let's Encrypt UnterstÃƒÂ¼tzung
- Sicherheits-Header (HSTS, XSS-Schutz, Frame-Schutz)

### Technische Details
- Backend: FastAPI 0.111, Python 3.12
- Frontend: React 18, Tailwind CSS, i18next
- Datenbank: PostgreSQL 16 mit Alembic-Migrationen
- Deployment: Docker Compose, nginx, Certbot (Let's Encrypt)

---

---

## [0.2.0] Ã¢â‚¬â€œ 2026-05-21 Ã¢â‚¬â€œ Dynamische Stammdaten-Verwaltung

### Neu
- **Stammdaten-Typen**: Kunden, Lieferanten und Projekte vorinstalliert
- **Beliebige neue Typen**: Jederzeit weitere anlegen (z.B. Mitarbeiter, Fahrzeuge, VertrÃƒÂ¤geÃ¢â‚¬Â¦)
- **Dynamischer Formular-Builder**: Felder direkt in der OberflÃƒÂ¤che hinzufÃƒÂ¼gen, bearbeiten und entfernen Ã¢â‚¬â€ ohne Programmieraufwand
- **9 Feldtypen**: Text, mehrzeiliger Text, Zahl, Datum, E-Mail, Telefon, Auswahlliste, Ja/Nein, Webseite
- **Pflichtfelder** und **Listenansicht** pro Feld konfigurierbar
- **Datensatz-Verwaltung**: Anlegen, bearbeiten und lÃƒÂ¶schen mit automatisch generiertem Formular
- **Suche**: Volltextsuche ÃƒÂ¼ber alle Felder eines Stammdaten-Typs
- **Paginierung**: GroÃƒÅ¸e Datenmengen werden seitenweise angezeigt
- **Dashboard**: SchnellÃƒÂ¼bersicht aller Stammdaten-Typen mit Eintrags-ZÃƒÂ¤hler
- **Datenbank**: JSONB-basierter Speicher mit GIN-Index fÃƒÂ¼r schnelle Suche

### Technische Details
- Neue Datenbankmodelle: `entity_types`, `field_definitions`, `entity_records`
- Migration 0002 mit vordefinierten Standard-Feldern fÃƒÂ¼r Kunden/Lieferanten/Projekte
- Neue API-Endpoints: `/api/masterdata/types/*` und `/api/masterdata/types/{slug}/records/*`
- Neue Komponenten: `FieldBuilder`, `DynamicForm`, `MasterDataOverview`, `MasterDataDetail`

---

---

## [0.3.0] Ã¢â‚¬â€œ 2026-05-21 Ã¢â‚¬â€œ Grid-Layout, Import/Export & Benutzerverwaltung

### Neu
- **Snap-to-Grid Drag & Drop Layout-Builder**: Felder per Maus oder Touch-Geste frei verschieben Ã¢â‚¬â€ ein unsichtbares 12-Spalten-Raster sorgt dafÃƒÂ¼r, dass alles sauber einrastet
- **Feldbreite frei wÃƒÂ¤hlbar**: 25% / 33% / 50% / 75% / 100% Ã¢â‚¬â€ direkt per Klick am Feld einstellbar; mehrere Felder kÃƒÂ¶nnen nebeneinander in einer Zeile angezeigt werden
- **Formular respektiert Layout**: Die Erfassungsmaske zeigt Felder exakt im definierten Raster-Layout Ã¢â‚¬â€ auf Desktop und Tablet; auf MobilgerÃƒÂ¤ten werden alle Felder automatisch auf volle Breite gestreckt
- **CSV Export**: Alle DatensÃƒÂ¤tze eines Stammdaten-Typs mit einem Klick als CSV exportieren (Excel-kompatibel mit BOM und Semikolon-Trennung)
- **CSV Import**: CSV-Datei hochladen, Spalten per Dropdown den Feldern zuordnen, Vorschau prÃƒÂ¼fen, dann importieren
- **Profilseite**: Jeder Benutzer kann Name, Sprache und Passwort selbst ÃƒÂ¤ndern sowie 2FA und Passkeys verwalten
- **Benutzerverwaltung**: Admin-Seite zum Anlegen neuer Benutzer mit Rolle und Sprache, Deaktivierung bestehender Benutzer

### Technische Details
- Neue Spalte `col_span` in `field_definitions` (Migration 0003)
- Neue Backend-Endpoints: `/fields-layout` (Bulk-Update), `/records/export/csv`, `/records/import/csv`
- Neue npm-Pakete: `@dnd-kit/core`, `@dnd-kit/sortable`, `@dnd-kit/utilities`, `papaparse`
- Neue Komponenten: `GridFieldBuilder`, `CsvImportExport`, `ProfilePage`, `UserManagementPage`

---

---

## [0.4.0] Ã¢â‚¬â€œ 2026-05-22 Ã¢â‚¬â€œ Sicherheit & Design-Upgrade

### Neu
- **Farbschema zur Laufzeit ÃƒÂ¤nderbar**: PrimÃƒÂ¤rfarbe und Akzentfarbe ÃƒÂ¼ber die Einstellungen wÃƒÂ¤hlbar Ã¢â‚¬â€ kein Neustart nÃƒÂ¶tig
- **Login-Seite neu gestaltet**: Modernes Design mit Markenbild
- **Sidebar neu gestaltet**: Schlankere Navigation, bessere Lesbarkeit
- **Dashboard neu gestaltet**: ÃƒÅ“bersichtlichere Kacheldarstellung
- **Admin-Benutzerbearbeitung**: Admins kÃƒÂ¶nnen Benutzerdaten direkt bearbeiten
- **Passwort vergessen Seite**: Eigene Seite mit Kontaktinformationen fÃƒÂ¼r Passwort-Reset
- **Kontakte zusammengefÃƒÂ¼hrt**: Kunden und Lieferanten wurden zu einem gemeinsamen Ã¢â‚¬Å¾Kontakte"-Typ zusammengefÃƒÂ¼hrt, Typ-Filter (Kunden / Lieferanten / Interessenten) in der Listenansicht
- **Rate Limiting**: Login-Endpunkt ist gegen Brute-Force-Angriffe geschÃƒÂ¼tzt
- **Sicherheits-Header**: HSTS, XSS-Schutz, Frame-Schutz, Content-Type-Sniffing-Schutz
- **API-Docs gesperrt**: Swagger-UI nur noch im Debug-Modus erreichbar
- **Upload-Limit**: Maximale DateigrÃƒÂ¶ÃƒÅ¸e fÃƒÂ¼r Uploads konfigurierbar

### Technische Details
- Migration 0004: Kontakte-Konsolidierung (Kunden + Lieferanten Ã¢â€ â€™ Kontakte mit `typ`-Feld)
- Neue npm-Pakete: `slowapi` (Rate Limiting)
- Tailwind CSS auf CSS-Variablen umgestellt (`--color-primary-*`) fÃƒÂ¼r Laufzeit-Farbwechsel

---

## [0.5.0] Ã¢â‚¬â€œ 2026-05-22 Ã¢â‚¬â€œ Zeiterfassung

### Neu
- **Zeiterfassung**: Timer starten/stoppen mit Projekt- und Aufgabenzuordnung
- **Manuelle EintrÃƒÂ¤ge**: Zeiten nachtrÃƒÂ¤glich eintragen und bearbeiten
- **Eigene Felder fÃƒÂ¼r ZeiteintrÃƒÂ¤ge**: Admin kann beliebige Zusatzfelder definieren (z.B. Ort, Fahrtzeit, Notiz)
- **Projektzeitbericht als PDF**: Gefilterte Auswertung nach Zeitraum, Mitarbeiter, Projekt als druckfertiges PDF
- **Bericht-Optionen**: Zeitrunden auf 15/30 Minuten, Filterung nach Aufgabe, verschiedene Zeitraum-Voreinstellungen

### Technische Details
- 
